/**
 * canonical-es.mjs — conformance layer канонизации execution-security/1.
 *
 * Нормативный источник: protocol/execution-security-1.md
 *   SHA-256 cb9fc1ff98be1efb428ee924c81163aab974b99faa8465f80f3d5697095cd04e
 * Базовая канонизация: archive-canon/json-v1 (src/lib/canonical.mjs).
 *
 * Слой НЕ переопределяет archive-canon. Он ВВОДИТ СУЖЕНИЕ для подписываемых
 * структур закона: множество допустимых канонических значений здесь строго
 * меньше ArchiveValue. Единственное расхождение с архивом — знак нуля:
 * archive-canon сохраняет −0 литералом "-0" (решение Р13, −0 там значимые
 * данные); для подписываемого протокола −0 НЕ является допустимым
 * каноническим числом и отклоняется на стадии decode. Архивный слой не
 * изменяется.
 *
 * Разделение обязанностей (жёсткая граница шага 1):
 *   esCanonicalEncode(value) -> Uint8Array        // без хэширования внутри
 *   esCanonicalHash(domain, value) -> hex         // SHA256(domain || bytes)
 *   esDecode(bytes) -> value                      // строгий декодер
 *   assertCanonicalBytes(bytes)                   // проверка каноничности ввода
 *   assertShape(value, spec)                      // структурная валидация
 * Семантическая валидация в этом файле отсутствует по построению.
 *
 * Стадии отказа фиксируются полем stage: decode | shape | canonicality.
 * Коды отказа закона (§7) здесь НЕ используются: перевод стадии в код —
 * обязанность валидаторов структур, не канонического слоя.
 */

import { sha256Bytes } from "../lib/sha256.mjs";

export const ES_CANON_ID = "execution-security/canon-json-v1";
export const ES_BASE_CANON = "archive-canon/json-v1";

const enc = new TextEncoder();
const dec = new TextDecoder("utf-8", { fatal: true });

/** Реестр стабильных классов причин. Тотален: путь отказа без класса невозможен. */
export const CanonReason = Object.freeze({
  INVALID_JSON: "invalid-json",
  INVALID_UTF8: "invalid-utf8",
  NEGATIVE_ZERO: "negative-zero",
  NON_FINITE: "non-finite-literal",
  DUPLICATE_KEY: "duplicate-key",
  DEPTH: "depth",
  TYPE_MISMATCH: "type-mismatch",
  UNSUPPORTED_VALUE: "unsupported-value",
  CYCLE: "cycle",
  ACCESSOR: "accessor",
  UNKNOWN_FIELD: "unknown-field",
  MISSING_FIELD: "missing-field",
  NULL_VALUE: "null",
  RANGE: "range",
  ENUM: "enum",
  PATTERN: "pattern",
  CANONICAL_FORM: "canonical-form",
  CANONICAL_ORDER: "canonical-order",
  INVALID_DOMAIN: "invalid-domain",
  INVALID_HEX: "invalid-hex",
  INPUT_TYPE: "input-type",
  SPEC: "spec",
  DUPLICATE_ITEM: "duplicate-item",
  DISCRIMINATOR: "discriminator",
  KEY_PATTERN: "key-pattern",
});
const REASONS = new Set(Object.values(CanonReason));

export class CanonError extends Error {
  /** reasonClass обязателен: классификация не может быть пропущена молча. */
  constructor(stage, reasonClass, reason, path = "$") {
    super(`${stage}:${path}: ${reason}`);
    if (!REASONS.has(reasonClass)) {
      throw new Error(`CanonError: неизвестный reasonClass "${reasonClass}" (${stage}:${reason})`);
    }
    this.stage = stage;     // decode | shape | canonicality
    this.reasonClass = reasonClass;
    this.reason = reason;
    this.path = path;
  }
}

/* ── байтовый компаратор ключей (совместим с archive-canon) ───────────── */
function byteCompareEscaped(a, b) {
  const A = enc.encode(JSON.stringify(a)), B = enc.encode(JSON.stringify(b));
  const n = Math.min(A.length, B.length);
  for (let i = 0; i < n; i++) if (A[i] !== B[i]) return A[i] - B[i];
  return A.length - B.length;
}
const isPlainObject = (v) =>
  v !== null && typeof v === "object" && !Array.isArray(v) &&
  (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);

/* ── 1. encode: value -> bytes, без хэширования ───────────────────────── */

function encodeValue(v, path, seen) {
  if (v === null) return "null";   // JSON-литерал; НЕ связан с CanonReason.NULL_VALUE
  const t = typeof v;
  if (t === "boolean") return v ? "true" : "false";
  if (t === "number") {
    if (!Number.isFinite(v)) throw new CanonError("shape", CanonReason.NON_FINITE, `${v}: NaN/Infinity запрещены`, path);
    if (Object.is(v, -0)) throw new CanonError("shape", CanonReason.NEGATIVE_ZERO, "-0 не является допустимым каноническим числом (сужение относительно archive-canon)", path);
    return JSON.stringify(v);
  }
  if (t === "string") return JSON.stringify(v);
  if (t === "undefined") throw new CanonError("shape", CanonReason.UNSUPPORTED_VALUE, "undefined запрещён", path);
  if (t === "bigint") throw new CanonError("shape", CanonReason.UNSUPPORTED_VALUE, "BigInt запрещён", path);
  if (t === "function" || t === "symbol") throw new CanonError("shape", CanonReason.UNSUPPORTED_VALUE, `${t} запрещён`, path);
  if (seen.has(v)) throw new CanonError("shape", CanonReason.CYCLE, "цикл", path);
  seen.add(v);
  try {
    if (Array.isArray(v)) {
      const ad = Object.getOwnPropertyDescriptors(v);
      for (const key of Reflect.ownKeys(v)) {
        if (key === "length") continue;
        if (typeof key === "symbol") throw new CanonError("shape", CanonReason.UNSUPPORTED_VALUE, "symbol-ключ массива запрещён", path);
        const d = ad[key];
        if (!d.enumerable) throw new CanonError("shape", CanonReason.UNSUPPORTED_VALUE, `неперечислимое свойство массива ${key} запрещено`, path);
        const isIndex = /^(0|[1-9][0-9]*)$/.test(key);
        if (!isIndex) throw new CanonError("shape", CanonReason.UNSUPPORTED_VALUE, `нецелочисленное свойство массива ${key} запрещено`, `${path}.${key}`);
        if (d.get || d.set) throw new CanonError("shape", CanonReason.ACCESSOR, `getter/setter ${key} запрещён`, `${path}[${key}]`);
      }
      const parts = [];
      for (let i = 0; i < v.length; i++) {
        const d = ad[String(i)];
        if (!d) throw new CanonError("shape", CanonReason.MISSING_FIELD, `разреженный массив: отсутствует элемент #${i}`, `${path}[${i}]`);
        parts.push(encodeValue(d.value, `${path}[${i}]`, seen));
      }
      return "[" + parts.join(",") + "]";
    }
    if (!isPlainObject(v)) throw new CanonError("shape", CanonReason.UNSUPPORTED_VALUE, "непростой объект (Date/Map/Set/класс/toJSON/TypedArray) запрещён", path);
    const desc = Object.getOwnPropertyDescriptors(v);
    for (const k of Reflect.ownKeys(v)) {
      if (typeof k === "symbol") throw new CanonError("shape", CanonReason.UNSUPPORTED_VALUE, "symbol-ключ запрещён", path);
      const d = desc[k];
      if (!d.enumerable) throw new CanonError("shape", CanonReason.UNSUPPORTED_VALUE, `неперечислимое поле ${k} запрещено`, `${path}.${k}`);
      if (d.get || d.set) throw new CanonError("shape", CanonReason.ACCESSOR, `getter/setter ${k} запрещён`, `${path}.${k}`);
    }
    const keys = Object.keys(v).sort(byteCompareEscaped);
    return "{" + keys.map((k) => JSON.stringify(k) + ":" + encodeValue(desc[k].value, `${path}.${k}`, seen)).join(",") + "}";
  } finally { seen.delete(v); }
}

/** value -> канонические байты. Хэширования внутри нет по контракту. */
export function esCanonicalEncode(value) {
  return enc.encode(encodeValue(value, "$", new WeakSet()));
}

/* ── 2. domain-separated hash ─────────────────────────────────────────── */

const hex = (b) => Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");

/** SHA256(domain || canonicalEncode(value)); домен — обязательный префикс. */
export function esCanonicalHash(domain, value) {
  if (typeof domain !== "string" || domain.length === 0) {
    throw new CanonError("shape", CanonReason.INVALID_DOMAIN, "domain: непустая строка обязательна (domain separation)");
  }
  const d = enc.encode(domain), b = esCanonicalEncode(value);
  const buf = new Uint8Array(d.length + b.length);
  buf.set(d, 0); buf.set(b, d.length);
  return sha256Bytes(buf);
}

/**
 * SHA256(domain || part0 || part1 || …) — для байтовых конкатенаций (Merkle-узлы).
 *
 * ОГРАНИЧЕНИЕ КОНТРАКТА: длины частей не кодируются, поэтому конкатенация
 * неоднозначна для частей переменной длины:
 *   esDomainHashBytes(d, "ab", "c") === esDomainHashBytes(d, "a", "bc").
 * Вызывающий алгоритм ОБЯЗАН использовать части фиксированной длины либо
 * собственный framing. Для evidence-merkle/1 это безопасно: дочерние хэши
 * всегда ровно 32 байта.
 */
export function esDomainHashBytes(domain, ...parts) {
  if (typeof domain !== "string" || domain.length === 0) {
    throw new CanonError("shape", CanonReason.INVALID_DOMAIN, "domain: непустая строка обязательна (domain separation)");
  }
  for (let i = 0; i < parts.length; i++) {
    if (!(parts[i] instanceof Uint8Array)) {
      throw new CanonError("shape", CanonReason.INPUT_TYPE, `part[${i}] обязан быть Uint8Array`, `$.parts[${i}]`);
    }
  }
  const d = enc.encode(domain);
  let n = d.length; for (const p of parts) n += p.length;
  const buf = new Uint8Array(n);
  buf.set(d, 0); let o = d.length;
  for (const p of parts) { buf.set(p, o); o += p.length; }
  return sha256Bytes(buf);
}

export const bytesToHex = hex;
export function hexToBytes(h) {
  if (typeof h !== "string" || h.length % 2 !== 0 || !/^[0-9a-f]*$/.test(h)) {
    throw new CanonError("shape", CanonReason.INVALID_HEX, "hex: строка чётной длины из [0-9a-f]");
  }
  const out = new Uint8Array(h.length / 2);
  for (let i = 0; i < out.length; i++) out[i] = parseInt(h.slice(i * 2, i * 2 + 2), 16);
  return out;
}

/* ── 3. строгий декодер: сканер JSON с состояниями (стадия decode) ──── */

/**
 * Полноценный лексический разбор, а НЕ поиск подстрок по сырому тексту:
 * запрещённые числовые токены и дубли ключей определяются грамматически,
 * вне строкового состояния.
 *
 * Нормы decode:
 *  - любой JSON number token, числовое значение которого равно
 *    отрицательному нулю, отвергается (-0, -0.0, -0e0, -0E+10, …);
 *  - NaN/Infinity/-Infinity как литералы отсутствуют в грамматике;
 *  - дубли ключей сравниваются по ДЕКОДИРОВАННОМУ значению строки,
 *    поэтому "a" и "\u0061" — один и тот же ключ;
 *  - Unicode-нормализация не выполняется: "é" и "e"+U+0301 остаются
 *    разными ключами;
 *  - никаких default, coercion и преобразования числовых строк.
 */
class Scanner {
  constructor(text) { this.s = text; this.i = 0; this.n = text.length; }
  err(reason, cls) { throw new CanonError("decode", cls, `${reason} (позиция ${this.i})`, "$"); }
  ws() { while (this.i < this.n && (this.s[this.i] === " " || this.s[this.i] === "\t" || this.s[this.i] === "\n" || this.s[this.i] === "\r")) this.i++; }
  peek() { return this.i < this.n ? this.s[this.i] : null; }
  expect(ch) { if (this.s[this.i] !== ch) this.err(`ожидался '${ch}'`, CanonReason.INVALID_JSON); this.i++; }

  parseValue(depth = 0) {
    if (depth > 256) this.err("превышена глубина вложенности", CanonReason.DEPTH);
    this.ws();
    const c = this.peek();
    if (c === null) this.err("неожиданный конец ввода", CanonReason.INVALID_JSON);
    if (c === "{") return this.parseObject(depth);
    if (c === "[") return this.parseArray(depth);
    if (c === '"') return this.parseString();
    if (c === "t") { this.lit("true"); return true; }
    if (c === "f") { this.lit("false"); return false; }
    if (c === "n") { this.lit("null"); return null; }   // JSON-литерал, не класс причины
    if (this.s.startsWith("-Infinity", this.i)) this.err("NaN/Infinity-литералы запрещены", CanonReason.NON_FINITE);
    if (c === "-" || (c >= "0" && c <= "9")) return this.parseNumber();
    if (c === "N" || c === "I") this.err("NaN/Infinity-литералы запрещены", CanonReason.NON_FINITE);
    this.err(`недопустимый символ '${c}'`, CanonReason.INVALID_JSON);
  }
  lit(word) {
    if (this.s.startsWith(word, this.i)) { this.i += word.length; return; }
    if (this.s.startsWith("Infinity", this.i) || this.s.startsWith("NaN", this.i)) this.err("NaN/Infinity-литералы запрещены", CanonReason.NON_FINITE);
    this.err(`ожидался литерал ${word}`, CanonReason.INVALID_JSON);
  }
  parseObject(depth) {
    this.expect("{");
    const obj = {};
    const seen = new Set();      // ДЕКОДИРОВАННЫЕ ключи
    this.ws();
    if (this.peek() === "}") { this.i++; return obj; }
    for (;;) {
      this.ws();
      if (this.peek() !== '"') this.err("ключ объекта обязан быть строкой", CanonReason.INVALID_JSON);
      const key = this.parseString();
      if (seen.has(key)) this.err(`дублирующийся ключ ${JSON.stringify(key)}`, CanonReason.DUPLICATE_KEY);
      seen.add(key);
      this.ws(); this.expect(":");
      const v = this.parseValue(depth + 1);
      Object.defineProperty(obj, key, { value: v, writable: true, enumerable: true, configurable: true });
      this.ws();
      const c = this.peek();
      if (c === ",") { this.i++; continue; }
      if (c === "}") { this.i++; return obj; }
      this.err("ожидались ',' или '}'", CanonReason.INVALID_JSON);
    }
  }
  parseArray(depth) {
    this.expect("[");
    const arr = [];
    this.ws();
    if (this.peek() === "]") { this.i++; return arr; }
    for (;;) {
      arr.push(this.parseValue(depth + 1));
      this.ws();
      const c = this.peek();
      if (c === ",") { this.i++; continue; }
      if (c === "]") { this.i++; return arr; }
      this.err("ожидались ',' или ']'", CanonReason.INVALID_JSON);
    }
  }
  parseString() {
    this.expect('"');
    let out = "";
    for (;;) {
      if (this.i >= this.n) this.err("незакрытая строка", CanonReason.INVALID_JSON);
      const c = this.s[this.i];
      if (c === '"') { this.i++; return out; }
      if (c === "\\") {
        this.i++;
        const e = this.s[this.i];
        if (e === undefined) this.err("оборванная escape-последовательность", CanonReason.INVALID_JSON);
        this.i++;
        switch (e) {
          case '"': out += '"'; break;
          case "\\": out += "\\"; break;
          case "/": out += "/"; break;
          case "b": out += "\b"; break;
          case "f": out += "\f"; break;
          case "n": out += "\n"; break;
          case "r": out += "\r"; break;
          case "t": out += "\t"; break;
          case "u": {
            const h = this.s.slice(this.i, this.i + 4);
            if (!/^[0-9a-fA-F]{4}$/.test(h)) this.err("некорректный \\u-escape", CanonReason.INVALID_JSON);
            this.i += 4;
            out += String.fromCharCode(parseInt(h, 16));
            break;
          }
          default: this.err(`недопустимая escape-последовательность \\${e}`, CanonReason.INVALID_JSON);
        }
        continue;
      }
      const code = c.charCodeAt(0);
      if (code < 0x20) this.err("непроэкранированный управляющий символ", CanonReason.INVALID_JSON);
      out += c;
      this.i++;
    }
  }
  parseNumber() {
    const start = this.i;
    if (this.peek() === "-") this.i++;
    if (this.peek() === "0") { this.i++; }
    else if (this.peek() >= "1" && this.peek() <= "9") { while (this.peek() >= "0" && this.peek() <= "9") this.i++; }
    else this.err("некорректное число", CanonReason.INVALID_JSON);
    if (this.peek() === ".") {
      this.i++;
      if (!(this.peek() >= "0" && this.peek() <= "9")) this.err("нет цифр после точки", CanonReason.INVALID_JSON);
      while (this.peek() >= "0" && this.peek() <= "9") this.i++;
    }
    if (this.peek() === "e" || this.peek() === "E") {
      this.i++;
      if (this.peek() === "+" || this.peek() === "-") this.i++;
      if (!(this.peek() >= "0" && this.peek() <= "9")) this.err("нет цифр в экспоненте", CanonReason.INVALID_JSON);
      while (this.peek() >= "0" && this.peek() <= "9") this.i++;
    }
    const token = this.s.slice(start, this.i);
    const value = Number(token);
    if (!Number.isFinite(value)) this.err(`число вне диапазона f64: ${token}`, CanonReason.NON_FINITE);
    // Норма: любой числовой токен со значением отрицательного нуля отвергается.
    if (Object.is(value, -0)) this.err(`${token}: числовое значение равно -0`, CanonReason.NEGATIVE_ZERO);
    return value;
  }
}

export function esDecode(bytes) {
  if (!(bytes instanceof Uint8Array)) throw new CanonError("decode", CanonReason.INPUT_TYPE, "ожидались Uint8Array", "$");
  let text;
  try { text = dec.decode(bytes); }
  catch { throw new CanonError("decode", CanonReason.INVALID_UTF8, "недопустимая последовательность UTF-8", "$"); }
  const sc = new Scanner(text);
  const value = sc.parseValue();
  sc.ws();
  if (sc.i !== sc.n) sc.err("лишние данные после значения", CanonReason.INVALID_JSON);
  return value;
}

/* ── 4. проверка каноничности ввода (стадия canonicality) ─────────────── */

/**
 * Байты каноничны, если повторное кодирование декодированного значения даёт
 * ровно те же байты. Ловит неканонический порядок ключей, лишние пробелы,
 * неминимальную запись чисел.
 */

/** Классифицирует причину неканоничности: порядок ключей либо форма записи. */
function canonicalReasonClass(input, canon) {
  try {
    const a = dec.decode(input), b = dec.decode(canon);
    const keysOf = (t) => (t.match(/"[^"]*"\s*:/g) || []).join("");
    if (keysOf(a) !== keysOf(b) && a.replace(/\s/g, "").length === b.length) return CanonReason.CANONICAL_ORDER;
    const sameChars = a.replace(/\s/g, "") === b;
    return sameChars ? CanonReason.CANONICAL_FORM : (keysOf(a) !== keysOf(b) ? CanonReason.CANONICAL_ORDER : CanonReason.CANONICAL_FORM);
  } catch { return CanonReason.CANONICAL_FORM; }
}

export function assertCanonicalBytes(bytes) {
  const value = esDecode(bytes);
  const re = esCanonicalEncode(value);
  if (re.length !== bytes.length) {
    throw new CanonError("canonicality", CanonReason.CANONICAL_FORM, `длина ${bytes.length} ≠ канонической ${re.length}`, "$");
  }
  for (let i = 0; i < re.length; i++) {
    if (re[i] !== bytes[i]) throw new CanonError("canonicality", canonicalReasonClass(bytes, re), `расхождение в байте ${i}`, "$");
  }
  return value;
}

/* ── 5. структурная валидация (стадия shape) ──────────────────────────── */

/* ── компиляция spec (доверенная форма) ──────────────────────────────── */

const COMPILED = new WeakMap();
const SPEC_TYPES = new Set(["string", "integer", "number", "boolean", "array", "object", "map"]);

/**
 * Однократно проверяет и замораживает spec: компилирует regex (SyntaxError
 * превращается в классифицированный CanonError), проверяет состав вариантов,
 * типы полей и вложенные spec. Runtime-валидация работает только с
 * проверенными объектами, поэтому повреждённый spec не может обойти CanonError.
 */
function specErr(msg, path) { throw new CanonError("shape", CanonReason.SPEC, msg, path); }
export function compileShapeSpec(spec, path = "$") {
  if (!isPlainObject(spec)) throw new CanonError("shape", CanonReason.SPEC, "spec обязан быть простым объектом", path);
  const keys = Object.keys(spec);

  if (spec.discriminator !== undefined) {
    // Верхний уровень: строгий состав. fields рядом с variants запрещены —
    // иначе объявленные поля молча игнорировались бы.
    const allowed = new Set(["discriminator", "variants"]);
    for (const k of keys) if (!allowed.has(k)) specErr(`неизвестное свойство spec "${k}"`, path);
    if (typeof spec.discriminator !== "string" || spec.discriminator.length === 0) {
      specErr("discriminator: непустая строка", path);
    }
    if (!isPlainObject(spec.variants) || Object.keys(spec.variants).length === 0) {
      specErr("variants: непустой объект вариантов", path);
    }
    const variants = Object.create(null);   // prototype-safe: ключ __proto__ из JSON
    for (const tag of Object.keys(spec.variants)) {
      const compiled = compileShapeSpec(spec.variants[tag], `${path}.variants.${tag}`);
      // Тег обязан быть закреплён самим вариантом: engine гарантирует
      // соответствие, а не дисциплина автора spec.
      if (!compiled.fields) specErr(`вариант ${tag}: вложенные discriminator-варианты не поддержаны`, `${path}.variants.${tag}`);
      const df = compiled.fields[spec.discriminator];
      if (!df) specErr(`вариант ${tag}: отсутствует поле дискриминатора ${spec.discriminator}`, `${path}.variants.${tag}`);
      if (df.type !== "string") specErr(`вариант ${tag}: поле дискриминатора обязано быть string`, `${path}.variants.${tag}`);
      if (!df.enum || df.enum.length !== 1 || df.enum[0] !== tag) {
        specErr(`вариант ${tag}: enum дискриминатора обязан быть ровно ["${tag}"]`, `${path}.variants.${tag}`);
      }
      if (df.optional === true) specErr(`вариант ${tag}: дискриминатор не может быть optional`, `${path}.variants.${tag}`);
      if (df.nullable === true) specErr(`вариант ${tag}: дискриминатор не может быть nullable`, `${path}.variants.${tag}`);
      Object.defineProperty(variants, tag, { value: compiled, enumerable: true, writable: false, configurable: false });
    }
    const out = Object.freeze({ discriminator: spec.discriminator, variants: Object.freeze(variants) });
    COMPILED.set(out, true);
    return out;
  }

  const allowed = new Set(["fields"]);
  for (const k of keys) if (!allowed.has(k)) specErr(`неизвестное свойство spec "${k}"`, path);
  if (!isPlainObject(spec.fields)) specErr("fields: объект обязателен", path);
  const fields = Object.create(null);      // prototype-safe
  for (const name of Object.keys(spec.fields)) {
    Object.defineProperty(fields, name, {
      value: compileField(spec.fields[name], `${path}.${name}`),
      enumerable: true, writable: false, configurable: false,
    });
  }
  const out = Object.freeze({ fields: Object.freeze(fields) });
  COMPILED.set(out, true);
  return out;
}

/** Разрешённые ограничения по типу. Ключ вне списка ⇒ отказ spec (ловит опечатки). */
const FIELD_KEYS = Object.freeze({
  common: ["type", "optional", "nullable"],
  string: ["enum", "pattern", "minUtf8Bytes", "maxUtf8Bytes"],
  integer: ["enum", "minimum", "maximum"],
  number: ["minimum", "maximum"],
  boolean: [],
  array: ["items", "minItems", "maxItems", "uniqueItems"],
  object: ["spec"],
  map: ["keyPattern", "values", "minEntries", "maxEntries"],
});

function reqBool(f, k, path) {
  if (f[k] !== undefined && typeof f[k] !== "boolean") specErr(`${k}: только boolean`, path);
}
function reqCount(f, k, path) {
  if (f[k] === undefined) return;
  if (typeof f[k] !== "number" || !Number.isSafeInteger(f[k]) || f[k] < 0) specErr(`${k}: неотрицательное безопасное целое`, path);
}
function reqBound(f, k, path, integer) {
  if (f[k] === undefined) return;
  if (typeof f[k] !== "number" || !Number.isFinite(f[k])) specErr(`${k}: конечное число`, path);
  if (integer && !Number.isSafeInteger(f[k])) specErr(`${k}: безопасное целое для type=integer`, path);
}
function reqOrder(f, lo, hi, path) {
  if (f[lo] !== undefined && f[hi] !== undefined && f[lo] > f[hi]) specErr(`${lo} > ${hi}`, path);
}

/**
 * Компиляция описания поля по WHITELIST: копируются только разрешённые для
 * данного типа ограничения, каждое проверяется по типу и взаимной
 * согласованности; массивы пересоздаются и замораживаются, поэтому
 * последующая мутация исходного объекта не влияет на скомпилированную форму.
 */
function compileField(f, path) {
  if (!isPlainObject(f)) specErr("описание поля обязано быть объектом", path);
  if (!SPEC_TYPES.has(f.type)) specErr(`неизвестный тип спецификации ${f.type}`, path);

  const allowed = new Set([...FIELD_KEYS.common, ...FIELD_KEYS[f.type]]);
  for (const k of Object.keys(f)) {
    if (!allowed.has(k)) specErr(`ограничение "${k}" недопустимо для type=${f.type}`, path);
  }
  reqBool(f, "optional", path); reqBool(f, "nullable", path); reqBool(f, "uniqueItems", path);

  const out = { type: f.type };
  if (f.optional !== undefined) out.optional = f.optional;
  if (f.nullable !== undefined) out.nullable = f.nullable;

  if (f.enum !== undefined) {
    if (!Array.isArray(f.enum) || f.enum.length === 0) specErr("enum: непустой массив", path);
    const wantString = f.type === "string";
    const seenEnum = new Set();
    for (const e of f.enum) {
      if (wantString ? typeof e !== "string" : !Number.isSafeInteger(e)) specErr(`enum: элемент несовместим с type=${f.type}`, path);
      if (!wantString && Object.is(e, -0)) specErr("enum: -0 запрещён", path);
      if (seenEnum.has(e)) specErr(`enum: дубль ${JSON.stringify(e)}`, path);
      seenEnum.add(e);
    }
    out.enum = Object.freeze([...f.enum]);      // изоляция от мутаций raw spec
  }
  if (f.pattern !== undefined) {
    if (typeof f.pattern !== "string") specErr("pattern: строка", path);
    try { out.compiledPattern = new RegExp(f.pattern); }
    catch (e) { specErr(`невалидный pattern: ${e.message}`, path); }
    out.pattern = f.pattern;
  }
  if (f.type === "string") {
    reqCount(f, "minUtf8Bytes", path); reqCount(f, "maxUtf8Bytes", path); reqOrder(f, "minUtf8Bytes", "maxUtf8Bytes", path);
    if (f.minUtf8Bytes !== undefined) out.minUtf8Bytes = f.minUtf8Bytes;
    if (f.maxUtf8Bytes !== undefined) out.maxUtf8Bytes = f.maxUtf8Bytes;
  }
  if (f.type === "integer" || f.type === "number") {
    const isInt = f.type === "integer";
    reqBound(f, "minimum", path, isInt); reqBound(f, "maximum", path, isInt); reqOrder(f, "minimum", "maximum", path);
    if (f.minimum !== undefined) out.minimum = f.minimum;
    if (f.maximum !== undefined) out.maximum = f.maximum;
  }
  if (f.type === "array") {
    reqCount(f, "minItems", path); reqCount(f, "maxItems", path); reqOrder(f, "minItems", "maxItems", path);
    if (f.minItems !== undefined) out.minItems = f.minItems;
    if (f.maxItems !== undefined) out.maxItems = f.maxItems;
    if (f.uniqueItems !== undefined) out.uniqueItems = f.uniqueItems;
    if (f.items !== undefined) out.items = compileField(f.items, `${path}.items`);
  }
  if (f.type === "object" && f.spec !== undefined) out.spec = compileShapeSpec(f.spec, `${path}.spec`);
  if (f.type === "map") {
    reqCount(f, "minEntries", path); reqCount(f, "maxEntries", path); reqOrder(f, "minEntries", "maxEntries", path);
    if (f.minEntries !== undefined) out.minEntries = f.minEntries;
    if (f.maxEntries !== undefined) out.maxEntries = f.maxEntries;
    if (f.keyPattern !== undefined) {
      if (typeof f.keyPattern !== "string") specErr("keyPattern: строка", path);
      try { out.compiledKeyPattern = new RegExp(f.keyPattern); }
      catch (e) { specErr(`невалидный keyPattern: ${e.message}`, path); }
      out.keyPattern = f.keyPattern;
    }
    if (f.values !== undefined) out.values = compileField(f.values, `${path}.values`);
  }
  return Object.freeze(out);
}

function ensureCompiled(spec, path) {
  return COMPILED.has(spec) ? spec : compileShapeSpec(spec, path);
}

/**
 * spec: { fields: {name: {type, optional?, nullable?, enum?, pattern?}} }
 * Unknown-поля отклоняются ДО вычисления любых нормативных хэшей.
 * Никаких default и coercion: отсутствующее необязательное поле остаётся
 * отсутствующим.
 */
export function assertShape(value, rawSpec, path = "$") {
  const spec = ensureCompiled(rawSpec, path);
  if (!isPlainObject(value)) throw new CanonError("shape", CanonReason.TYPE_MISMATCH, "ожидался простой объект", path);
  // Вариантная структура: ровно один spec выбирается по дискриминатору.
  // Смешение полей разных вариантов физически невозможно — обычный
  // assertShape выполняется уже против единственного выбранного варианта.
  if (spec.discriminator) {
    const name = spec.discriminator;
    // Чтение дискриминатора — тоже через descriptor: variant dispatch не
    // должен исполнять пользовательский код (четвёртая accessor-поверхность).
    const dd = Object.getOwnPropertyDescriptors(value);
    const descriptor = dd[name];
    if (!descriptor) {
      throw new CanonError("shape", CanonReason.DISCRIMINATOR, `отсутствует дискриминатор ${name}`, path);
    }
    if (descriptor.get || descriptor.set) {
      throw new CanonError("shape", CanonReason.ACCESSOR, `getter/setter ${name} запрещён`, `${path}.${name}`);
    }
    const tag = descriptor.value;
    if (typeof tag !== "string") {
      throw new CanonError("shape", CanonReason.DISCRIMINATOR, `дискриминатор ${name} обязан быть строкой`, `${path}.${name}`);
    }
    const variant = Object.prototype.hasOwnProperty.call(spec.variants, tag) ? spec.variants[tag] : undefined;
    if (!variant) {
      throw new CanonError("shape", CanonReason.DISCRIMINATOR, `неизвестный вариант ${name}=${tag}`, `${path}.${name}`);
    }
    return assertShape(value, variant, `${path}<${tag}>`);
  }
  // Полная поверхность: Reflect.ownKeys, а не только enumerable string keys —
  // иначе symbol/неперечислимое поле прошло бы shape, но затем было бы
  // отвергнуто encoder-ом. Домен shape и canonical model обязан совпадать.
  const descriptors = Object.getOwnPropertyDescriptors(value);
  const allowed = new Set(Object.keys(spec.fields));
  for (const k of Reflect.ownKeys(value)) {
    if (typeof k === "symbol") throw new CanonError("shape", CanonReason.UNSUPPORTED_VALUE, "symbol-ключ запрещён", path);
    const d = descriptors[k];
    if (!d.enumerable) throw new CanonError("shape", CanonReason.UNSUPPORTED_VALUE, `неперечислимое поле ${k} запрещено`, `${path}.${k}`);
    if (d.get || d.set) throw new CanonError("shape", CanonReason.ACCESSOR, `getter/setter ${k} запрещён`, `${path}.${k}`);
    if (!allowed.has(k)) throw new CanonError("shape", CanonReason.UNKNOWN_FIELD, `неизвестное поле ${k}`, path);
  }
  for (const [k, f] of Object.entries(spec.fields)) {
    const present = Object.prototype.hasOwnProperty.call(value, k);
    if (!present) {
      if (f.optional !== true) throw new CanonError("shape", CanonReason.MISSING_FIELD, `отсутствует обязательное поле ${k}`, path);
      continue;
    }
    const v = descriptors[k].value;
    if (v === null) {
      if (f.nullable !== true) throw new CanonError("shape", CanonReason.NULL_VALUE, `${k}: null запрещён`, path);
      continue;
    }
    checkType(v, f, `${path}.${k}`);
  }
  return value;
}

function checkType(v, f, path) {
  switch (f.type) {
    case "string":
      if (typeof v !== "string") throw new CanonError("shape", CanonReason.TYPE_MISMATCH, "ожидалась строка", path);
      if (f.enum && !f.enum.includes(v)) throw new CanonError("shape", CanonReason.ENUM, `значение вне enum: ${v}`, path);
      if (f.compiledPattern && !f.compiledPattern.test(v)) throw new CanonError("shape", CanonReason.PATTERN, `не соответствует ${f.pattern}`, path);
      // Единица длины — БАЙТЫ UTF-8, а не UTF-16 code units: именно байты
      // канонизируются и хэшируются. "😀" = 4 байта (в JS .length === 2).
      if (f.minUtf8Bytes !== undefined || f.maxUtf8Bytes !== undefined) {
        const bl = enc.encode(v).length;
        if (f.minUtf8Bytes !== undefined && bl < f.minUtf8Bytes) throw new CanonError("shape", CanonReason.RANGE, `${bl} < minUtf8Bytes ${f.minUtf8Bytes}`, path);
        if (f.maxUtf8Bytes !== undefined && bl > f.maxUtf8Bytes) throw new CanonError("shape", CanonReason.RANGE, `${bl} > maxUtf8Bytes ${f.maxUtf8Bytes}`, path);
      }
      break;
    case "integer":
      if (typeof v !== "number" || !Number.isSafeInteger(v)) throw new CanonError("shape", CanonReason.TYPE_MISMATCH, "ожидалось безопасное целое", path);
      if (Object.is(v, -0)) throw new CanonError("shape", CanonReason.NEGATIVE_ZERO, "-0 запрещён", path);
      if (f.enum && !f.enum.includes(v)) throw new CanonError("shape", CanonReason.ENUM, `значение вне enum: ${v}`, path);
      if (f.minimum !== undefined && v < f.minimum) throw new CanonError("shape", CanonReason.RANGE, `< ${f.minimum}`, path);
      if (f.maximum !== undefined && v > f.maximum) throw new CanonError("shape", CanonReason.RANGE, `> ${f.maximum}`, path);
      break;
    case "number":
      if (typeof v !== "number" || !Number.isFinite(v)) throw new CanonError("shape", CanonReason.TYPE_MISMATCH, "ожидалось конечное число", path);
      if (Object.is(v, -0)) throw new CanonError("shape", CanonReason.NEGATIVE_ZERO, "-0 запрещён", path);
      if (f.minimum !== undefined && v < f.minimum) throw new CanonError("shape", CanonReason.RANGE, `< ${f.minimum}`, path);
      if (f.maximum !== undefined && v > f.maximum) throw new CanonError("shape", CanonReason.RANGE, `> ${f.maximum}`, path);
      break;
    case "boolean":
      if (typeof v !== "boolean") throw new CanonError("shape", CanonReason.TYPE_MISMATCH, "ожидался boolean", path);
      break;
    case "array":
      if (!Array.isArray(v)) throw new CanonError("shape", CanonReason.TYPE_MISMATCH, "ожидался массив", path);
      const ad = Object.getOwnPropertyDescriptors(v);
      // Плотность обязательна: forEach/map пропускают holes, поэтому
      // разреженный массив иначе прошёл бы minItems и item-валидацию,
      // не имея при этом канонического представления.
      for (let i = 0; i < v.length; i++) {
        const d = ad[String(i)];
        if (!d) throw new CanonError("shape", CanonReason.MISSING_FIELD, `разреженный массив: отсутствует элемент #${i}`, `${path}[${i}]`);
        if (d.get || d.set) throw new CanonError("shape", CanonReason.ACCESSOR, `getter/setter на индексе ${i} запрещён`, `${path}[${i}]`);
      }
      if (f.minItems !== undefined && v.length < f.minItems) throw new CanonError("shape", CanonReason.RANGE, `< minItems ${f.minItems}`, path);
      if (f.maxItems !== undefined && v.length > f.maxItems) throw new CanonError("shape", CanonReason.RANGE, `> maxItems ${f.maxItems}`, path);
      // Порядок обязателен: valid item shape → canonical identity → uniqueness.
      // Иначе невалидный элемент сначала канонизируется и даёт отказ encoder-а
      // с чужим путём вместо структурного отказа по ${path}[i].
      if (f.items) {
        for (let i = 0; i < v.length; i++) {
          const x = ad[String(i)].value;
          if (f.items.type === "object" && f.items.spec) assertShape(x, f.items.spec, `${path}[${i}]`);
          else checkType(x, f.items, `${path}[${i}]`);
        }
      }
      if (f.uniqueItems === true) {
        const seenItems = new Set();
        for (let i = 0; i < v.length; i++) {
          const key = bytesToHex(esCanonicalEncode(ad[String(i)].value));
          if (seenItems.has(key)) throw new CanonError("shape", CanonReason.DUPLICATE_ITEM, `дубль элемента #${i}`, `${path}[${i}]`);
          seenItems.add(key);
        }
      }
      break;
    case "object":
      if (f.spec) assertShape(v, f.spec, path);
      else if (!isPlainObject(v)) throw new CanonError("shape", CanonReason.TYPE_MISMATCH, "ожидался простой объект", path);
      break;
    case "map": {
      // Четыре независимых ограничения: тип, pattern ключа, cardinality, spec значения.
      if (!isPlainObject(v)) throw new CanonError("shape", CanonReason.TYPE_MISMATCH, "ожидался простой объект (map)", path);
      const md = Object.getOwnPropertyDescriptors(v);
      for (const k of Reflect.ownKeys(v)) {
        if (typeof k === "symbol") throw new CanonError("shape", CanonReason.UNSUPPORTED_VALUE, "symbol-ключ map запрещён", path);
        const d = md[k];
        if (!d.enumerable) throw new CanonError("shape", CanonReason.UNSUPPORTED_VALUE, `неперечислимый ключ map ${k} запрещён`, `${path}.${k}`);
        if (d.get || d.set) throw new CanonError("shape", CanonReason.ACCESSOR, `getter/setter ${k} запрещён`, `${path}.${k}`);
      }
      const mkeys = Object.keys(v);
      if (f.minEntries !== undefined && mkeys.length < f.minEntries) throw new CanonError("shape", CanonReason.RANGE, `< minEntries ${f.minEntries}`, path);
      if (f.maxEntries !== undefined && mkeys.length > f.maxEntries) throw new CanonError("shape", CanonReason.RANGE, `> maxEntries ${f.maxEntries}`, path);
      for (const k of mkeys) {
        const x = md[k].value;
        if (f.compiledKeyPattern && !f.compiledKeyPattern.test(k)) {
          throw new CanonError("shape", CanonReason.KEY_PATTERN, `ключ ${k} не соответствует ${f.keyPattern}`, path);
        }
        if (f.values) {
          if (f.values.type === "object" && f.values.spec) assertShape(x, f.values.spec, `${path}.${k}`);
          else checkType(x, f.values, `${path}.${k}`);
        }
      }
      break;
    }
    default:
      throw new CanonError("shape", CanonReason.SPEC, `неизвестный тип спецификации ${f.type}`, path);
  }
}

/* ── Слой 2: spec-объекты структур §3 ────────────────────────────────── */

// Общие паттерны (переиспользуются в нескольких spec)
const HEX64 = "^[0-9a-f]{64}$";         // SHA-256 hex
const NODE_ID = "^[a-zA-Z0-9_.-]{1,128}$";
const POS_INT = { type: "integer", minimum: 1 };

/** §3.1 ProposalEnvelope — 18 полей + proposalHash (не вычисляется этим срезом). */
export const PROPOSAL_ENVELOPE_SPEC = compileShapeSpec({
  fields: {
    sourceNodeId:            { type: "string", pattern: NODE_ID, minUtf8Bytes: 1, maxUtf8Bytes: 128 },
    sourceStateHash:         { type: "string", pattern: HEX64 },
    sourceEpoch:             { type: "integer", minimum: 0 },
    proposalType:            { type: "string", enum: ["CALIBRATION_PROPOSAL"] },
    requestedCapability:     { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 256 },
    boundedParameters:       { type: "array", minItems: 1, maxItems: 64, items: {
      type: "object", spec: { fields: {
        parameterId:  { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 128 },
        proposedValue: { type: "number", minimum: 0, maximum: 4 },
      } }
    } },
    evidenceWindow:          { type: "object", spec: { fields: {
      firstReportSeq: { type: "integer", minimum: 0 },
      lastReportSeq:  { type: "integer", minimum: 0 },
      firstFactSeq:   { type: "integer", minimum: 0 },
      lastFactSeq:    { type: "integer", minimum: 0 },
    } } },
    supportSet:              { type: "array", minItems: 1, maxItems: 256 },
    supportRoot:             { type: "string", pattern: HEX64 },
    stabilityEvidenceHash:   { type: "string", pattern: HEX64 },
    causalConfigHash:        { type: "string", pattern: HEX64 },
    calibrationSurfaceId:    { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 256 },
    calibrationSurfaceHash:  { type: "string", pattern: HEX64 },
    parentCommitRefs:        { type: "array", minItems: 0, maxItems: 256, items: {
      type: "string", pattern: HEX64,
    } },
    nonce:                   { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 64 },
    validFromReportSeq:      { type: "integer", minimum: 0 },
    validUntilReportSeq:     { type: "integer", minimum: 0, optional: true },
    proposalHash:            { type: "string", pattern: HEX64 },
  }
});

// §3.2 evidenceWindow — отдельный spec для переиспользования
export const EVIDENCE_WINDOW_SPEC = compileShapeSpec({
  fields: {
    firstReportSeq: { type: "integer", minimum: 0 },
    lastReportSeq:  { type: "integer", minimum: 0 },
    firstFactSeq:   { type: "integer", minimum: 0 },
    lastFactSeq:    { type: "integer", minimum: 0 },
  }
});

/** §3.2 SupportAttestation — 7 полей. */
export const SUPPORT_ATTESTATION_SPEC = compileShapeSpec({
  fields: {
    supporterNodeId:    { type: "string", pattern: NODE_ID, minUtf8Bytes: 1, maxUtf8Bytes: 128 },
    supporterStateHash: { type: "string", pattern: HEX64 },
    supporterEpoch:     { type: "integer", minimum: 0 },
    parentCommitRef:    { type: "string", pattern: HEX64 },
    evidenceWindow:     { type: "object", spec: { fields: {
      firstReportSeq: { type: "integer", minimum: 0 },
      lastReportSeq:  { type: "integer", minimum: 0 },
      firstFactSeq:   { type: "integer", minimum: 0 },
      lastFactSeq:    { type: "integer", minimum: 0 },
    } } },
    derivationRoot:     { type: "string", pattern: HEX64 },
    supportClaimHash:   { type: "string", pattern: HEX64 },
  }
});

/** §3.3 EvidenceLeaf — 5 полей. Не вариантная. */
export const EVIDENCE_LEAF_SPEC = compileShapeSpec({
  fields: {
    commitMarkerHash: { type: "string", pattern: "^[0-9a-f]{64}$" },
    reportSeq:        { type: "integer", minimum: 0 },
    factSeq:          { type: "integer", minimum: 0 },
    factHash:         { type: "string", pattern: "^[0-9a-f]{64}$" },
    relationRole:     { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 128 },
  }
});

/** §3.4 AdministrativeDecision — 17 полей + decisionHash (не вычисляется этим срезом). */
export const ADMINISTRATIVE_DECISION_SPEC = compileShapeSpec({
  fields: {
    decisionVersion:        { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 64 },
    proposalHash:           { type: "string", pattern: "^[0-9a-f]{64}$" },
    decision:               { type: "string", enum: ["APPROVE", "DENY"] },
    calibrationSurfaceId:   { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 256 },
    calibrationSurfaceHash: { type: "string", pattern: "^[0-9a-f]{64}$" },
    parameterId:            { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 128 },
    expectedPreviousValue:  { type: "number", minimum: 0, maximum: 4 },
    approvedNextValue:      { type: "number", minimum: 0, maximum: 4 },
    approvedBudgetDebit:    { type: "number", minimum: 0, maximum: 4 },
    causalConfigHashBefore: { type: "string", pattern: "^[0-9a-f]{64}$" },
    applicationMode:        { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 64 },
    validFromReportSeq:     { type: "integer", minimum: 0 },
    validUntilReportSeq:    { type: "integer", minimum: 0 },
    authorityPolicyId:      { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 256 },
    authorityRegistryId:    { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 256 },
    authorityRegistryHash:  { type: "string", pattern: "^[0-9a-f]{64}$" },
    decisionNonce:          { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 64 },
    decisionHash:           { type: "string", pattern: "^[0-9a-f]{64}$" },
  }
});

/** §3.5 Authorization — 5 полей. */
export const AUTHORIZATION_SPEC = compileShapeSpec({
  fields: {
    authorityId:        { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 256 },
    keyId:              { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 256 },
    signatureAlgorithm: { type: "string", enum: ["Ed25519"] },
    decisionHash:       { type: "string", pattern: "^[0-9a-f]{64}$" },
    signature:          { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 1024 },
  }
});

/** §3.6 AuthorityKeyRecord — 8 полей. */
export const AUTHORITY_KEY_RECORD_SPEC = compileShapeSpec({
  fields: {
    authorityId:        { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 256 },
    keyId:              { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 256 },
    algorithm:          { type: "string", enum: ["Ed25519"] },
    publicKey:          { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 1024 },
    status:             { type: "string", enum: ["ACTIVE", "SUSPENDED", "REVOKED", "RETIRED"] },
    validFromReportSeq: { type: "integer", minimum: 0 },
    validUntilReportSeq:{ type: "integer", minimum: 0, nullable: true },
    allowedPolicyIds:   { type: "array", minItems: 1, maxItems: 64, items: {
      type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 256,
    } },
  }
});

/** §3.7 CALIBRATION_APPLY — 18 полей + calibrationApplyHash (не вычисляется этим срезом). */
export const CALIBRATION_APPLY_SPEC = compileShapeSpec({
  fields: {
    calibrationApplyVersion:     { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 64 },
    proposalHash:                { type: "string", pattern: "^[0-9a-f]{64}$" },
    decisionHash:                { type: "string", pattern: "^[0-9a-f]{64}$" },
    calibrationSurfaceId:        { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 256 },
    calibrationSurfaceHash:      { type: "string", pattern: "^[0-9a-f]{64}$" },
    authorityPolicyId:           { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 256 },
    authorityRegistryHash:       { type: "string", pattern: "^[0-9a-f]{64}$" },
    parameterId:                 { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 128 },
    previousValue:               { type: "number", minimum: 0, maximum: 4 },
    nextValue:                   { type: "number", minimum: 0, maximum: 4 },
    budgetDebit:                 { type: "number", minimum: 0, maximum: 4 },
    actuatorAuthorityId:         { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 256 },
    authorizationRefs:           { type: "array", minItems: 1, maxItems: 64, items: {
      type: "string", pattern: "^[0-9a-f]{64}$",
    } },
    applicationMode:             { type: "string", minUtf8Bytes: 1, maxUtf8Bytes: 64 },
    effectiveReportSeq:          { type: "integer", minimum: 0 },
    causalConfigHashBefore:      { type: "string", pattern: "^[0-9a-f]{64}$" },
    causalConfigHashAfter:       { type: "string", pattern: "^[0-9a-f]{64}$" },
    preApplicationCheckpointHash:{ type: "string", pattern: "^[0-9a-f]{64}$" },
    calibrationApplyHash:        { type: "string", pattern: "^[0-9a-f]{64}$" },
  }
});
