# JOURNAL — execution-security/1, шаг 7 (реализация)

Дата среза: 25 июля 2026. Точка входа для новой сессии. Всё ниже —
проверяемые факты, сверенные с деревом, не пересказ.

## Как развернуться в новой сессии

1. Распаковать рабочее дерево. Прогнать восемь гейтов (см. ниже) —
   обязаны дать зелёный, три эталона неизменны.
2. Прочитать docs/ в порядке README: CURRENT_STATE → NEXT_STEP →
   CONFORMANCE → ARCHITECTURAL_LAWS → DECISIONS → OPEN_QUESTIONS.
3. Сверить trust anchor: таблица хэшей в конце docs/CONFORMANCE.md должна
   совпасть с фактическими SHA-256 файлов.
4. Инвариант процесса: код пишется против зафиксированного документа
   (закон cb9fc1ff…d04e), НЕ против переписки. При расхождении нормативен
   документ.

## Где мы стоим

Спецификация execution-security/1.0.0 ПРИНЯТА и зафиксирована (draft1→
draft4 через ревизию). Реализация ОТКРЫТА и идёт.

**Шаг 7, слой 1 (канонизация + shape-engine) — ЗАКРЫТ.** Гейт
conformance-security 46/46. Единый допустимый домен значений: обе
публичные функции (esCanonicalEncode, assertShape) отвергают один класс
программно сконструированных значений. Custody machine-checked:
manifest→артефакты + внешний якорь в CONFORMANCE.md.

**Шаг 7, слой 2 (семь структур §3) — НЕ НАЧАТ.** Это следующее задание.

kernel-feedback-gate/1 — ЗАКРЫТ до прохождения полного гейта
execution-security.

## Восемь гейтов (все зелёные на срезе)

```
node tools/run-fixtures.mjs        # 52
node tools/conformance-step1.mjs   # 35
node tools/conformance-step2.mjs   # 14
node tools/conformance-step3.mjs   # 18
node tools/conformance-step4.mjs   # 21
node tools/conformance-step5.mjs   # 21
node tools/conformance-step6.mjs   # 57
node tools/conformance-security.mjs # 46
```

Три эталона (НЕ меняются): a7cdfd3b306c5a77, 20e11a6290f1c3bd,
4d036ba986b6d554.

## Комплект execution-security (хэши среза)

| Файл | SHA-256 | Назначение |
|---|---|---|
| protocol/execution-security-1.md | `cb9fc1ff98be1efb428ee924c81163aab974b99faa8465f80f3d5697095cd04e` | закон execution-security/1.0.0 |
| protocol/calibration-surface-1.md | `d4b6f02b0f345f207a3ab7d5b012858f910ddd0c0542fe8122e82dd8c153afaf` | профиль калибруемой поверхности |
| protocol/stability-profile-1.md | `de90716293e976981c07ab8c79d526579a1a5f1b03a5c13491283b42c7642ba3` | профиль устойчивости |
| protocol/authority-registry-schema-1.md | `0d58efa56bda4ebdfc137c4c94a208f606881534b165666660f71af199632b4e` | схема реестра полномочий |
| protocol/authority-policy-1.md | `59f338b934cbf77c754450f03d4f60382ba6615fc4296e36b8c0137465968c6f` | политики авторизации |
| protocol/evidence-merkle-1.md | `fd3a2cdd1762b4c782c17899065d4f82ef978281153e49dbd2bf20c388c16966` | канон дерева доказательств |
| src/security/canonical-es.mjs | `4cea625a6f6fbcc0c5197ca1b911a94bb020f3a46620a44156fa156716776578` | слой 1: канонизация + shape-engine |
| tools/conformance-security.mjs | `c4240799a48a3cd7e606cf1c15c1ede5b13197d53c95c63261d2af8d66c224f2` | гейт execution-security (46/46) |
| fixtures/es-canon-vectors.json | `bde175ba0e9d5069c653411e25e5816e37b898e98b4b0a4e9cfade94582fe63f` | переносимые векторы канонизации |
| fixtures/es-artifact-manifest.json | `7d325d6587faa8c808652910c00cb31fa95cf0b1ba6cbdd889eedbf96ab62526` | manifest custody |

Внешний якорь provenance — таблица в конце docs/CONFORMANCE.md
(закон+manifest+гейт+реализация+векторы). Хэш гейта закреплён якорем, не
manifest (гейт не хэширует сам себя: selfExcludedFromGate).

## Что делает слой 1 (src/security/canonical-es.mjs)

- esCanonicalEncode(value)→Uint8Array — без хэширования внутри.
- esCanonicalHash(domain,value)=SHA256(domain‖bytes) — домен обязателен.
- esDomainHashBytes(domain,...parts) — для Merkle-узлов; framing
  неоднозначен для переменных длин, безопасен для 32-байтных частей
  (зафиксировано контрактом и тестом).
- esDecode(bytes) — сканер JSON с состояниями (не regex): отвергает −0 во
  всех формах, NaN/Infinity, дубли ключей по ДЕКОДИРОВАННОМУ значению; без
  Unicode-нормализации.
- assertCanonicalBytes — round-trip проверка каноничности.
- compileShapeSpec(spec) + assertShape(value,spec) — spec-engine.

Реестр CanonReason заморожен (25 классов); reasonClass — ОБЯЗАТЕЛЬНЫЙ
аргумент CanonError (тотальность классификации: путь отказа без класса
невозможен). $special — маркер значений, невыразимых в JSON (−0), строгий:
ровно одно поле. Единица длины — minUtf8Bytes/maxUtf8Bytes (БАЙТЫ, не
code units). discriminator: отдельный spec на вариант, тег привязан к
enum движком, смешение полей вариантов ⇒ unknown-field. Четыре
accessor-поверхности закрыты (поля объекта, индексы массива, ключи map,
дискриминатор); holes, symbol-ключи, неперечислимые и лишние свойства
отвергаются; prototype-safe словари (__proto__ — обычный ключ).

−0: archive-canon сохраняет (Р13), подписываемый слой ЗАПРЕЩАЕТ. Это
осознанное СУЖЕНИЕ, зафиксировано отдельным тестом; архивный слой не
тронут.

## Следующее задание — слой 2 (порядок §11)

Семь структур §3 против закона cb9fc1ff…d04e, поверх проверенного
compileShapeSpec/assertShape:
1. ProposalEnvelope (§3.1)
2. SupportAttestation (§3.2)
3. EvidenceLeaf (§3.3) — вариантная
4. AdministrativeDecision (§3.4)
5. Authorization (§3.5)
6. AuthorityKeyRecord (§3.6)
7. CALIBRATION_APPLY (§3.7) — вариантная

Для каждой: отдельный spec ID на структуру и вариант; позитивный
canonical vector; негатив на КАЖДОЕ поле, enum, диапазон, pattern,
cardinality и cross-field ограничение; запрет смешения вариантов.
Хэшей НЕ вычислять — proposalHash/decisionHash/calibrationApplyHash идут
ОТДЕЛЬНЫМ срезом против уже зафиксированных байтов.

Тестовый экземпляр authority-registry-instance с детерминированной парой
ключей завести отдельно, помеченным как conformance fixture, НЕ раньше
среза подписей/авторизации.

## Инварианты, которые нельзя нарушить

- Код против зафиксированного документа, не против переписки.
- reversible-only калибровка; monotonic/irreversible в runtime denied.
- Причинный контур не пишет CALIBRATION_APPLY, не владеет ключами, не
  выбирает policy evaluator, не влияет на проверку происхождения.
- Каждый срез: маленький шаг → гейт → мутационный контроль → полный
  регресс восьми гейтов + сверка трёх эталонов → показ файлов.
- Custody: SHA-256 импортированного гейтом source == SHA-256
  предъявленного на ревью. Проверяется самим гейтом.
