# ROST/0k v2 — гейты и эталонные хэши

## Запуск

    cd rost0k-v2
    node tools/run-fixtures.mjs          # шаг 0: схемы и фикстуры
    node tools/conformance-step1.mjs     # ядро и хост
    node tools/conformance-step2.mjs     # снимки и ownership
    node tools/conformance-step3.mjs     # наблюдатели, C7, O1
    node tools/conformance-step4.mjs     # архив, ArchiveValue, идентичности
    node tools/conformance-step5.mjs     # журнал, оси, валидатор, manifest
    node tools/conformance-step6.mjs     # живой контур: staging, commit-bundle, seal-verify
    # node tools/conformance-security.mjs  # execution-security/1 (реализуется, шаг 7)

Node 22+, зависимостей нет, сеть не нужна. Любой гейт даёт ненулевой код
процесса при провале.

## Ожидаемые результаты (20 июля 2026)

| Гейт | Проверок |
|---|---|
| run-fixtures | 52 |
| step1 | 35 |
| step2 | 14 |
| step3 | 18 |
| step4 | 21 |
| step5 | 21 |
| step6 | 57 |

## Эталоны Integration Profile (fixtures/integration-hash-vectors.json)

Отдельный fixture, мутационно-контролируемый как hash-vector.json. Меняются
только явной сменой версии integration-relaxation.

| Что | Значение |
|---|---|
| Траектория Integration Profile, тик 100 | `1a0af86729512e7e` |
| Траектория Integration Profile, тик 200 | `d34ed9eef41ad1c8` |
| Голова потока фактов (seq:tick:type ×5) | `0:1 1:2 2:3 3:4 4:5`, тип `fact.field-relaxed` |

Три исходных эталона (a7cdfd3b306c5a77, 20e11a6290f1c3bd, 4d036ba986b6d554)
НЕ затронуты kernel-abi 2.2.0: метаданные и causalConfig в CausalStateHash
контрольного ядра не входят.

## Эталонные хэши — НЕ ДОЛЖНЫ меняться

Изменение любого из трёх без явной смены версии закона = сломанный
детерминизм. Это первое, что проверяется после любой правки.

| Что | Значение | Где проверяется |
|---|---|---|
| causal-state-hash, закреплённый вектор | `a7cdfd3b306c5a77` | run-fixtures (fixtures/hash-vector.json) |
| Траектория ядра, тик 100 | `20e11a6290f1c3bd` | step1 (C1) |
| Траектория ядра, тик 200 | `4d036ba986b6d554` | step2, step3 (A/B) |

## RNG-векторы контрольного ядра

master = 8842107, поток "noise":
- fnv1a32("noise") = `0x904416d1`
- seed = `0x90c2fdaa`
- первые u32: `0x218c9831`, `0xe3d6cff4`, `0x7f220ee0`, `0xe13c227f`, `0xcb0de806`

## Что доказывает каждый гейт

**run-fixtures (52).** Схемы принуждают законы, а не документируют их:
гибрид факт/заявление невалиден синтаксически; growthCapable обязан
совпадать с moveSet; протокол без предрегистрации отклоняется. Плюс 7
тестов эталона хэша: ±0 различимы, NaN → E_NAN_STATE, инвариантность к
порядку ключей, причинный u32 входит в хэш. Плюс нуль-контроль самого
раннера. Плюс журнальные схемы (семь типов).

**step1 (35).** C1–C6, C9. Прямое ядро ≡ InProcessHost ≡ WorkerHost при
разном батчинге. FIFO; step(0) посреди очереди не ломает порядок.
Mutation-suite полноты: обнуление input/hist/memory, сдвиг activePage и
phaseCursor (расхождение на горизонтах 1/8/64/256), RNG⊕маска, drive×2,
обратный порядок RNG. Зеркальный тест: обнуление мёртвой output-роли НЕ
меняет траекторию. Exact-restore: 12 подделок дескрипторов.

**step2 (14).** Кольцо <3 отклоняется. Drop-not-block: produced=3,
dropped=37 на 200 тактах — хэш эталонный. Ownership: двойной возврат,
чужой буфер, устаревший seq → E_OWNERSHIP; чтение после возврата →
E_USE_AFTER_RETURN (буфер физически отсоединён). Мёртвая роль не
просачивается в представление (байтовое сравнение двух состояний с
разным RawCausalRecordHash). E_HOST_FAILURE при аварии воркера.

**step3 (18).** **C7 в четырёх режимах** — анализатор отсутствует,
работает, падает на каждом снимке, соседствует с падающим: один хэш
`4d036ba986b6d554`. Частоты every=2 и every=25 — тот же хэш. **O1:**
диверсант-mutator с пятью стратегиями порчи, оба порядка регистрации —
payload соседа бит-идентичен контрольному. Claims — значения (мутация
descriptor после публикации бессильна). Кэхэн-тест 1e16+1−1e16.
Средонезависимость (нет Buffer в научном модуле).

**step4 (21).** ArchiveValue: 12 негативов (NaN, ±Inf, undefined, toJSON,
цикл, TypedArray, symbol-ключ, неперечислимое, getter, setter); −0
сохраняется; «__proto__» — данные, копия на null-прототипе. SHA-256 +
векторы FIPS. Fail-closed команды: мёртвый журнал ⇒ применение
недостижимо. Атомарность: 50 конкурентных записей одного id → ровно одна
запись. Жизненный цикл; три идентичности; 19 числовых векторов
пересчитываются из raw IEEE-754 hex.

**step5 (21).** **ЦТ1:** APPLIED + отказ result-журнала ⇒ UNSEALED при
неизменном runIdentityHash (`195cd390bc54…` у здорового и раненого).
**ЦТ2:** OUTCOME_UNKNOWN ⇒ только ABORTED+UNSEALED, causal-indeterminate,
compare() → E_IDENTITY_CLASS. Машина исходов (E_TRANSITION на повтор и
смену). JournalConsistencyValidator: 7 порч → 7 обнаружений (И1–И7).
Manifest: доказательство покрытия — подлог «recorded 0..10, HWM=100,
missing=[]» отвергается. Repair: дыра закрывается повторной выдачей;
лгущий источник ⇒ mismatch ⇒ permanent ⇒ INCOMPLETE. Э1–Э8: валидатор на
воротах SEALED, транзакционный resolve (PENDING после E_SCHEMA),
requestedTick ≠ scheduledTick в идентичности, идемпотентность
ObserverFailure, верификация finalCheckpointRef, чистота неудачного open.

## Дисциплина

После ЛЮБОЙ правки — полный регресс всех шести гейтов и сверка трёх
эталонов. Зелёный гейт без сверки эталонов ничего не доказывает.

## execution-security/1 — trust anchor реализации (шаг 7, слой 1)

Внешний якорь provenance: manifest доказывает внутреннюю согласованность
комплекта, но сам закрепляется здесь, уровнем выше. Согласованная подмена
закона/реализации/векторов/manifest не пройдёт, пока не совпадёт с этими
хэшами. Хэш гейта закреплён здесь, а не в manifest (гейт не хэширует сам
себя).

| Артефакт | SHA-256 |
|---|---|
| protocol/execution-security-1.md | `cb9fc1ff98be1efb428ee924c81163aab974b99faa8465f80f3d5697095cd04e` |
| fixtures/es-artifact-manifest.json | `7d325d6587faa8c808652910c00cb31fa95cf0b1ba6cbdd889eedbf96ab62526` |
| tools/conformance-security.mjs | `c4240799a48a3cd7e606cf1c15c1ede5b13197d53c95c63261d2af8d66c224f2` |
| src/security/canonical-es.mjs | `4cea625a6f6fbcc0c5197ca1b911a94bb020f3a46620a44156fa156716776578` |
| fixtures/es-canon-vectors.json | `bde175ba0e9d5069c653411e25e5816e37b898e98b4b0a4e9cfade94582fe63f` |

Цепочка: этот документ (якорь) → manifest → {закон, реализация, векторы};
хэш гейта — напрямую от якоря. Гейт conformance-security проверяет
manifest→артефакты; хэши manifest и гейта сверяются с настоящей таблицей
при регистрации среза.
