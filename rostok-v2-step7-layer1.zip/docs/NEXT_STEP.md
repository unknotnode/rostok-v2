# ROST/0k v2 — текущее задание

## Шаг 7: реализация execution-security/1.0.0

Спецификация execution-security/1.0.0 ПРИНЯТА (draft1→draft4 через ревизию,
новых способностей не вводит). Реализация ОТКРЫТА. Одно задание:
реализовать execution-security/1 строго по принятой спецификации + гейт.
kernel-feedback-gate/1 закрыт до прохождения этого гейта.

## Порядок реализации (нормативный, задан ревизором)

Не начинать с actuator или криптографии отдельно. Строго:

1. Чистые канонические структуры и валидаторы (ProposalEnvelope,
   AdministrativeDecision, SupportAttestation, CALIBRATION_APPLY,
   CalibrationSurface entry) — canonicalEncode переиспользует
   archive-canon/json-v1, второй несовместимый формат не вводить.
2. Provenance / support / replay: commit-backed происхождение,
   evidence-merkle/1 (SHA-256, domain separation, odd-node promotion,
   дубликаты запрещены), графовая независимость §4a, ProposalReplayRegistry.
3. Authorization: Ed25519, authority-registry/1, историческая проверка по
   authorityRegistryHash ДО key lookup и подписи.
4. State machine применения: NORMAL → CALIBRATION_APPLICATION →
   CALIBRATION_BINDING_PENDING → NORMAL; отказы/crash в окне ⇒
   CAUSAL_INDETERMINATE (Д-исп-3).
5. Интеграция с Runtime commit bundle: CALIBRATION_APPLY в causal evidence
   chain, calibrationApplyHash в первом переходе, reversible-only.

## Незыблемые инварианты (из спецификации)

- Только CALIBRATION_PROPOSAL; новые capabilities/типы фактов/буферы/связи/
  правила перехода ⇒ E_CAPABILITY_ESCALATION без анализа.
- reversible-only в runtime; monotonic/irreversible — denied.
- Причинный контур не пишет CALIBRATION_APPLY, не владеет ключами, не
  выбирает policy evaluator, не влияет на проверку происхождения (Р22/Р26).
- computedBudgetDebit == approvedBudgetDebit; один APPROVE ⇒ ≤1 применение;
  DENY не открывает application.
- Sandbox над отделённой копией: не потребляет production fact.seq, не
  публикует факты, не трогает retention/replay-registry/budget/STEP_COMMIT.
- Конвейер строго последователен, перескок структурно невозможен.

## Гейт execution-security (обязательные проверки)

Все коды отказа §4a/§4b/§5 + восемь conformance-нормализаций ревизии:
каноническое кодирование инвариантно к порядку полей; unknown-поле в
AdministrativeDecision отвергается до подписи; authorityRegistryHash
mismatch — до key lookup; sandbox, произведший production-факт/потребивший
fact.seq — провал; budget≠approved — E_DECISION_MISMATCH; BINDING_PENDING
+ seal — fail-closed; BINDING_PENDING + пропуск reportSeq —
E_CALIBRATION_BINDING; историческая авторизация по текущему реестру вместо
привязанного — провал; один APPROVE дважды ⇒ ровно одно CALIBRATION_APPLY
и одно списание budget.

После любой правки — полный регресс семи гейтов + сверка эталонов; гейт
execution-security добавляется восьмым.

## Что НЕ делать

- Не начинать с actuator/криптографии в отрыве от структур и валидаторов.
- Не открывать kernel-feedback-gate/1 до прохождения гейта.
- Не обещать durable recovery/replay/budget-reconstruction после crash
  (Д-исп-3; Т5/Т6 — вне области).
- Не переоткрывать принятые Runtime Integration Layer и спецификацию.
- Не вводить исполнение monotonic/irreversible в runtime.
- Не трогать зафиксированные ядра и исходные эталоны.
