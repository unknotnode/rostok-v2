/**
 * run-fixtures.mjs — гоняет fixtures/valid и fixtures/invalid через валидатор.
 *
 * Формат фикстуры:
 * {
 *   "schema": "event",                    // имя файла схемы без .schema.json
 *   "expect": "valid" | "invalid",
 *   "law": "Д2.3",                        // какой закон проверяется (для отчёта)
 *   "mustMention": "provenance",          // для invalid: подстрока в ошибках
 *   "data": { ... }
 * }
 *
 * Выход: сводка + ненулевой код процесса при любом расхождении.
 */
import { readFileSync, readdirSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { validate } from "./validate.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const schemaDir = join(root, "protocol", "schema");
const fixtureDirs = [join(root, "fixtures", "valid"), join(root, "fixtures", "invalid")];

const schemaCache = new Map();
function loadSchema(name) {
  if (!schemaCache.has(name)) {
    schemaCache.set(name, JSON.parse(readFileSync(join(schemaDir, `${name}.schema.json`), "utf8")));
  }
  return schemaCache.get(name);
}

let pass = 0, fail = 0;
const failures = [];

for (const dir of fixtureDirs) {
  for (const file of readdirSync(dir).filter((f) => f.endsWith(".json")).sort()) {
    const fx = JSON.parse(readFileSync(join(dir, file), "utf8"));
    const { ok, errors } = validate(loadSchema(fx.schema), fx.data, fx.schema);
    const expectedOk = fx.expect === "valid";
    let verdict = ok === expectedOk;
    let detail = "";
    if (verdict && !ok && fx.mustMention) {
      const text = errors.map((e) => `${e.path}: ${e.message}`).join("\n");
      if (!text.includes(fx.mustMention)) {
        verdict = false;
        detail = `ошибки не упоминают "${fx.mustMention}":\n${text}`;
      }
    }
    if (!verdict && detail === "") {
      detail = ok
        ? "валидатор принял то, что обязан отклонять"
        : "валидатор отклонил валидное:\n" + errors.map((e) => `  ${e.path}: ${e.message}`).join("\n");
    }
    if (verdict) {
      pass++;
      console.log(`  ✓ ${file}  [${fx.law ?? "—"}]`);
    } else {
      fail++;
      failures.push({ file, detail });
      console.log(`  ✗ ${file}  [${fx.law ?? "—"}]`);
    }
  }
}

console.log(`\nФикстуры: ${pass} прошло, ${fail} провалено.`);
for (const f of failures) console.log(`\n--- ${f.file} ---\n${f.detail}`);

/* ── Секция 2: тесты эталона causal-state-hash/fnv1a64-le-v1 ── */
const { causalStateHash, HASH_SCHEMA_ID } = await import("./causal-hash.mjs");
const clone = (o) => JSON.parse(JSON.stringify(o));
const stateFx = JSON.parse(readFileSync(join(root, "fixtures", "valid", "kernel-state.json"), "utf8")).data;

let hpass = 0, hfail = 0;
function hcheck(name, fn) {
  try {
    const msg = fn();
    hpass++; console.log(`  ✓ hash: ${name}${msg ? " — " + msg : ""}`);
  } catch (e) {
    hfail++; console.log(`  ✗ hash: ${name} — ${e.message}`);
  }
}
console.log(`\nЭталон ${HASH_SCHEMA_ID}:`);

hcheck("закреплённый вектор", () => {
  const pin = JSON.parse(readFileSync(join(root, "fixtures", "hash-vector.json"), "utf8"));
  const got = causalStateHash(stateFx);
  if (got !== pin.expected) throw new Error(`получено ${got}, закреплено ${pin.expected}`);
  return got;
});

hcheck("+0 и −0 различаются", () => {
  const a = clone(stateFx); a.scalars.zeroTest = 0;
  const b = clone(stateFx); b.scalars.zeroTest = -0;
  // JSON не переносит −0 — присваиваем после клонирования:
  b.scalars.zeroTest = -0;
  const ha = causalStateHash(a), hb = causalStateHash(b);
  if (ha === hb) throw new Error("хэши совпали: знак нуля потерян");
});

hcheck("NaN в f64-буфере → E_NAN_STATE", () => {
  const bad = JSON.parse(readFileSync(join(root, "fixtures", "invalid", "state-nan.json"), "utf8")).data;
  try { causalStateHash(bad); } catch (e) {
    if (e.code === "E_NAN_STATE") return;
    throw new Error(`ожидался E_NAN_STATE, получен ${e.code}`);
  }
  throw new Error("NaN не был отклонён");
});

hcheck("NaN в скаляре → E_NAN_STATE", () => {
  const a = clone(stateFx); a.scalars.bad = NaN;
  try { causalStateHash(a); } catch (e) {
    if (e.code === "E_NAN_STATE") return;
    throw new Error(`ожидался E_NAN_STATE, получен ${e.code}`);
  }
  throw new Error("NaN не был отклонён");
});

hcheck("хэш не зависит от порядка вставки буферов/ключей", () => {
  const reordered = clone(stateFx);
  const names = Object.keys(reordered.buffers).reverse();
  const shuffled = {};
  for (const n of names) shuffled[n] = reordered.buffers[n];
  reordered.buffers = shuffled;
  reordered.scalars = Object.fromEntries(Object.entries(reordered.scalars).reverse());
  if (causalStateHash(reordered) !== causalStateHash(stateFx)) {
    throw new Error("хэш зависит от порядка вставки — сортировка сломана");
  }
});

hcheck("причинный u32-курсор входит в хэш", () => {
  const a = clone(stateFx);
  // allocCursor [4,4] → [5,4]: один дискретный причинный элемент
  const buf = Buffer.from(a.buffers.allocCursor.data, "base64");
  buf.writeUInt32LE(5, 0);
  a.buffers.allocCursor.data = buf.toString("base64");
  if (causalStateHash(a) === causalStateHash(stateFx)) {
    throw new Error("изменение причинного u32 не изменило хэш");
  }
});

hcheck("реклассификация буфера меняет идентичность", () => {
  const a = clone(stateFx);
  a.buffers.aliveMask.numericClass = "continuous"; // (схемно это отдельно отловится, здесь — свойство хэша)
  if (causalStateHash(a) === causalStateHash(stateFx)) {
    throw new Error("numericClass не участвует в хэше");
  }
});

console.log(`\nХэш-тесты: ${hpass} прошло, ${hfail} провалено.`);
console.log(`\nИтог: ${pass + hpass} прошло, ${fail + hfail} провалено.`);
process.exit(fail + hfail === 0 ? 0 : 1);
