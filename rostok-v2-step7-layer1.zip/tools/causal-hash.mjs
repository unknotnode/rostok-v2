/**
 * causal-hash.mjs — эталонная реализация causal-state-hash/fnv1a64-le-v1.
 *
 * Канонизация зафиксирована в kernel-abi-2.md §5a. Любое изменение здесь —
 * новый идентификатор канонизации, иначе идентичность экспериментов
 * изменится молча. Закреплённый тест-вектор: fixtures/hash-vector.json.
 */

export const HASH_SCHEMA_ID = "causal-state-hash/fnv1a64-le-v1";

const DTYPE_SIZE = { f64: 8, u8: 1, u16: 2, u32: 4 };
const FNV_OFFSET = 0xcbf29ce484222325n;
const FNV_PRIME = 0x100000001b3n;
const MASK64 = 0xffffffffffffffffn;

export class StateError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}

/* байтовая сортировка UTF-8 (для ASCII-имён совпадает с побайтовой) */
function byteSort(keys) {
  const enc = new TextEncoder();
  return [...keys].sort((a, b) => {
    const A = enc.encode(a), B = enc.encode(b);
    const n = Math.min(A.length, B.length);
    for (let i = 0; i < n; i++) if (A[i] !== B[i]) return A[i] - B[i];
    return A.length - B.length;
  });
}

class ByteStream {
  constructor() { this.chunks = []; }
  raw(u8) { this.chunks.push(u8); }
  u32(n) {
    const b = new Uint8Array(4);
    new DataView(b.buffer).setUint32(0, n >>> 0, true); // little-endian
    this.raw(b);
  }
  u8(n) { this.raw(Uint8Array.of(n & 0xff)); }
  str(s) {
    const b = new TextEncoder().encode(s);
    this.u32(b.length);
    this.raw(b);
  }
  f64(x) {
    const b = new Uint8Array(8);
    new DataView(b.buffer).setFloat64(0, x, true); // LE, биты как есть: ±0 различимы
    this.raw(b);
  }
  bytes() {
    const total = this.chunks.reduce((s, c) => s + c.length, 0);
    const out = new Uint8Array(total);
    let o = 0;
    for (const c of this.chunks) { out.set(c, o); o += c.length; }
    return out;
  }
}

function fnv1a64(bytes) {
  let h = FNV_OFFSET;
  for (const b of bytes) {
    h ^= BigInt(b);
    h = (h * FNV_PRIME) & MASK64;
  }
  return h.toString(16).padStart(16, "0");
}

function decodeBase64(s) {
  // Node и браузер: без зависимостей.
  if (typeof Buffer !== "undefined") {
    const buf = Buffer.from(s, "base64");
    return new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength).slice();
  }
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function scanNaNf64(raw, where, allowNaN) {
  if (allowNaN) return;
  // Явное little-endian чтение: эталон не зависит от порядка байтов CPU.
  const view = new DataView(raw.buffer, raw.byteOffset, raw.byteLength);
  for (let offset = 0, index = 0; offset + 8 <= raw.byteLength; offset += 8, index++) {
    if (Number.isNaN(view.getFloat64(offset, true))) {
      throw new StateError("E_NAN_STATE", `${where}[${index}]: NaN в причинном состоянии (схема ядра не разрешила NaN)`);
    }
  }
}

/* Правка 2: канонические целочисленные представления. */
const CANONICAL_DECIMAL = /^(0|[1-9][0-9]*)$/;

function assertCanonicalRngValue(name, v) {
  if (typeof v !== "string" || !CANONICAL_DECIMAL.test(v)) {
    throw new StateError("E_STATE_FORMAT",
      `rng.streams.${name}: состояние RNG — только каноническая десятичная строка (без +, ведущих нулей и экспоненты), получено ${JSON.stringify(v)}`);
  }
}

function assertCanonicalCount(where, v) {
  if (!Number.isSafeInteger(v) || v < 0) {
    throw new StateError("E_STATE_FORMAT",
      `${where}: целое в диапазоне 0…${Number.MAX_SAFE_INTEGER}, получено ${JSON.stringify(v)}`);
  }
}

/**
 * causalStateHash(state, { allowNaN = false }) → 16 hex.
 * state — объект по schema/kernel-state.schema.json (уже валидированный).
 */
export function causalStateHash(state, opts = {}) {
  const allowNaN = opts.allowNaN === true;
  const s = new ByteStream();

  // 2. фиксированный порядок полей
  s.str(HASH_SCHEMA_ID);
  s.str(state.abiVersion);
  s.str(state.kernelName);
  s.str(state.kernelVersion);
  s.str(state.stateFormat);
  assertCanonicalCount("tick", state.tick);
  s.str("tick");
  s.str(String(state.tick));

  // 3. rng — сортировка имён
  s.str("rng");
  const streams = state.rng?.streams ?? {};
  const streamNames = byteSort(Object.keys(streams));
  s.u32(streamNames.length);
  for (const name of streamNames) {
    assertCanonicalRngValue(name, streams[name]);
    s.str(name);
    s.str(String(streams[name]));
  }

  // 4. scalars — сортировка ключей, сырые биты f64
  s.str("scalars");
  const scalars = state.scalars ?? {};
  const scalarKeys = byteSort(Object.keys(scalars));
  s.u32(scalarKeys.length);
  for (const k of scalarKeys) {
    const v = scalars[k];
    if (Number.isNaN(v) && !allowNaN) {
      throw new StateError("E_NAN_STATE", `scalars.${k}: NaN в причинном состоянии`);
    }
    s.str(k);
    s.f64(v);
  }

  // 5. cursors — сортировка ключей, десятичная запись
  s.str("cursors");
  const cursors = state.cursors ?? {};
  const cursorKeys = byteSort(Object.keys(cursors));
  s.u32(cursorKeys.length);
  for (const k of cursorKeys) {
    assertCanonicalCount(`cursors.${k}`, cursors[k]);
    s.str(k);
    s.str(String(cursors[k]));
  }

  // 6. buffers — сортировка имён; dtype, numericClass, causal, length, байты
  s.str("buffers");
  const buffers = state.buffers ?? {};
  const bufNames = byteSort(Object.keys(buffers));
  s.u32(bufNames.length);
  for (const name of bufNames) {
    const b = buffers[name];
    const size = DTYPE_SIZE[b.dtype];
    if (size === undefined) throw new StateError("E_STATE_FORMAT", `${name}: неизвестный dtype ${b.dtype}`);
    const raw = decodeBase64(b.data);
    if (raw.length !== b.length * size) {
      throw new StateError("E_STATE_FORMAT", `${name}: byteLength ${raw.length} ≠ length ${b.length} × ${size} байт`);
    }
    if (b.dtype === "f64") scanNaNf64(raw, name, allowNaN);
    s.str(name);
    s.str(b.dtype);
    s.str(b.numericClass);
    s.u8(b.causal === true ? 1 : 0);
    s.u32(b.length);
    s.u32(raw.length);
    s.raw(raw);
  }

  return fnv1a64(s.bytes());
}
