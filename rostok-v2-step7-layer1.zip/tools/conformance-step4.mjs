/**
 * conformance-step4.mjs — исполняемый гейт шага 4 (протокол + архив).
 * Границы 1–12 приёмки шага 3.
 */
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { ReferenceRelaxationKernel } from "../src/kernels/reference-relaxation.mjs";
import { WorkerHost } from "../src/host/worker-host.mjs";
import { SnapshotPool } from "../src/snapshot/pool.mjs";
import { SERIES_VIEW_BYTES } from "../src/snapshot/encode.mjs";
import { ObserverRunner } from "../src/observe/runner.mjs";
import { SeriesStatsObserver } from "../src/observe/series-stats.mjs";
import { ExperimentArchive, InMemoryDriver, archiveSink, ArchiveConflictError } from "../src/archive/archive.mjs";
import { contentHash, canonicalBytes, archiveValue, ArchiveValueError } from "../src/lib/canonical.mjs";
import { sha256Utf8 } from "../src/lib/sha256.mjs";
import { causalStateHash } from "./causal-hash.mjs";
import { validate } from "./validate.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const schema = (n) => JSON.parse(readFileSync(join(root, "protocol", "schema", `${n}.schema.json`), "utf8"));
const ENTRY = new URL("../src/host/worker-entry.mjs", import.meta.url);
const CONFIG = { seed: 8842107, params: { drive: 1.0 } };
const clone = (o) => JSON.parse(JSON.stringify(o));
const settle = () => new Promise((r) => setImmediate(r));

let pass = 0, fail = 0;
async function check(name, fn) {
  try { const msg = await fn(); pass++; console.log(`  ✓ ${name}${msg ? " — " + msg : ""}`); }
  catch (e) { fail++; console.log(`  ✗ ${name} — ${e.message}`); }
}
const assert = (cond, msg) => { if (!cond) throw new Error(msg); };

function buildProtocol(stats) {
  return {
    protocol: "rost0k-experiment/2",
    id: "exp-step4-gate-001",
    createdAt: "2026-07-16T00:00:00Z",
    kernel: { name: "reference-relaxation", version: "1.0.0", abiVersion: "kernel-abi/2", stateFormat: "reference-relaxation-state/1" },
    runtime: { version: "0.4.0" },
    manifest: {
      modules: [{ id: "analyzer.series-stats", version: "1.0.0", enabled: true, cadence: 5, params: archiveValue(stats.descriptor.parameters) }],
      snapshotTransport: { mode: "ring", poolSize: 3, cadence: 5 },
    },
    seed: { master: CONFIG.seed },
    commands: [],
    detectors: [{
      id: "analyzer.series-stats", version: "1.0.0",
      parameters: archiveValue(stats.descriptor.parameters),
      requiredViews: ["series-view@1"],
      configHash: stats.configHash,
    }],
    preregistered: {
      observables: ["mean", "variance", "l2", "lagCorr канала input"],
      expectations: ["контрольное ядро: статистики стационарны; интерпретаций нет"],
    },
    environment: { platform: "node-worker/v8", float: "f64" },
  };
}

function refHashAfter(ticks) {
  const k = new ReferenceRelaxationKernel({ hashFn: causalStateHash });
  k.initialize(clone(CONFIG)); k.step(ticks);
  return causalStateHash(k.checkpoint());
}
const REF200 = refHashAfter(200);

console.log("Протокол и идентичность (п.1–3, 6):");

let archiveA = null, statsA = null;

await check("протокол валиден по схеме, замораживается при открытии, protocolHash стабилен", async () => {
  statsA = new SeriesStatsObserver();
  const doc = buildProtocol(statsA);
  const v = validate(schema("experiment-protocol"), doc, "experiment-protocol");
  assert(v.ok, v.errors.map((e) => `${e.path}: ${e.message}`).join("; "));
  archiveA = new ExperimentArchive(new InMemoryDriver(), { validateProtocol: (d) => validate(schema("experiment-protocol"), d, "experiment-protocol") });
  const { documentHash: h1 } = await archiveA.openExperiment(doc);
  // канонизация: перестановка ключей не меняет хэш (честный клон с
  // ОБРАТНЫМ порядком вставки ключей на каждом уровне)
  const reorder = (v) => {
    if (v === null || typeof v !== "object") return v;
    if (Array.isArray(v)) return v.map(reorder);
    const out = {};
    for (const k of Object.keys(v).reverse()) out[k] = reorder(v[k]);
    return out;
  };
  const reordered = reorder(doc);
  assert(JSON.stringify(reordered) !== JSON.stringify(doc), "предусловие: порядок ключей реально изменён");
  assert(contentHash(doc) === contentHash(reordered) && h1.length === 64, "канонизация зависит от порядка ключей");
  try { archiveA.protocol.seed.master = 1; } catch { /* заморожено */ }
  assert(archiveA.protocol.seed.master === CONFIG.seed, "протокол мутируем после открытия");
  return h1;
});

await check("полный прогон: физика → снимки → claims → архив; траектория бит-идентична эталону", async () => {
  const host = new WorkerHost(ENTRY);
  await host.initialize(clone(CONFIG));
  const pool = new SnapshotPool(host, { poolSize: 3, byteLength: SERIES_VIEW_BYTES });
  await host.snapshotStats();
  const runner = new ObserverRunner(pool, { viewId: "series-view@1", sink: archiveSink(archiveA), maxRetained: 8 });
  runner.register(statsA);
  for (let done = 0; done < 200; done += 10) {
    await host.stepWithSnapshots(10, 5);
    await settle();
    await runner.pump();
  }
  const hash = causalStateHash(await host.checkpoint());
  await archiveA.appendCheckpoint("final", await host.checkpoint());
  await host.dispose();
  assert(hash === REF200, "траектория с архивом разошлась");
  assert(runner.claimCount === 40, `claims: ${runner.claimCount}`);
  assert(runner.claims.length === 8, `кольцо памяти: ${runner.claims.length} ≠ maxRetained=8 (п.11)`);
  const claims = (await archiveA.records()).filter((r) => r.kind === "claim");
  assert(claims.length === 40, `в архиве ${claims.length} claims из 40`);
  return `40 claims в архиве, в памяти кольцо из 8`;
});

await check("п.2/12(идентичность): runIdentityHash включает журнал команд", async () => {
  // Раздельные архивы одного протокола: разные команды → разные идентичности
  const mk = async (cmds) => {
    const a = new ExperimentArchive(new InMemoryDriver());
    await a.openExperiment(buildProtocol(new SeriesStatsObserver()));
    for (const c of cmds) await a.appendCommand(c);
    return a.finalize({ verdict: "ok" });
  };
  const h1 = await mk([{ tick: 100, cmd: "noop" }]);
  const h2 = await mk([{ tick: 100, cmd: "noop" }]);
  const h3 = await mk([{ tick: 100, cmd: "noop" }, { tick: 150, cmd: "noop" }]);
  assert(h1 === h2, "одинаковые протокол+команды дали разные идентичности");
  assert(h1 !== h3, "журнал команд не вошёл в идентичность запуска");
});

console.log("\nЦелостность записей (п.5–7):");

await check("п.7: повторная запись того же id — идемпотентна при том же содержимом, конфликт при ином", async () => {
  const a = new ExperimentArchive(new InMemoryDriver());
  await a.openExperiment(buildProtocol(new SeriesStatsObserver()));
  const fact = { tier: "fact", type: "fact.command.apply", tick: 7, seq: 1, payload: { cmd: "noop" } };
  const r1 = await a.appendFact(fact);
  const r2 = await a.appendFact(fact); // идемпотентно
  assert(r1.contentHash === r2.contentHash, "идемпотентная запись изменила хэш");
  try {
    await a._append("fact", r1.id, { ...fact, payload: { cmd: "hacked" } }, { tick: 7, seq: 1 });
    throw new Error("конфликт не обнаружен");
  } catch (e) {
    assert(e instanceof ArchiveConflictError, `ожидался E_ARCHIVE_CONFLICT, получен ${e.code}`);
  }
});

await check("п.5: архив хранит значения — мутация оригинала после записи безвредна", async () => {
  const a = new ExperimentArchive(new InMemoryDriver());
  await a.openExperiment(buildProtocol(new SeriesStatsObserver()));
  const fact = { tier: "fact", type: "fact.element.birth", tick: 3, seq: 0, payload: { element: 5 } };
  const rec = await a.appendFact(fact);
  fact.payload.element = 999; // живая ссылка мутируется ПОСЛЕ записи
  const stored = (await a.records()).find((r) => r.id === rec.id);
  assert(stored.body.payload.element === 5, "архив хранит живую ссылку, а не значение");
  try { stored.body.payload.element = 777; } catch { /* заморожено */ }
  assert(stored.body.payload.element === 5, "архивная запись мутируема");
});

console.log("\nОтказ записи и отрицательные результаты (п.8–9):");

await check("п.9: отказ драйвера → infra-failure, физика бит-идентична", async () => {
  class FailingDriver extends InMemoryDriver {
    async putIfAbsent(record, canonical) {
      if (record.kind === "claim") { const e = new Error("диск переполнен (модель)"); e.code = "E_IO"; throw e; }
      return super.putIfAbsent(record, canonical);
    }
  }
  const a = new ExperimentArchive(new FailingDriver());
  const stats = new SeriesStatsObserver();
  await a.openExperiment(buildProtocol(stats));
  const host = new WorkerHost(ENTRY);
  await host.initialize(clone(CONFIG));
  const pool = new SnapshotPool(host, { poolSize: 3, byteLength: SERIES_VIEW_BYTES });
  await host.snapshotStats();
  const runner = new ObserverRunner(pool, { viewId: "series-view@1", sink: archiveSink(a) });
  runner.register(stats);
  for (let done = 0; done < 200; done += 10) {
    await host.stepWithSnapshots(10, 5); await settle(); await runner.pump();
  }
  const hash = causalStateHash(await host.checkpoint());
  await host.dispose();
  assert(hash === REF200, "отказ архива изменил физическую траекторию");
  assert(a.infraFailureCount === 40, `infra-failures: ${a.infraFailureCount} из 40`);
  const infra = (await a.records()).filter((r) => r.kind === "infra-failure");
  assert(infra.length === 40, "инфраструктурные сбои не зарегистрированы записями");
  return `40 отказов записи, 40 infra-failure, хэш ядра совпал`;
});

await check("п.8: отсутствие claims архивируется наравне с положительным результатом", async () => {
  const a = new ExperimentArchive(new InMemoryDriver());
  await a.openExperiment(buildProtocol(new SeriesStatsObserver()));
  const runHash = await a.finalize({ verdict: "no-claims", note: "анализатор был отключён; отрицательный результат — данные" });
  const res = (await a.records()).find((r) => r.kind === "result");
  assert(res && res.body.verdict === "no-claims" && res.body.runIdentityHash === runHash, "отрицательный результат не архивирован");
});

console.log("\nReplay (п.12):");

await check("replay воспроизводит порядок facts/claims/failures/commands по (tick, seq) без физики", async () => {
  const a = new ExperimentArchive(new InMemoryDriver());
  await a.openExperiment(buildProtocol(new SeriesStatsObserver()));
  // Синтетический перемешанный ввод: архив обязан упорядочить сам.
  await a.appendClaim({ tier: "claim", type: "claim.measurement.series-stats", tick: 20, payload: { seq: 2 }, provenance: { detectorId: "analyzer.series-stats" } });
  await a.appendFact({ tier: "fact", type: "fact.command.apply", tick: 5, seq: 1, payload: {} });
  await a.appendCommand({ tick: 5, cmd: "set-param" });
  await a.appendFailure({ tier: "claim", type: "claim.observer.failure", tick: 20, payload: { seq: 1 }, provenance: { detectorId: "analyzer.crash-test" } });
  await a.appendFact({ tier: "fact", type: "fact.element.birth", tick: 10, seq: 0, payload: {} });
  const rows = await a.replay();
  const got = rows.map((r) => `${r.kind}@${r.order.tick}.${r.order.seq}`);
  const want = ["fact@5.1", "command@5.1", "fact@10.0", "claim@20.0", "failure@20.1"];
  assert(JSON.stringify(got) === JSON.stringify(want), `порядок: ${got.join(", ")}`);
});

console.log("\nПоправки приёмки шага 4 (пять законов):");

const expectValueError = (fn, what) => {
  try { fn(); } catch (e) { assert(e.code === "E_ARCHIVE_VALUE", `${what}: ожидался E_ARCHIVE_VALUE, получен ${e.code}`); return; }
  throw new Error(`${what}: молча принято`);
};

await check("П1: ArchiveValue отклоняет всё, что JSON.stringify нормализует молча", () => {
  expectValueError(() => archiveValue({ a: NaN }), "NaN");
  expectValueError(() => archiveValue({ a: Infinity }), "Infinity");
  expectValueError(() => archiveValue({ a: -Infinity }), "-Infinity");
  expectValueError(() => archiveValue({ a: undefined }), "undefined в объекте");
  expectValueError(() => archiveValue([undefined]), "[undefined]");
  expectValueError(() => archiveValue({ a: () => 0 }), "функция");
  expectValueError(() => archiveValue({ a: 1n }), "BigInt");
  expectValueError(() => archiveValue({ a: new Date() }), "Date (toJSON)");
  expectValueError(() => archiveValue({ a: new Map() }), "Map");
  expectValueError(() => archiveValue({ a: { toJSON: () => "подмена" } }), "объект с toJSON-функцией");
  expectValueError(() => archiveValue({ a: new Float64Array(4) }), "TypedArray без дескриптора");
  const cyc = {}; cyc.self = cyc;
  expectValueError(() => archiveValue(cyc), "цикл");
  // бинарный дескриптор — легален
  const d = archiveValue({ dtype: "f64", encoding: "base64", byteOrder: "little-endian", length: 0, data: "" });
  assert(d.dtype === "f64", "нормативный дескриптор отклонён");
});

await check("П1: −0 сохраняется — contentHash(−0) ≠ contentHash(+0); [null] ≠ отклонённый [undefined]", () => {
  assert(canonicalBytes({ x: -0 }) === '{"x":-0}', `канон −0: ${canonicalBytes({ x: -0 })}`);
  assert(contentHash({ x: -0 }) !== contentHash({ x: 0 }), "знак нуля схлопнут");
  const roundtrip = JSON.parse(canonicalBytes({ x: -0 }));
  assert(Object.is(roundtrip.x, -0), "JSON.parse не вернул −0");
  assert(contentHash({ a: [null] }).length === 64, "[null] легален");
});

await check("П2: contentHash — SHA-256 канонических байтов (вектор FIPS + совпадение с ручным)", () => {
  assert(sha256Utf8("abc") === "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", "вектор FIPS не сошёлся");
  const v = { b: 1, a: [2, -0] };
  assert(contentHash(v) === sha256Utf8(canonicalBytes(v)), "contentHash ≠ sha256(canonical)");
});

await check("П3: журнал команд fail-closed — недоступный журнал ⇒ команда НЕ применяется", async () => {
  class DeadJournalDriver extends InMemoryDriver {
    async putIfAbsent(record, canonical) {
      if (record.kind === "command") { const e = new Error("журнал недоступен"); e.code = "E_IO"; throw e; }
      return super.putIfAbsent(record, canonical);
    }
  }
  const a = new ExperimentArchive(new DeadJournalDriver());
  await a.openExperiment(buildProtocol(new SeriesStatsObserver()));
  let applied = false;
  const applyCommand = () => { applied = true; };
  try {
    await a.appendCommand({ tick: 100, cmd: "set-param" });
    applyCommand(); // сюда дойти нельзя
    throw new Error("команда прошла при мёртвом журнале");
  } catch (e) {
    assert(e.code === "E_COMMAND_JOURNAL", `ожидался E_COMMAND_JOURNAL, получен ${e.code}`);
  }
  assert(applied === false, "команда применена без записи в журнал");
  // здоровый журнал: порядок запись → применение → результат-связка
  const b = new ExperimentArchive(new InMemoryDriver());
  await b.openExperiment(buildProtocol(new SeriesStatsObserver()));
  const log = [];
  const { commandId } = await b.appendCommand({ tick: 100, cmd: "set-param" });
  log.push("journaled");
  log.push("applied"); // применение строго после подтверждения записи
  await b.appendCommandResult(commandId, { status: "applied", tick: 100 });
  const kinds = (await b.records()).map((r) => r.kind);
  assert(kinds.includes("command") && kinds.includes("command-result"), "связка команда→результат не записана");
  assert(log.join(",") === "journaled,applied", "порядок нарушен");
});

await check("П4: атомарный putIfAbsent — 50 конкурентных записей одного id", async () => {
  class DelayedDriver extends InMemoryDriver {
    async putIfAbsent(record, canonical) {
      await new Promise((r) => setTimeout(r, Math.floor(Math.random() * 3)));
      return super.putIfAbsent(record, canonical); // атомарное ядро без await
    }
  }
  const a = new ExperimentArchive(new DelayedDriver());
  await a.openExperiment(buildProtocol(new SeriesStatsObserver()));
  const same = { tier: "fact", type: "fact.command.apply", tick: 9, seq: 4, payload: { v: 1 } };
  const results = await Promise.allSettled(Array.from({ length: 50 }, (_, i) =>
    a._append("fact", "fact:race", i % 2 === 0 ? same : { ...same, payload: { v: 2 } }, { tick: 9, seq: 4 })));
  const conflicts = results.filter((r) => r.status === "rejected" && r.reason.code === "E_ARCHIVE_CONFLICT").length;
  const ok = results.filter((r) => r.status === "fulfilled").length;
  const stored = (await a.records()).filter((r) => r.id === "fact:race");
  assert(stored.length === 1, `в архиве ${stored.length} записей fact:race`);
  assert(ok + conflicts === 50 && conflicts >= 24, `исходы: ok=${ok}, conflicts=${conflicts}`);
  return `одна запись, ${ok} идемпотентных/вставок, ${conflicts} конфликтов`;
});

await check("П5: жизненный цикл — после finalize причинные записи запрещены, revision разрешена", async () => {
  const a = new ExperimentArchive(new InMemoryDriver());
  await a.openExperiment(buildProtocol(new SeriesStatsObserver()));
  const run = await a.finalize({ verdict: "ok" });
  for (const [what, fn] of [
    ["appendFact", () => a.appendFact({ tick: 1, seq: 0, payload: {} })],
    ["appendCommand", () => a.appendCommand({ tick: 1, cmd: "noop" })],
    ["appendClaim", () => a.appendClaim({ tick: 1, payload: {}, provenance: {} })],
    ["appendCheckpoint", () => a.appendCheckpoint("x", { tick: 1 })],
    ["finalize", () => a.finalize({ verdict: "again" })],
  ]) {
    try { await fn(); throw new Error(`${what} прошёл после finalize`); }
    catch (e) { assert(e.code === "E_ARCHIVE_STATE", `${what}: ожидался E_ARCHIVE_STATE, получен ${e.code}`); }
  }
  const rev = await a.appendRevision({ note: "post-analysis" });
  assert(rev.body.parentRunIdentityHash === run, "revision без родительской идентичности");
  a.dispose();
  try { await a.appendRevision({ note: "после закрытия" }); throw new Error("revision после dispose"); }
  catch (e) { assert(e.code === "E_ARCHIVE_STATE", `после dispose: ${e.code}`); }
});

await check("П5: три идентичности — createdAt/id меняют documentHash, но не experimentIdentityHash", async () => {
  const s = new SeriesStatsObserver();
  const d1 = buildProtocol(s);
  const d2 = { ...buildProtocol(s), id: "exp-step4-gate-002", createdAt: "2026-07-16T09:59:59Z" };
  const a1 = new ExperimentArchive(new InMemoryDriver());
  const a2 = new ExperimentArchive(new InMemoryDriver());
  const h1 = await a1.openExperiment(d1);
  const h2 = await a2.openExperiment(d2);
  assert(h1.documentHash !== h2.documentHash, "documentHash не различил документы");
  assert(h1.experimentIdentityHash === h2.experimentIdentityHash, "семантическая идентичность зависит от id/createdAt");
});

await check("неблок.: идемпотентная повторная доставка claim (стабильный eventId из провенанса)", async () => {
  const a = new ExperimentArchive(new InMemoryDriver());
  await a.openExperiment(buildProtocol(new SeriesStatsObserver()));
  const claim = { tier: "claim", type: "claim.measurement.series-stats", tick: 15,
    payload: { mean: 1 }, provenance: { detectorId: "analyzer.series-stats", configHash: "a".repeat(64), snapshotTick: 15 } };
  await a.appendClaim(claim);
  await a.appendClaim(JSON.parse(JSON.stringify(claim))); // повторная доставка
  const claims = (await a.records()).filter((r) => r.kind === "claim");
  assert(claims.length === 1, `повторная доставка создала ${claims.length} записи`);
  // тот же eventId с ИНЫМ содержимым — конфликт → infra-failure (fail-open путь)
  await a.appendClaim({ ...claim, payload: { mean: 2 } });
  assert(a.infraFailureCount === 1, "конфликт содержимого не зарегистрирован");
});

console.log("\nКрая канонизации и жизненного цикла (К1–К4):");

await check("К1: отказ записи протокола — архив остаётся CREATED и открывается повторно", async () => {
  class FlakyDriver extends InMemoryDriver {
    constructor() { super(); this.dead = true; }
    async putIfAbsent(record, canonical) {
      if (this.dead && record.kind === "protocol") { const e = new Error("backend недоступен"); e.code = "E_IO"; throw e; }
      return super.putIfAbsent(record, canonical);
    }
  }
  const drv = new FlakyDriver();
  const a = new ExperimentArchive(drv);
  const doc = buildProtocol(new SeriesStatsObserver());
  try { await a.openExperiment(doc); throw new Error("открылся при мёртвом драйвере"); }
  catch (e) { assert(e.code === "E_IO" || e.code === "E_ARCHIVE_CONFLICT", `код: ${e.code}`); }
  assert(a.state === "created" && a.protocol === null && a.hashes === null,
    `fail-closed старт нарушен: state=${a.state}`);
  try { await a.appendFact({ tick: 1, seq: 0, payload: {} }); throw new Error("append прошёл без открытия"); }
  catch (e) { assert(e.code === "E_ARCHIVE_STATE", `append до открытия: ${e.code}`); }
  drv.dead = false; // backend ожил — повторное открытие того же экземпляра
  const h = await a.openExperiment(doc);
  assert(a.state === "open" && h.documentHash.length === 64, "повторное открытие не удалось");
});

await check("К2: конкурентные команды — commandSeq монотонен, номера уникальны, пропуски честны", async () => {
  class SelectiveDriver extends InMemoryDriver {
    async putIfAbsent(record, canonical) {
      if (record.kind === "command") {
        await new Promise((r) => setTimeout(r, Math.floor(Math.random() * 3)));
        if (record.body.cmd === "bad") { const e = new Error("отказ журнала"); e.code = "E_IO"; throw e; }
      }
      return super.putIfAbsent(record, canonical);
    }
  }
  const a = new ExperimentArchive(new SelectiveDriver());
  await a.openExperiment(buildProtocol(new SeriesStatsObserver()));
  const cmds = ["ok", "bad", "ok", "bad", "ok", "ok", "bad", "ok"].map((c, i) =>
    a.appendCommand({ tick: 100 + i, cmd: c }).then((r) => ({ ok: true, seq: r.seq }), (e) => ({ ok: false, code: e.code })));
  const results = await Promise.all(cmds);
  const okSeqs = results.filter((r) => r.ok).map((r) => r.seq);
  const fails = results.filter((r) => !r.ok);
  assert(fails.length === 3 && fails.every((f) => f.code === "E_COMMAND_JOURNAL"), "отказы не fail-closed");
  assert(new Set(okSeqs).size === okSeqs.length, "номера команд переиспользованы");
  const sorted = [...okSeqs].sort((x, y) => x - y);
  assert(JSON.stringify(okSeqs) === JSON.stringify(sorted), "последовательность немонотонна");
  // пропуски от отказов существуют, но повторное использование невозможно:
  const next = await a.appendCommand({ tick: 200, cmd: "ok" });
  assert(next.seq === 9, `следующий seq ${next.seq}, ожидался 9 (8 попыток + 1)`);
  const stored = (await a.records()).filter((r) => r.kind === "command");
  assert(stored.length === 6, `в журнале ${stored.length} команд из 6 успешных`);
  return `успешных 5+1, отказов 3, пропуски сохранены`;
});

await check("К3: symbol-ключ, неперечислимое, getter, setter → E_ARCHIVE_VALUE; __proto__ — обычный ключ", () => {
  expectValueError(() => archiveValue({ [Symbol("s")]: 1, a: 2 }), "symbol-ключ");
  const nonEnum = {}; Object.defineProperty(nonEnum, "hidden", { value: 1, enumerable: false });
  expectValueError(() => archiveValue(nonEnum), "неперечислимое");
  const getter = {}; Object.defineProperty(getter, "g", { get: () => Math.random(), enumerable: true });
  expectValueError(() => archiveValue(getter), "getter");
  const setter = {}; Object.defineProperty(setter, "s", { set: () => {}, enumerable: true });
  expectValueError(() => archiveValue(setter), "setter");
  // __proto__ как данные: JSON.parse создаёт собственное свойство
  const src = JSON.parse('{"__proto__": 7, "a": 1}');
  const out = archiveValue(src);
  assert(Object.getPrototypeOf(out) === null, "копия не на null-прототипе");
  assert(Object.keys(out).includes("__proto__") && out["__proto__"] === 7, "__proto__ потерян как данные");
  assert(canonicalBytes(src).includes('"__proto__":7'), "__proto__ не сериализован");
  const rt = JSON.parse(canonicalBytes(src));
  assert(rt["__proto__"] === 7 && rt.a === 1, "round-trip __proto__ сломан");
});

await check("К4: непарные суррогатные ключи — полный порядок, хэш не зависит от порядка вставки", () => {
  const mk = (order) => {
    const o = Object.create(null);
    if (order === "ab") { o["\ud800"] = 1; o["\ud801"] = 2; }
    else { o["\ud801"] = 2; o["\ud800"] = 1; }
    return o;
  };
  const A = mk("ab"), B = mk("ba");
  assert(Object.keys(A)[0] !== Object.keys(B)[0], "предусловие: порядок вставки реально различен");
  assert(canonicalBytes(A) === canonicalBytes(B), "канонические байты зависят от порядка вставки суррогатных ключей");
  assert(contentHash(A) === contentHash(B), "contentHash разошёлся");
  // и сами ключи различимы (не схлопнуты в U+FFFD):
  assert(contentHash({ ["\ud800"]: 1 }) !== contentHash({ ["\ud801"]: 1 }), "суррогаты схлопнуты");
});

await check("О5/доп.8: кросс-языковые векторы числовой канонизации — пересчёт из raw IEEE-754 hex", () => {
  const fx = JSON.parse(readFileSync(join(root, "fixtures", "numeric-canon-vectors.json"), "utf8"));
  assert(fx.vectors.length >= 19, "векторов меньше заявленного");
  for (const v of fx.vectors) {
    const b = new Uint8Array(8);
    for (let i = 0; i < 8; i++) b[i] = parseInt(v.ieee754Hex.slice(i * 2, i * 2 + 2), 16);
    const num = new DataView(b.buffer).getFloat64(0, false);
    const canon = canonicalBytes(num);
    assert(canon === v.canonical, `${v.name}: канон "${canon}" ≠ закреплённого "${v.canonical}"`);
    assert(sha256Utf8(canon) === v.sha256, `${v.name}: SHA-256 разошёлся`);
    // бит-точность обратного пути (включая −0):
    const b2 = new Uint8Array(8);
    new DataView(b2.buffer).setFloat64(0, JSON.parse(canon === "-0" ? "-0" : canon), false);
    assert([...b2].map((x) => x.toString(16).padStart(2, "0")).join("") === v.ieee754Hex,
      `${v.name}: hex round-trip сломан`);
  }
  return `${fx.vectors.length} векторов, включая ±0, субнормаль, оба края e-порога, 1e16`;
});

console.log(`\nИтог шага 4: ${pass} прошло, ${fail} провалено.`);
process.exit(fail === 0 ? 0 : 1);
