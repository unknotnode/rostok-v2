/**
 * conformance-step3.mjs — исполняемый гейт шага 3.
 * Ключевой критерий: присутствие, отсутствие, сбой и разная частота
 * первого анализатора не меняют ни один бит причинной траектории, а
 * ownership-пул не теряет буферы даже при исключении анализатора.
 * Плюс проверки долгов Т2–Т4 приёмки шага 2.
 */
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { ReferenceRelaxationKernel } from "../src/kernels/reference-relaxation.mjs";
import { WorkerHost } from "../src/host/worker-host.mjs";
import { SnapshotPool } from "../src/snapshot/pool.mjs";
import { SERIES_VIEW_BYTES } from "../src/snapshot/encode.mjs";
import { ObserverRunner } from "../src/observe/runner.mjs";
import { SeriesStatsObserver, CrashingObserver } from "../src/observe/series-stats.mjs";
import { causalStateHash } from "./causal-hash.mjs";
import { validate } from "./validate.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const schema = (n) => JSON.parse(readFileSync(join(root, "protocol", "schema", `${n}.schema.json`), "utf8"));
const ENTRY = new URL("../src/host/worker-entry.mjs", import.meta.url);
const CONFIG = { seed: 8842107, params: { drive: 1.0 } };
const clone = (o) => JSON.parse(JSON.stringify(o));

let pass = 0, fail = 0;
async function check(name, fn) {
  try { const msg = await fn(); pass++; console.log(`  ✓ ${name}${msg ? " — " + msg : ""}`); }
  catch (e) { fail++; console.log(`  ✗ ${name} — ${e.message}`); }
}
const assert = (cond, msg) => { if (!cond) throw new Error(msg); };
const settle = () => new Promise((r) => setImmediate(r));

function refHashAfter(ticks) {
  const k = new ReferenceRelaxationKernel({ hashFn: causalStateHash });
  k.initialize(clone(CONFIG)); k.step(ticks);
  return causalStateHash(k.checkpoint());
}
const REF200 = refHashAfter(200);

async function runWithObservers(observers, { every = 5, ticks = 200, poolSize = 3 } = {}) {
  const host = new WorkerHost(ENTRY);
  await host.initialize(clone(CONFIG));
  const pool = new SnapshotPool(host, { poolSize, byteLength: SERIES_VIEW_BYTES });
  await host.snapshotStats(); // барьер грантов
  const runner = new ObserverRunner(pool, { viewId: "series-view@1" });
  observers.forEach((o) => runner.register(o));
  let processed = 0;
  for (let done = 0; done < ticks; done += 10) {
    await host.stepWithSnapshots(10, every);
    await settle();
    processed += await runner.pump(); // возврат в try/finally → кольцо живёт
  }
  const hash = causalStateHash(await host.checkpoint());
  const prod = await host.snapshotStats();
  const telemetry = pool.telemetry();
  await host.dispose();
  return { hash, processed, prod, telemetry, runner };
}

console.log("C7 — ключевой критерий (эталон 200 тактов: " + REF200 + "):");

let statsRunA = null;
await check("анализатор ОТСУТСТВУЕТ — контрольная траектория", async () => {
  const r = await runWithObservers([], { every: 5 });
  assert(r.hash === REF200, "траектория без анализатора разошлась");
});

await check("анализатор ВКЛЮЧЁН — бит-идентичная траектория, буферы не теряются", async () => {
  const stats = new SeriesStatsObserver();
  const r = await runWithObservers([stats], { every: 5 });
  r.statsObs = stats;
  statsRunA = r;
  assert(r.hash === REF200, "траектория с анализатором разошлась");
  assert(r.telemetry.inFlight === 0, `inFlight=${r.telemetry.inFlight} после прогона`);
  assert(r.telemetry.delivered === r.telemetry.returned, "delivered ≠ returned");
  assert(r.runner.claims.length === r.processed && r.processed > 0, "не на каждый снимок есть claim");
  return `снимков обработано: ${r.processed}, claims: ${r.runner.claims.length}`;
});

await check("анализатор ПАДАЕТ на каждом снимке — физика бит-идентична, пул не течёт", async () => {
  const crash = new CrashingObserver();
  const r = await runWithObservers([crash], { every: 5 });
  assert(r.hash === REF200, "траектория при падающем анализаторе разошлась");
  assert(crash.calls === r.processed && r.processed > 0, "диверсант вызывался не на каждый снимок");
  assert(r.runner.failures.length === r.processed, "не каждое падение учтено как observer failure");
  assert(r.runner.failures[0].provenance.detectorId === "analyzer.crash-test", "провенанс сбоя потерян");
  assert(r.runner.failures[0].type === "claim.observer.failure", "сбой не оформлен событием");
  assert(r.telemetry.inFlight === 0 && r.telemetry.delivered === r.telemetry.returned,
    `утечка буферов: ${JSON.stringify(r.telemetry)}`);
  return `сбоев учтено: ${r.runner.failures.length}, утечек: 0`;
});

await check("падающий + здоровый вместе — здоровый получает ВСЕ снимки, физика бит-идентична", async () => {
  const crash = new CrashingObserver();
  const stats = new SeriesStatsObserver();
  const r = await runWithObservers([crash, stats], { every: 5 });
  assert(r.hash === REF200, "траектория разошлась");
  assert(stats._snapshotsSeen === r.processed, `здоровый видел ${stats._snapshotsSeen} из ${r.processed}`);
  assert(r.runner.claims.length === r.processed, "claims здорового потеряны из-за соседа-диверсанта");
});

await check("разная частота снимков (every=2 и every=25) — та же траектория ядра", async () => {
  const r2 = await runWithObservers([new SeriesStatsObserver()], { every: 2 });
  const r25 = await runWithObservers([new SeriesStatsObserver()], { every: 25 });
  assert(r2.hash === REF200 && r25.hash === REF200, "частота снимков повлияла на ядро");
  assert(r2.processed > r25.processed, "предусловие: частоты реально различны");
  return `обработано ${r2.processed} против ${r25.processed} снимков, хэш один`;
});

console.log("\nClaims наблюдательного контура (п.10):");

await check("каждый claim валиден по схеме event и несёт полный провенанс", () => {
  assert(statsRunA.runner.claims.length > 0, "нет claims для проверки");
  for (const c of statsRunA.runner.claims) {
    const r = validate(schema("event"), c, "event");
    assert(r.ok, r.errors.map((e) => `${e.path}: ${e.message}`).join("; "));
    assert(c.provenance.snapshotTick === c.tick, "snapshotTick ≠ tick");
    assert(typeof c.provenance.configHash === "string" && c.provenance.configHash.length === 64, "configHash отсутствует");
  }
  return `${statsRunA.runner.claims.length} claims валидны`;
});

await check("детерминизм наблюдателя: два независимых прогона дают идентичные payload", async () => {
  const r = await runWithObservers([new SeriesStatsObserver()], { every: 5 });
  assert(JSON.stringify(r.runner.claims) === JSON.stringify(statsRunA.runner.claims),
    "фиксированный порядок редукций нарушен: payload различаются");
});

await check("компенсированная сумма: 1e16 + 1 − 1e16 (наивная сумма теряет единицу)", async () => {
  // Единичная проверка дисциплины Кэхэна на известном злом векторе.
  const { SeriesStatsObserver: S } = await import("../src/observe/series-stats.mjs");
  const obs = new S();
  const evil = new Float64Array(64);
  evil[0] = 1e16; evil[1] = 1; evil[2] = -1e16;
  const view = { length: 64, getInput: (i) => evil[i] };
  const claim = obs.observe(view, { tick: 0, views: ["series-view@1"] });
  let naive = 0; for (const v of evil) naive += v;
  assert(naive !== 1, "предусловие: наивная сумма обязана терять единицу на этом векторе");
  assert(claim.payload.mean === 1 / 64, `mean=${claim.payload.mean}, ожидалось ${1 / 64}`);
});

await check("checkpoint/restore анализатора отдельны от KernelState и продолжают ряд бит-точно", async () => {
  const host = new WorkerHost(ENTRY);
  await host.initialize(clone(CONFIG));
  const pool = new SnapshotPool(host, { poolSize: 3, byteLength: SERIES_VIEW_BYTES });
  await host.snapshotStats();
  const runner = new ObserverRunner(pool, { viewId: "series-view@1" });
  const obs = new SeriesStatsObserver();
  runner.register(obs);
  await host.stepWithSnapshots(50, 10); await settle(); await runner.pump();
  // 5 попыток снимка на кольцо из 3 буферов без промежуточного pump →
  // производятся ровно тики 10/20/30, попытки 40/50 честно падают.
  const obsCp = obs.checkpoint();
  assert(obsCp.detectorId === "analyzer.series-stats" && obsCp.snapshotsSeen === 3,
    `checkpoint наблюдателя неполон: snapshotsSeen=${obsCp.snapshotsSeen}`);
  assert(obsCp.prevTick === 30, `prevTick=${obsCp.prevTick}, ожидался 30`);
  // ветка A: продолжение без прерывания
  await host.stepWithSnapshots(50, 10); await settle(); await runner.pump();
  const claimsA = runner.claims.slice(3).map((c) => JSON.stringify(c.payload));
  // ветка B: свежий наблюдатель, restore, те же снимки (реплей той же траектории)
  const host2 = new WorkerHost(ENTRY);
  await host2.initialize(clone(CONFIG));
  const pool2 = new SnapshotPool(host2, { poolSize: 3, byteLength: SERIES_VIEW_BYTES });
  await host2.snapshotStats();
  const runner2 = new ObserverRunner(pool2, { viewId: "series-view@1" });
  const obs2 = new SeriesStatsObserver();
  runner2.register(obs2);
  await host2.step(50); // догоняем траекторию без наблюдения
  obs2.restore(clone(obsCp));
  await host2.stepWithSnapshots(50, 10); await settle(); await runner2.pump();
  const claimsB = runner2.claims.map((c) => JSON.stringify(c.payload));
  await host.dispose(); await host2.dispose();
  assert(claimsA.length === 3 && claimsB.length === 3, `ветки: ${claimsA.length}/${claimsB.length}`);
  for (let i = 0; i < 3; i++) assert(claimsA[i] === claimsB[i], `payload ${i} разошёлся: restore наблюдателя не бит-точен`);
});

console.log("\nПоправки приёмки шага 3 (O1, 2–4):");

class MutatorObserver {
  constructor() { this.descriptor = { detectorId: "analyzer.mutator", version: "1.0.0", parameters: {} }; this.attempts = 0; }
  observe(view) {
    // Диверсант: пытается испортить всё достижимое. Каждая попытка — в try,
    // цель — коррупция входа соседа, а не собственное падение.
    const tryMut = (fn) => { this.attempts++; try { fn(); } catch { /* заблокировано */ } };
    tryMut(() => { view.getInput = () => -777; });
    tryMut(() => { view.length = 0; });
    tryMut(() => { view.input && view.input.fill(0); });
    tryMut(() => { Object.assign(view, { getHist: () => 0 }); });
    tryMut(() => { const p = Object.getPrototypeOf(view); p && (p.getInput = () => 0); });
    return null;
  }
}

await check("O1: mutator ДО series-stats — payload бит-идентичен контрольному без mutator", async () => {
  const control = statsRunA.runner.claims.map((c) => JSON.stringify(c.payload));
  const m = new MutatorObserver();
  const r = await runWithObservers([m, new SeriesStatsObserver()], { every: 5 });
  assert(r.hash === REF200, "физика задета");
  const got = r.runner.claims.filter((c) => c.type === "claim.measurement.series-stats").map((c) => JSON.stringify(c.payload));
  assert(got.length === control.length, `claims: ${got.length} против ${control.length}`);
  for (let i = 0; i < got.length; i++) assert(got[i] === control[i], `payload ${i} искажён соседом-диверсантом`);
  assert(m.attempts > 0, "предусловие: диверсант реально пытался");
  return `попыток мутации: ${m.attempts}, искажений: 0`;
});

await check("O1: mutator ПОСЛЕ series-stats — тот же результат (порядок регистрации безразличен)", async () => {
  const control = statsRunA.runner.claims.map((c) => JSON.stringify(c.payload));
  const r = await runWithObservers([new SeriesStatsObserver(), new MutatorObserver()], { every: 5 });
  const got = r.runner.claims.filter((c) => c.type === "claim.measurement.series-stats").map((c) => JSON.stringify(c.payload));
  for (let i = 0; i < got.length; i++) assert(got[i] === control[i], `payload ${i} искажён`);
});

await check("поправка 2: claim — значение; мутация descriptor.parameters не меняет опубликованное", () => {
  const c = statsRunA.runner.claims[0];
  const serialized = JSON.stringify(c);
  const hash0 = c.provenance.configHash;
  const obs = statsRunA.observers?.[0];
  // мутируем живой descriptor (замороженные параметры отклонят запись — и это тоже защита)
  try { statsRunA.statsObs.descriptor.parameters.lagSnapshots = 999; } catch { /* заморожено */ }
  try { statsRunA.statsObs.descriptor.parameters = { hacked: true }; } catch { /* — */ }
  assert(JSON.stringify(c) === serialized, "опубликованный claim изменился вслед за descriptor");
  assert(c.provenance.configHash === hash0, "configHash поплыл");
  try { c.payload.mean = 0; } catch { /* заморожено */ }
  assert(JSON.stringify(c) === serialized, "payload опубликованного claim мутируем");
});

await check("поправка 3: restore checkpoint в экземпляр с ИНЫМИ parameters → E_STATE_FORMAT", () => {
  const a = new SeriesStatsObserver({ lagSnapshots: 1 });
  const cp = a.checkpoint();
  assert(cp.observerStateFormat === "series-stats-state/1" && typeof cp.configHash === "string", "checkpoint неполон");
  const b = new SeriesStatsObserver({ lagSnapshots: 2 });
  try { b.restore(cp); throw new Error("checkpoint с чужой конфигурацией принят"); }
  catch (e) { assert(e.code === "E_STATE_FORMAT", `ожидался E_STATE_FORMAT, получен ${e.code}`); }
});

await check("поправка 4: в научном модуле анализатора нет Buffer (средонезависимость)", () => {
  const srcText = readFileSync(join(root, "src", "observe", "series-stats.mjs"), "utf8")
    .replace(/\/\*[\s\S]*?\*\//g, "")   // блочные комментарии
    .replace(/\/\/[^\n]*/g, "");          // строчные комментарии
  assert(!/\bBuffer\b/.test(srcText), "series-stats.mjs использует Buffer в коде");
});


await check("Т2: неподдержанное представление → E_VIEW_UNSUPPORTED; незарегистрированный кодек → E_VIEW_UNKNOWN", async () => {
  const host = new WorkerHost(ENTRY);
  await host.initialize(clone(CONFIG));
  const pool = new SnapshotPool(host, { poolSize: 3, byteLength: SERIES_VIEW_BYTES });
  await host.snapshotStats();
  await host.snapshotNow(); await settle();
  const [h] = pool.takeAll();
  try { h.view("lattice-view@1"); throw new Error("не отклонено"); }
  catch (e) { assert(e.code === "E_VIEW_UNSUPPORTED", `ожидался E_VIEW_UNSUPPORTED, получен ${e.code}`); }
  const { getViewCodec } = await import("../src/snapshot/view-registry.mjs");
  try { getViewCodec("ghost-view@1"); throw new Error("не отклонено"); }
  catch (e) { assert(e.code === "E_VIEW_UNKNOWN", `ожидался E_VIEW_UNKNOWN, получен ${e.code}`); }
  h.release();
  await host.dispose();
});

await check("Т3: исключение snapshot-callback не вылетает из message handler, маршрутизируется как ошибка", async () => {
  const host = new WorkerHost(ENTRY);
  await host.initialize(clone(CONFIG));
  const errors = [];
  host.onSnapshot(() => { throw new Error("диверсия в callback"); });
  host.onSnapshotError((e) => errors.push(e.message));
  host.grantBuffer(0, new ArrayBuffer(SERIES_VIEW_BYTES));
  await host.snapshotNow(); await settle();
  assert(errors.length === 1 && errors[0] === "диверсия в callback", "ошибка callback не перехвачена");
  const rep = await host.step(1); // хост жив
  assert(rep.tickEnd === 1, "хост повреждён исключением callback");
  await host.dispose();
});

await check("Т4: жизненный цикл пула — dispose, leaked handles, локальное закрытие, E_POOL_DISPOSED", async () => {
  const host = new WorkerHost(ENTRY);
  await host.initialize(clone(CONFIG));
  const pool = new SnapshotPool(host, { poolSize: 3, byteLength: SERIES_VIEW_BYTES });
  await host.snapshotStats();
  await host.snapshotNow(); await host.snapshotNow(); await settle();
  const handles = pool.takeAll();
  assert(handles.length === 2, "предусловие: два удержанных снимка");
  pool.dispose();
  assert(pool.lifecycle === "disposed", "жизненный цикл не переключился");
  assert(pool.telemetry().leakedAtDispose === 2, "leaked handles не учтены");
  // release после dispose: локальное закрытие, без исключения, без утечки
  handles.forEach((h) => h.release());
  const t = pool.telemetry();
  assert(t.returnedLocal === 2 && t.inFlight === 0, `локальное закрытие: ${JSON.stringify(t)}`);
  try { pool.takeAll(); throw new Error("не отклонено"); }
  catch (e) { assert(e.code === "E_POOL_DISPOSED", `ожидался E_POOL_DISPOSED, получен ${e.code}`); }
  await host.dispose();
});

await check("Т4: release после аварии хоста закрывает handle локально, буфер не виснет в HELD", async () => {
  const host = new WorkerHost(ENTRY);
  await host.initialize(clone(CONFIG));
  const pool = new SnapshotPool(host, { poolSize: 3, byteLength: SERIES_VIEW_BYTES });
  await host.snapshotStats();
  await host.snapshotNow(); await settle();
  const [h] = pool.takeAll();
  await host._worker.terminate(); // жёсткая авария
  h.release(); // не бросает: E_HOST_FAILURE поглощён локальным закрытием
  const t = pool.telemetry();
  assert(t.returnedLocal === 1 && t.inFlight === 0, `после аварии: ${JSON.stringify(t)}`);
});

console.log(`\nИтог шага 3: ${pass} прошло, ${fail} провалено.`);
process.exit(fail === 0 ? 0 : 1);
