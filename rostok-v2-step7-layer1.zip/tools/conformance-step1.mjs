/**
 * conformance-step1.mjs — исполняемый гейт шага 1.
 * Положительные законы C1–C6, C9; эквивалентность хостов; FIFO;
 * mutation-suite полноты checkpoint (спецификация ядра §5, У1–У7).
 * Ненулевой код процесса при любом провале.
 */
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { ReferenceRelaxationKernel, xorshift32Step } from "../src/kernels/reference-relaxation.mjs";
import { InProcessHost } from "../src/host/in-process-host.mjs";
import { WorkerHost } from "../src/host/worker-host.mjs";
import { causalStateHash } from "./causal-hash.mjs";
import { validate } from "./validate.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const schema = (n) => JSON.parse(readFileSync(join(root, "protocol", "schema", `${n}.schema.json`), "utf8"));
const CONFIG = { seed: 8842107, params: { drive: 1.0 } };
const clone = (o) => JSON.parse(JSON.stringify(o));

let pass = 0, fail = 0;
async function check(name, fn) {
  try {
    const msg = await fn();
    pass++; console.log(`  ✓ ${name}${msg ? " — " + msg : ""}`);
  } catch (e) {
    fail++; console.log(`  ✗ ${name} — ${e.message}`);
  }
}
const assert = (cond, msg) => { if (!cond) throw new Error(msg); };

function freshKernel(cfg = CONFIG) {
  const k = new ReferenceRelaxationKernel({ hashFn: causalStateHash });
  k.initialize(clone(cfg));
  return k;
}
const hashOf = (k) => causalStateHash(k.checkpoint());

/* поле+память без курсоров/rng — для проверки расхождения СОДЕРЖИМОГО */
function fieldFingerprint(k) {
  const cp = k.checkpoint();
  return [cp.buffers.field0.data, cp.buffers.field1.data, cp.buffers.field2.data, cp.buffers.memory.data].join("|");
}

console.log("Положительные законы:");

await check("C6: metadata валидна по схеме + кросс-проверки", () => {
  const r = validate(schema("kernel-metadata"), freshKernel().metadata(), "kernel-metadata");
  assert(r.ok, r.errors.map((e) => `${e.path}: ${e.message}`).join("; "));
});

await check("C9: checkpoint валиден по схеме kernel-state (канонический base64-LE)", () => {
  const k = freshKernel(); k.step(7);
  const r = validate(schema("kernel-state"), k.checkpoint(), "kernel-state");
  assert(r.ok, r.errors.map((e) => `${e.path}: ${e.message}`).join("; "));
});

await check("C9: StepReport с checksum валиден по схеме step-report", () => {
  const k = freshKernel({ ...CONFIG, emitChecksum: true });
  const rep = k.step(3);
  const r = validate(schema("step-report"), rep, "step-report");
  assert(r.ok, r.errors.map((e) => `${e.path}: ${e.message}`).join("; "));
  assert(rep.checksum === hashOf(k), "checksum отчёта ≠ CausalStateHash состояния");
});

let refHash100 = null;
await check("C1: детерминизм — один seed, две траектории, хэши на тиках 10/50/100", () => {
  const a = freshKernel(), b = freshKernel();
  const points = [10, 50, 100];
  let done = 0;
  for (const t of points) {
    a.step(t - done); b.step(t - done); done = t;
    assert(hashOf(a) === hashOf(b), `расхождение на тике ${t}`);
  }
  refHash100 = hashOf(a);
  return refHash100;
});

await check("C2: step(64) ≡ 64 × step(1) — хэш и согласованные отчёты", () => {
  const a = freshKernel(), b = freshKernel();
  const ra = a.step(64);
  assert(ra.tickStart === 0 && ra.tickEnd === 64, "диапазон отчёта step(64)");
  let last = 0;
  for (let i = 0; i < 64; i++) {
    const r = b.step(1);
    assert(r.tickStart === last && r.tickEnd === last + 1, "диапазон отчёта step(1)");
    last = r.tickEnd;
  }
  assert(hashOf(a) === hashOf(b), "хэши батча и одиночных шагов разошлись");
});

await check("C3: checkpoint→restore→continue ≡ непрерванный прогон", () => {
  const k = freshKernel(); k.step(10);
  const cp = k.checkpoint();
  k.step(10);
  const uninterrupted = hashOf(k);
  const r = freshKernel();
  r.restore(clone(cp)); r.step(10);
  assert(hashOf(r) === uninterrupted, "restore-траектория разошлась");
});

await check("C4: checkpoint чист — не тянет RNG и не меняет траекторию", () => {
  const a = freshKernel(), b = freshKernel();
  for (let i = 0; i < 20; i++) {
    a.step(1);
    b.step(1);
    const before = b.checkpoint().rng.streams.noise;
    b.checkpoint(); b.checkpoint();
    assert(b.checkpoint().rng.streams.noise === before, "checkpoint изменил RNG");
  }
  assert(hashOf(a) === hashOf(b), "чекпойнты между шагами изменили траекторию");
});

await check("C5: shutdown терминален; разрешены только metadata и повторный shutdown", () => {
  const k = freshKernel(); k.step(1); k.shutdown();
  k.metadata();      // допустимо
  k.shutdown();      // no-op
  for (const op of [() => k.step(1), () => k.checkpoint(), () => k.restore({})]) {
    try { op(); throw new Error("вызов после shutdown не отклонён"); }
    catch (e) { assert(e.code === "E_TERMINATED", `ожидался E_TERMINATED, получен ${e.code}`); }
  }
});

console.log("\nЭквивалентность хостов и FIFO:");

await check("прямое ядро ≡ InProcessHost ≡ WorkerHost (100 тактов, разный батчинг)", async () => {
  const ip = new InProcessHost(new ReferenceRelaxationKernel());
  await ip.initialize(clone(CONFIG));
  for (let i = 0; i < 20; i++) await ip.step(5);
  const hIp = causalStateHash(await ip.checkpoint());

  const wh = new WorkerHost(new URL("../src/host/worker-entry.mjs", import.meta.url));
  await wh.initialize(clone(CONFIG));
  for (let i = 0; i < 10; i++) await wh.step(10);
  const hWh = causalStateHash(await wh.checkpoint());
  await wh.dispose();

  assert(hIp === refHash100, "InProcessHost ≠ прямое ядро");
  assert(hWh === refHash100, "WorkerHost ≠ прямое ядро");
});

await check("WorkerHost: FIFO — 20 неожидаемых step(1) исполняются по порядку", async () => {
  const wh = new WorkerHost(new URL("../src/host/worker-entry.mjs", import.meta.url));
  await wh.initialize(clone(CONFIG));
  const reports = await Promise.all(Array.from({ length: 20 }, () => wh.step(1)));
  reports.forEach((r, i) => assert(r.tickStart === i && r.tickEnd === i + 1, `нарушен порядок на вызове ${i}`));
  const h = causalStateHash(await wh.checkpoint());
  await wh.dispose();
  const ref = freshKernel(); ref.step(20);
  assert(h === hashOf(ref), "итоговое состояние ≠ последовательному");
});

await check("WorkerHost: отказ вызова не создаёт параллельного входа и не ломает очередь", async () => {
  const wh = new WorkerHost(new URL("../src/host/worker-entry.mjs", import.meta.url));
  await wh.initialize(clone(CONFIG));
  const results = await Promise.allSettled([
    wh.step(1), wh.step(0), wh.step(1), wh.step(1),   // step(0) → E_BAD_ARG
  ]);
  assert(results[1].status === "rejected" && results[1].reason.code === "E_BAD_ARG",
    "step(0) не отклонён кодом E_BAD_ARG");
  const okReports = [results[0], results[2], results[3]].map((r) => r.value);
  assert(okReports[0].tickStart === 0 && okReports[1].tickStart === 1 && okReports[2].tickStart === 2,
    "порядок после отказа нарушен");
  const h = causalStateHash(await wh.checkpoint());
  await wh.dispose();
  const ref = freshKernel(); ref.step(3);
  assert(h === hashOf(ref), "состояние после отказа ≠ трём честным тактам");
});

console.log("\nMutation-suite полноты checkpoint (прогрев 50 тактов):");

const warm = freshKernel(); warm.step(50);
const CP = warm.checkpoint();
const roles = { input: CP.cursors.activePage, hist: (CP.cursors.activePage + 2) % 3, output: (CP.cursors.activePage + 1) % 3 };
const ZERO64 = (() => { const k = freshKernel(); return k.checkpoint().buffers.field1.data; })(); // 64 нуля f64 LE

function continuedHash(cp, ticks = 1) {
  const k = freshKernel();
  k.restore(clone(cp)); k.step(ticks);
  return hashOf(k);
}
function continuedFields(cp, ticks) {
  const k = freshKernel();
  k.restore(clone(cp)); k.step(ticks);
  return fieldFingerprint(k);
}
const REF1 = continuedHash(CP, 1);

async function mutation(name, mutate, opts = {}) {
  await check(`mutation: ${name}`, () => {
    const bad = clone(CP);
    mutate(bad);
    const h = continuedHash(bad, 1);
    if (opts.expectEqual) assert(h === REF1, "траектория разошлась, а не должна была");
    else assert(h !== REF1, "потеря причинного состояния НЕ обнаружена");
  });
}

await mutation(`обнуление буфера в роли input (field${roles.input})`, (s) => { s.buffers[`field${roles.input}`].data = ZERO64; });
await mutation(`обнуление буфера в роли hist (field${roles.hist})`, (s) => { s.buffers[`field${roles.hist}`].data = ZERO64; });
await mutation("обнуление memory после прогрева (У3)", (s) => { s.buffers.memory.data = ZERO64; });
await mutation("activePage + 1 (mod 3)", (s) => { s.cursors.activePage = (s.cursors.activePage + 1) % 3; });
await mutation("drive × 2 — restore обязан заменить drive (У7)", (s) => { s.scalars.drive = s.scalars.drive * 2; });
await mutation("tick + 1 (идентичность хэша)", (s) => { s.tick += 1; });
await mutation(`обнуление буфера в роли output (field${roles.output}) — документированное исключение: НЕ причинен`,
  (s) => { s.buffers[`field${roles.output}`].data = ZERO64; }, { expectEqual: true });

await check("mutation: RNG XOR ненулевой маски — гарантированно иной следующий u32 (У2)", () => {
  const s0 = Number(CP.rng.streams.noise);
  let mask = null;
  for (const m of [0x1, 0xdeadbeef, 0x9e3779b9]) {
    if (xorshift32Step((s0 ^ m) >>> 0) !== xorshift32Step(s0)) { mask = m; break; }
  }
  assert(mask !== null, "не нашлась маска с отличающимся следующим u32");
  const bad = clone(CP);
  bad.rng.streams.noise = String((s0 ^ mask) >>> 0);
  assert(continuedHash(bad, 1) !== REF1, "изменение RNG-state не изменило хэш на следующем step(1)");
  return `маска 0x${mask.toString(16)}`;
});

await check("mutation: phaseCursor+1 — полевое расхождение на горизонтах 1/8/64/256 (У1)", () => {
  const bad = clone(CP);
  bad.cursors.phaseCursor = (bad.cursors.phaseCursor + 1) % 64;
  for (const t of [1, 8, 64, 256]) {
    assert(continuedFields(bad, t) !== continuedFields(CP, t),
      `полевое содержимое совпало на горизонте ${t}`);
  }
});

await check("mutation: перестановка порядка RNG-вызовов меняет траекторию", () => {
  // Тот же RNG, тот же такт, но значения выданы элементам в обратном порядке —
  // модель рефакторинга «обход с конца». Полевое содержимое обязано разойтись.
  const k = freshKernel();
  k.restore(clone(CP));
  const cpRef = clone(CP);
  // эталон: честный step(1)
  const refFields = continuedFields(cpRef, 1);
  // подделка: воспроизводим такт вручную с обратным порядком выдачи RNG
  const s = clone(CP);
  const dec = (b64) => { const raw = Buffer.from(b64, "base64"); const a = new Float64Array(64); const dv = new DataView(raw.buffer, raw.byteOffset); for (let i = 0; i < 64; i++) a[i] = dv.getFloat64(i * 8, true); return a; };
  const enc = (a) => { const bytes = new Uint8Array(512); const dv = new DataView(bytes.buffer); for (let i = 0; i < 64; i++) dv.setFloat64(i * 8, a[i], true); return Buffer.from(bytes).toString("base64"); };
  const page = s.cursors.activePage;
  const input = dec(s.buffers[`field${page}`].data);
  const hist = dec(s.buffers[`field${(page + 2) % 3}`].data);
  const output = new Float64Array(64);
  const memory = dec(s.buffers.memory.data);
  const p = s.cursors.phaseCursor, parity = p % 2, drive = s.scalars.drive;
  let rs = Number(s.rng.streams.noise);
  const draws = [];
  for (let i = 0; i < 64; i++) { rs = xorshift32Step(rs); draws.push(rs); }
  for (let i = 0; i < 64; i++) {
    const R = (i + 1 + p) % 64, L = (i + 63 - parity) % 64;
    const u = draws[63 - i];                       // ОБРАТНЫЙ порядок выдачи
    const noise = (u / 4294967296) - 0.5;
    output[i] = (((input[i] * 0.5) + (input[R] * 0.25))
      + ((hist[L] * 0.125) + (memory[i] * 0.125)))
      + ((noise * drive) * 0.00000095367431640625);
    memory[i] = (memory[i] * 0.9375) + (output[i] * 0.0625);
  }
  s.buffers[`field${(page + 1) % 3}`].data = enc(output);
  s.buffers.memory.data = enc(memory);
  s.rng.streams.noise = String(rs >>> 0);
  s.cursors.activePage = (page + 1) % 3;
  s.cursors.phaseCursor = (p + 1) % 64;
  s.tick += 1;
  const forged = [s.buffers.field0.data, s.buffers.field1.data, s.buffers.field2.data, s.buffers.memory.data].join("|");
  assert(forged !== refFields, "обратный порядок RNG дал ту же траекторию");
});

console.log("\nExact-restore: подмена каждого нормативного поля → E_STATE_FORMAT (Р3):");

async function forgery(name, mutate) {
  await check(`restore-подделка: ${name}`, () => {
    const bad = clone(CP);
    mutate(bad);
    const k = freshKernel();
    try { k.restore(bad); }
    catch (e) {
      assert(e.code === "E_STATE_FORMAT", `ожидался E_STATE_FORMAT, получен ${e.code}: ${e.message}`);
      return;
    }
    throw new Error("подложный checkpoint принят");
  });
}

await forgery("abiVersion", (s) => { s.abiVersion = "kernel-abi/1"; });
await forgery("kernelName", (s) => { s.kernelName = "impostor"; });
await forgery("kernelVersion", (s) => { s.kernelVersion = "9.9.9"; });
await forgery("stateFormat", (s) => { s.stateFormat = "impostor-state/1"; });
await forgery("buffers.field0.dtype", (s) => { s.buffers.field0.dtype = "u32"; });
await forgery("buffers.field1.numericClass", (s) => { s.buffers.field1.numericClass = "discrete"; });
await forgery("buffers.field2.causal", (s) => { s.buffers.field2.causal = false; });
await forgery("buffers.memory.encoding", (s) => { s.buffers.memory.encoding = "number-array"; });
await forgery("buffers.memory.byteOrder", (s) => { s.buffers.memory.byteOrder = "big-endian"; });
await forgery("buffers.field0.length (дескриптор 63 при 64 элементах данных)", (s) => { s.buffers.field0.length = 63; });
await forgery("состав буферов: лишний буфер", (s) => { s.buffers.extra = clone(s.buffers.memory); });
await forgery("состав буферов: отсутствует memory", (s) => { delete s.buffers.memory; });

await check("Р3: emitChecksum=true без hashFn в конструкторе → E_CONFIG при initialize", () => {
  const k = new ReferenceRelaxationKernel();
  try { k.initialize({ ...clone(CONFIG), emitChecksum: true }); }
  catch (e) { assert(e.code === "E_CONFIG", `ожидался E_CONFIG, получен ${e.code}`); return; }
  throw new Error("initialize принял emitChecksum без hashFn");
});

await check("Р1: metadata декларирует deadRegions и остаётся валидной по схеме", () => {
  const md = freshKernel().metadata();
  assert(Array.isArray(md.deadRegions) && md.deadRegions[0]?.kind === "overwrite-before-read", "deadRegions не декларированы");
  const r = validate(schema("kernel-metadata"), md, "kernel-metadata");
  assert(r.ok, r.errors.map((e) => `${e.path}: ${e.message}`).join("; "));
});

console.log(`\nИтог шага 1: ${pass} прошло, ${fail} провалено.`);
process.exit(fail === 0 ? 0 : 1);
