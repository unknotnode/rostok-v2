/**
 * conformance-step2.mjs — исполняемый гейт шага 2 (snapshot layer + views).
 * Пункты границ 5–15 приёмки + ключевой критерий: транспорт может терять
 * и задерживать снимки, возвращать буферы в произвольное допустимое
 * время — ядро продолжает бит-идентичную траекторию и никогда не ждёт.
 */
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { ReferenceRelaxationKernel } from "../src/kernels/reference-relaxation.mjs";
import { WorkerHost } from "../src/host/worker-host.mjs";
import { SnapshotPool, OwnershipError } from "../src/snapshot/pool.mjs";
import { SERIES_VIEW_BYTES } from "../src/snapshot/encode.mjs";
import { causalStateHash } from "./causal-hash.mjs";
import { validate } from "./validate.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const schema = (n) => JSON.parse(readFileSync(join(root, "protocol", "schema", `${n}.schema.json`), "utf8"));
const ENTRY = new URL("../src/host/worker-entry.mjs", import.meta.url);
const CONFIG = { seed: 8842107, params: { drive: 1.0 } };
const clone = (o) => JSON.parse(JSON.stringify(o));

let pass = 0, fail = 0;
async function check(name, fn) {
  try {
    const msg = await fn();
    pass++; console.log(`  ✓ ${name}${msg ? " — " + msg : ""}`);
  } catch (e) {
    fail++; console.log(`  ✗ ${name} — ${e.message}`);
  }
}
const assert = (cond, msg) => { if (!cond) throw new Error(msg); };
const expectCode = (fn, code, what) => {
  try { fn(); } catch (e) { assert(e.code === code, `${what}: ожидался ${code}, получен ${e.code}`); return; }
  throw new Error(`${what}: нарушение не обнаружено`);
};
const settle = () => new Promise((r) => setImmediate(r)); // доставка push-сообщений

function refHashAfter(ticks) {
  const k = new ReferenceRelaxationKernel({ hashFn: causalStateHash });
  k.initialize(clone(CONFIG));
  k.step(ticks);
  return causalStateHash(k.checkpoint());
}

async function makeHostPool(poolSize = 3) {
  const host = new WorkerHost(ENTRY);
  await host.initialize(clone(CONFIG));
  const pool = new SnapshotPool(host, { poolSize, byteLength: SERIES_VIEW_BYTES });
  await host.snapshotStats(); // барьер: гранты доставлены до первого снимка
  return { host, pool };
}

console.log("Кольцо, заголовки, телеметрия:");

await check("п.5: пул < 3 буферов отклоняется (Д4.2)", async () => {
  const host = new WorkerHost(ENTRY);
  await host.initialize(clone(CONFIG));
  expectCode(() => new SnapshotPool(host, { poolSize: 2, byteLength: SERIES_VIEW_BYTES }), "E_OWNERSHIP", "poolSize=2");
  await host.dispose();
});

await check("п.9: заголовок снимка валиден по схеме; seq монотонен", async () => {
  const { host, pool } = await makeHostPool();
  await host.step(5); await host.snapshotNow();
  await host.step(5); await host.snapshotNow();
  await settle();
  const handles = pool.takeAll();
  assert(handles.length === 2, `доставлено ${handles.length} из 2`);
  let prev = -1;
  for (const h of handles) {
    const r = validate(schema("snapshot-header"), h.header, "snapshot-header");
    assert(r.ok, r.errors.map((e) => `${e.path}: ${e.message}`).join("; "));
    assert(h.header.seq > prev, "seq не монотонен");
    prev = h.header.seq;
    assert(h.header.views.length === 1 && h.header.views[0] === "series-view@1", "views неверны");
  }
  assert(handles[1].header.tick === 10, `tick заголовка ${handles[1].header.tick} ≠ 10`);
  for (const h of handles) h.release();
  await host.dispose();
});

await check("п.7/8: drop-not-block + телеметрия produced/delivered/returned/dropped/inFlight/highWaterMark", async () => {
  const { host, pool } = await makeHostPool(3);
  for (let i = 0; i < 5; i++) { await host.step(1); await host.snapshotNow(); } // 3 произведутся, 2 упадут
  await settle();
  const prod = await host.snapshotStats();
  assert(prod.produced === 3 && prod.dropped === 2, `производитель: ${JSON.stringify(prod)}`);
  const handles = pool.takeAll();
  assert(handles.length === 3, `доставлено ${handles.length}`);
  let t = pool.telemetry();
  assert(t.delivered === 3 && t.inFlight === 3 && t.highWaterMark === 3 && t.returned === 0, `потребитель: ${JSON.stringify(t)}`);
  assert(handles[2].header.dropped === 0, "снимки 1–3 произведены до первого пропуска: dropped обязан быть 0");
  handles.forEach((h) => h.release());
  t = pool.telemetry();
  assert(t.returned === 3 && t.inFlight === 0, `после возврата: ${JSON.stringify(t)}`);
  // кольцо ожило после возврата; накопленные пропуски видны в заголовке нового снимка
  await host.snapshotNow(); await settle();
  const late = pool.takeAll();
  assert(late.length === 1, "возвращённый буфер не переиспользован");
  assert(late[0].header.dropped === 2, `заголовок нового снимка: dropped=${late[0].header.dropped}, ожидалось 2`);
  late[0].release();
  await host.dispose();
});

console.log("\nOwnership-нарушения (п.10/11):");

await check("двойной возврат → E_OWNERSHIP", async () => {
  const { host, pool } = await makeHostPool();
  await host.snapshotNow(); await settle();
  const [h] = pool.takeAll();
  h.release();
  expectCode(() => h.release(), "E_OWNERSHIP", "двойной release");
  await host.dispose();
});

await check("возврат чужого буфера → E_OWNERSHIP", async () => {
  const { host, pool } = await makeHostPool();
  expectCode(() => pool._release(999, 0, new ArrayBuffer(8)), "E_OWNERSHIP", "чужой poolId");
  await host.dispose();
});

await check("устаревший seq при возврате → E_OWNERSHIP", async () => {
  const { host, pool } = await makeHostPool();
  await host.snapshotNow(); await settle();
  const [h] = pool.takeAll();
  expectCode(() => h.release(h.seq + 41), "E_OWNERSHIP", "подложный seq");
  h.release(); // корректный возврат после отклонённого
  await host.dispose();
});

await check("чтение после возврата → E_USE_AFTER_RETURN (буфер физически отсоединён)", async () => {
  const { host, pool } = await makeHostPool();
  await host.step(3); await host.snapshotNow(); await settle();
  const [h] = pool.takeAll();
  const before = h.view("series-view@1");
  assert(before.length === 64 && Number.isFinite(before.getInput(0)), "каналы до возврата недоступны");
  h.release();
  expectCode(() => h.view("series-view@1"), "E_USE_AFTER_RETURN", "чтение после release");
  await host.dispose();
});

console.log("\nСодержимое представления (п.6/14):");

await check("п.14: мёртвая роль не входит в снимок — состояния, различающиеся только ею, дают байт-идентичную нагрузку", async () => {
  const warm = new ReferenceRelaxationKernel({ hashFn: causalStateHash });
  warm.initialize(clone(CONFIG)); warm.step(50);
  const cp = warm.checkpoint();
  const deadName = `field${(cp.cursors.activePage + 1) % 3}`;
  const cpDead = clone(cp);
  const zero = new ReferenceRelaxationKernel({ hashFn: causalStateHash });
  zero.initialize(clone(CONFIG));
  cpDead.buffers[deadName].data = zero.checkpoint().buffers.field1.data; // нули
  assert(causalStateHash(cp) !== causalStateHash(cpDead), "предусловие: записи различаются");

  const payloads = [];
  for (const state of [cp, cpDead]) {
    const { host, pool } = await makeHostPool();
    await host.restore(clone(state));
    await host.snapshotNow(); await settle();
    const [h] = pool.takeAll();
    const ch = h.view("series-view@1");
    const flat = new Float64Array(ch.length * 3);
    for (let i = 0; i < ch.length; i++) {
      flat[i] = ch.getInput(i); flat[64 + i] = ch.getHist(i); flat[128 + i] = ch.getMemory(i);
    }
    payloads.push(Buffer.from(flat.buffer.slice(0)));
    h.release();
    await host.dispose();
  }
  assert(payloads[0].equals(payloads[1]), "мёртвая роль просочилась в представление");
});

await check("п.6: живое состояние не передаётся — снимок совпадает с checkpoint-копией по ролям", async () => {
  const { host, pool } = await makeHostPool();
  await host.step(17);
  const cp = await host.checkpoint();
  await host.snapshotNow(); await settle();
  const [h] = pool.takeAll();
  const ch = h.view("series-view@1");
  const dec = (b64) => { const raw = Buffer.from(b64, "base64"); const a = new Float64Array(64); const dv = new DataView(raw.buffer, raw.byteOffset); for (let i = 0; i < 64; i++) a[i] = dv.getFloat64(i * 8, true); return a; };
  const input = dec(cp.buffers[`field${cp.cursors.activePage}`].data);
  for (let i = 0; i < 64; i++) assert(ch.getInput(i) === input[i], `input[${i}] расходится с ролевым checkpoint`);
  h.release();
  await host.dispose();
});

console.log("\nКлючевой критерий и A/B (п.15):");

const REF200 = refHashAfter(200);

await check("A/B: снимки выключены — контрольная траектория", async () => {
  const host = new WorkerHost(ENTRY);
  await host.initialize(clone(CONFIG));
  await host.step(200);
  const h = causalStateHash(await host.checkpoint());
  await host.dispose();
  assert(h === REF200, "траектория без снимков разошлась");
  return REF200;
});

await check("A/B: массовые drop (потребитель никогда не возвращает) — та же траектория, ядро не ждёт", async () => {
  const { host, pool } = await makeHostPool(3);
  const rep = await host.stepWithSnapshots(200, 5); // 40 попыток на 3 буфера
  const h = causalStateHash(await host.checkpoint());
  const prod = await host.snapshotStats();
  await settle();
  assert(h === REF200, "траектория под массовыми drop разошлась");
  assert(prod.produced === 3 && prod.dropped === 37, `ожидалось 3/37, получено ${prod.produced}/${prod.dropped}`);
  assert(rep.tickEnd === 200, "батч не дошёл до 200 тактов");
  pool.takeAll().forEach((x) => x.release());
  await host.dispose();
  return `produced=3, dropped=37, хэш совпал`;
});

await check("A/B: произвольное допустимое время возврата (задержки, вперемешку) — та же траектория", async () => {
  const { host, pool } = await makeHostPool(3);
  const held = [];
  for (let round = 0; round < 20; round++) {
    await host.stepWithSnapshots(10, 3);
    await settle();
    held.push(...pool.takeAll());
    // детерминированный «капризный потребитель»: возвращает через раз и не по порядку
    if (round % 2 === 1) {
      while (held.length > 1) held.pop().release();  // LIFO, с задержкой на раунд
    }
  }
  while (held.length) held.shift().release();
  const h = causalStateHash(await host.checkpoint());
  const prod = await host.snapshotStats();
  await host.dispose();
  assert(h === REF200, "траектория при капризном потребителе разошлась");
  assert(prod.produced + prod.dropped === 80, `учёт попыток: ${prod.produced}+${prod.dropped}≠80`);
  return `produced=${prod.produced}, dropped=${prod.dropped}, хэш совпал`;
});

console.log("\nАвария хоста (п.12/13):");

await check("п.13: явная FIFO-очередь — вызовы уходят строго последовательно", async () => {
  const host = new WorkerHost(ENTRY);
  await host.initialize(clone(CONFIG));
  const reports = await Promise.all(Array.from({ length: 10 }, () => host.step(1)));
  reports.forEach((r, i) => assert(r.tickStart === i, `порядок нарушен на ${i}`));
  await host.dispose();
});

await check("п.12: авария воркера отклоняет все pending и будущие вызовы E_HOST_FAILURE", async () => {
  const host = new WorkerHost(ENTRY);
  await host.initialize(clone(CONFIG));
  const pending = [host.step(1000000), host.step(1), host.checkpoint()];
  await host._worker.terminate(); // жёсткая авария (не dispose-путь)
  const results = await Promise.allSettled(pending);
  for (const [i, r] of results.entries()) {
    assert(r.status === "rejected" && r.reason.code === "E_HOST_FAILURE",
      `pending ${i}: ${r.status} ${r.reason?.code}`);
  }
  const after = await host.step(1).then(() => null, (e) => e);
  assert(after && after.code === "E_HOST_FAILURE", "вызов после аварии не отклонён");
  expectCode(() => host.grantBuffer(0, new ArrayBuffer(8)), "E_HOST_FAILURE", "grant после аварии");
});

console.log(`\nИтог шага 2: ${pass} прошло, ${fail} провалено.`);
process.exit(fail === 0 ? 0 : 1);
