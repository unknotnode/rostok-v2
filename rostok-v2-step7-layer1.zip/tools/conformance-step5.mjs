/**
 * conformance-step5.mjs — исполняемый гейт реализации two-tier-journal/1.0.0.
 */
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { RunJournal } from "../src/journal/run-journal.mjs";
import { validateJournalConsistency } from "../src/journal/consistency.mjs";
import { InMemoryDriver } from "../src/archive/archive.mjs";
import { validate } from "./validate.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const schemaCache = new Map();
const schema = (n) => {
  if (!schemaCache.has(n)) schemaCache.set(n, JSON.parse(readFileSync(join(root, "protocol", "schema", `${n}.schema.json`), "utf8")));
  return schemaCache.get(n);
};
const validateRecord = (name, data) => validate(schema(name), data, name);
const H = "a".repeat(64);

let pass = 0, fail = 0;
async function check(name, fn) {
  try { const msg = await fn(); pass++; console.log(`  ✓ ${name}${msg ? " — " + msg : ""}`); }
  catch (e) { fail++; console.log(`  ✗ ${name} — ${e.message}`); }
}
const assert = (cond, msg) => { if (!cond) throw new Error(msg); };
async function expectCode(fnP, code, what) {
  try { await fnP(); } catch (e) { assert(e.code === code, `${what}: ожидался ${code}, получен ${e.code}: ${e.message}`); return; }
  throw new Error(`${what}: нарушение не обнаружено`);
}

const PROTOCOL = {
  protocol: "rost0k-experiment/2", id: "exp-journal-001", createdAt: "2026-07-17T04:20:00Z",
  kernel: { name: "reference-relaxation", version: "1.0.0", abiVersion: "kernel-abi/2", stateFormat: "reference-relaxation-state/1" },
  runtime: { version: "0.5.0" },
  manifest: { modules: [], snapshotTransport: { mode: "copy", cadence: 5 } },
  seed: { master: 8842107 }, commands: [],
  detectors: [], preregistered: { observables: ["ряд"], expectations: ["контроль"] },
  environment: { platform: "node-worker/v8", float: "f64" },
};
const ENV = { runtime: "0.5.0", platform: "node/v8", float: "f64", host: "worker" };
const clone = (o) => JSON.parse(JSON.stringify(o));

async function openJournal(driver = new InMemoryDriver(), proto = PROTOCOL) {
  const j = new RunJournal(driver, { validateRecord });
  await j.open(clone(proto), clone(ENV));
  return j;
}

/** Полный здоровый жизненный цикл одной команды. */
async function applyCommandChain(j, tick, cmdBody = { cmd: "set-param" }) {
  const { commandId } = await j.submitCommand({ body: cmdBody, requestedTick: tick });
  const factId = await j.recordFact({
    tier: "fact", type: "fact.command.apply", causalTick: tick, seq: j._streams.get("facts")?.recorded.size ?? 0,
    payload: { commandId }, envelope: { correlationId: commandId },
  });
  await j.resolveCommand(commandId, "APPLIED", { tick, kernelFactId: factId });
  return { commandId, factId };
}

console.log("Машина исходов и осей:");

await check("двойное разрешение и смена терминального исхода → E_TRANSITION", async () => {
  const j = await openJournal();
  const { commandId, factId } = await applyCommandChain(j, 100);
  await expectCode(() => j.resolveCommand(commandId, "APPLIED", { tick: 100, kernelFactId: factId }), "E_TRANSITION", "повторное APPLIED");
  await expectCode(() => j.resolveCommand(commandId, "REJECTED", { tick: 100, kernelFactId: factId }), "E_TRANSITION", "смена исхода");
  await expectCode(() => j.resolveCommand("command:99:zzz", "APPLIED", { tick: 1, kernelFactId: factId }), "E_UNKNOWN_COMMAND", "неизвестная команда");
});

await check("APPLIED/REJECTED без факта ядра → E_TRANSITION (§3)", async () => {
  const j = await openJournal();
  const { commandId } = await j.submitCommand({ body: { cmd: "x" }, requestedTick: 5 });
  await expectCode(() => j.resolveCommand(commandId, "APPLIED", { tick: 5 }), "E_TRANSITION", "APPLIED без факта");
});

await check("finalize при PENDING → E_FINALIZE_PENDING", async () => {
  const j = await openJournal();
  await j.submitCommand({ body: { cmd: "x" }, requestedTick: 5 });
  await expectCode(() => j.finalize({ execution: "COMPLETED" }), "E_FINALIZE_PENDING", "PENDING");
});

await check("Ф1: ABORTED с полной атрибуцией ⇒ SEALED; без checkpoint/обоснования ⇒ отвергнут", async () => {
  const a = await openJournal();
  await applyCommandChain(a, 100);
  await a.appendCheckpoint("final", { tick: 50000 });   // ссылка обязана указывать на существующую запись
  const fa = await a.finalize({ execution: "ABORTED", terminationReason: "оператор остановил", terminalTick: 50000, finalCheckpointRef: "checkpoint:final" });
  assert(fa.runSealStatus === "SEALED" && fa.runExecutionStatus === "ABORTED", `оси: ${fa.runExecutionStatus}/${fa.runSealStatus}`);
  const b = await openJournal(new InMemoryDriver(), { ...clone(PROTOCOL), id: "exp-journal-001b" });
  await applyCommandChain(b, 100);
  await expectCode(() => b.finalize({ execution: "ABORTED", terminationReason: "стоп", terminalTick: 1 }), "E_SEAL_REQUIREMENTS", "ABORTED без checkpoint");
  return "ABORTED+SEALED допустим, контртест отвергнут";
});

console.log("\nЦентральные тесты спецификации:");

await check("ЦТ1: APPLIED + отказ result-журнала ⇒ UNSEALED, runIdentityHash НЕИЗМЕНЕН", async () => {
  class ResultKiller extends InMemoryDriver {
    async putIfAbsent(record, canonical) {
      if (record.kind === "command-result") { const e = new Error("result-backend мёртв"); e.code = "E_IO"; throw e; }
      return super.putIfAbsent(record, canonical);
    }
  }
  const healthy = await openJournal();
  await applyCommandChain(healthy, 100);
  const fh = await healthy.finalize({ execution: "COMPLETED" });
  assert(fh.runSealStatus === "SEALED" && fh.runIdentityClass === "causal-confirmed", "здоровый прогон не SEALED");

  const wounded = await openJournal(new ResultKiller());
  await applyCommandChain(wounded, 100);
  const { journalStatus } = { journalStatus: [...wounded._commands.values()][0].journalStatus };
  assert(journalStatus === "RESULT_MISSING", `journalStatus=${journalStatus}`);
  const fw = await wounded.finalize({ execution: "COMPLETED" });
  assert(fw.runSealStatus === "UNSEALED", "отказ result-журнала не дал UNSEALED");
  assert(fw.runIdentityClass === "causal-confirmed", "исход известен — класс обязан быть confirmed");
  assert(fw.runIdentityHash === fh.runIdentityHash, "У1 НАРУШЕН: судьба backend изменила физическую идентичность");
  assert(RunJournal.compare(fh, fw) === true, "сравнение confirmed-запусков обязано видеть тот же прогон");
  return `hash ${fh.runIdentityHash.slice(0, 12)}… одинаков, seal SEALED против UNSEALED`;
});

await check("ЦТ2: OUTCOME_UNKNOWN ⇒ только ABORTED+UNSEALED, indeterminate, сравнение отвергается", async () => {
  const j = await openJournal();
  const { commandId } = await j.submitCommand({ body: { cmd: "x" }, requestedTick: 100 });
  // авария хоста до подтверждения:
  await j.resolveCommand(commandId, "OUTCOME_UNKNOWN", { tick: 100 });
  await expectCode(() => j.finalize({ execution: "COMPLETED" }), "E_FINALIZE_INDETERMINATE", "COMPLETED при UNKNOWN");
  const f = await j.finalize({ execution: "ABORTED", terminationReason: "авария хоста до подтверждения", terminalTick: 100, checkpointAbsenceJustification: "хост погиб, checkpoint остановки недостижим" });
  assert(f.runSealStatus === "UNSEALED" && f.runIdentityClass === "causal-indeterminate",
    `оси: ${f.runSealStatus}/${f.runIdentityClass}`);
  const healthy = await openJournal(new InMemoryDriver(), { ...clone(PROTOCOL), id: "exp-journal-001c" });
  await applyCommandChain(healthy, 100);
  const fh = await healthy.finalize({ execution: "COMPLETED" });
  try { RunJournal.compare(fh, f); throw new Error("сравнение с indeterminate прошло"); }
  catch (e) { assert(e.code === "E_IDENTITY_CLASS", `ожидался E_IDENTITY_CLASS, получен ${e.code}`); }
});

await check("идентичность: разные исходы ⇒ разные хэши; env входит в runIdentityHash", async () => {
  const a = await openJournal();
  await applyCommandChain(a, 100);
  const fa = await a.finalize({ execution: "COMPLETED" });
  const b = await openJournal();
  const { commandId } = await b.submitCommand({ body: { cmd: "set-param" }, requestedTick: 100 });
  const factId = await b.recordFact({ tier: "fact", type: "fact.command.reject", causalTick: 100, seq: 0, payload: { commandId }, envelope: { correlationId: commandId } });
  await b.resolveCommand(commandId, "REJECTED", { tick: 100, kernelFactId: factId });
  const fb = await b.finalize({ execution: "COMPLETED" });
  assert(fa.runIdentityHash !== fb.runIdentityHash, "APPLIED и REJECTED дали одну идентичность");
  const c = new RunJournal(new InMemoryDriver(), { validateRecord });
  await c.open(clone(PROTOCOL), { ...clone(ENV), platform: "rust/native" });
  await applyCommandChain(c, 100);
  const fc = await c.finalize({ execution: "COMPLETED" });
  assert(fc.runIdentityHash !== fa.runIdentityHash, "среда исполнения не вошла в идентичность (О6)");
});

console.log("\nJournalConsistencyValidator (Ф2, семь инвариантов):");

await check("чистый журнал проходит; семь порч — семь обнаружений", async () => {
  const j = await openJournal();
  const { commandId, factId } = await applyCommandChain(j, 100);
  const clean = await j.records();
  assert(validateJournalConsistency(clean).length === 0, "чистый журнал объявлен противоречивым");

  const mutate = (fn) => {
    const recs = clean.map((r) => JSON.parse(JSON.stringify(r)));
    fn(recs);
    return validateJournalConsistency(recs);
  };
  const has = (viol, inv) => viol.some((v) => v.invariant === inv);

  let v = mutate((r) => { r.find((x) => x.kind === "command-record").body.commandId = "command:ghost"; r.find((x) => x.kind === "command-record").id = "command:ghost"; });
  assert(has(v, "И1") || has(v, "И2"), "И1 висячий commandId не обнаружен");

  v = mutate((r) => { r.find((x) => x.kind === "command-result").body.kernelFactId = commandId; });
  assert(has(v, "И2"), "И2 ссылка на объект другого типа не обнаружена");

  v = mutate((r) => { r.find((x) => x.kind === "causal-fact").runRef = "exp-чужой"; });
  assert(has(v, "И3"), "И3 чужой запуск не обнаружен");

  v = mutate((r) => { r.find((x) => x.kind === "causal-fact").body.type = "fact.command.reject"; });
  assert(has(v, "И4"), "И4 APPLIED при reject-факте не обнаружен");

  v = mutate((r) => {
    const res = JSON.parse(JSON.stringify(r.find((x) => x.kind === "command-result")));
    res.id = res.id + ":dup"; res.body.commandOutcome = "REJECTED"; res.contentHash = "f".repeat(64);
    r.push(res);
  });
  assert(has(v, "И5"), "И5 два терминальных результата не обнаружены");

  v = mutate((r) => {
    const res = JSON.parse(JSON.stringify(r.find((x) => x.kind === "command-result")));
    res.id = "command:2:xyz:result"; res.body.commandId = "command:2:xyz";
    const cr = JSON.parse(JSON.stringify(r.find((x) => x.kind === "command-record")));
    cr.id = "command:2:xyz"; cr.body.commandId = "command:2:xyz";
    r.push(cr, res);
  });
  assert(has(v, "И6"), "И6 один факт двум командам не обнаружен");

  v = mutate((r) => {
    const a = r.find((x) => x.kind === "causal-fact");
    const b = r.find((x) => x.kind === "command-result");
    a.body.envelope.causationId = b.id;
    // b уже ссылается causationId → factId → цикл a→b→a
  });
  assert(has(v, "И7"), "И7 цикл causationId не обнаружен");
  return "7/7 порч обнаружены";
});

console.log("\nManifest, аудит, repair (В4):");

await check("отказ fact-sink ⇒ дыра летописи; repair из детерминированного источника закрывает её", async () => {
  class FactGapDriver extends InMemoryDriver {
    constructor() { super(); this.killSeq = 2; }
    async putIfAbsent(record, canonical) {
      if (record.kind === "causal-fact" && record.order.seq === this.killSeq && this.killSeq !== null) {
        const e = new Error("fact-sink отказал"); e.code = "E_IO"; throw e;
      }
      return super.putIfAbsent(record, canonical);
    }
  }
  const drv = new FactGapDriver();
  const j = await openJournal(drv);
  const issued = [];
  for (let s = 0; s < 5; s++) {
    const fact = { tier: "fact", type: "fact.element.birth", causalTick: 10 + s, seq: s, payload: { element: s }, envelope: { correlationId: `f${s}` } };
    issued.push(fact);
    await j.recordFact(fact);
  }
  let manifest = j.buildManifest();
  const facts = manifest.streams.find((s) => s.streamId === "facts");
  assert(JSON.stringify(facts.missingSeqRanges) === JSON.stringify([{ from: 2, to: 2 }]), `пропуск: ${JSON.stringify(facts.missingSeqRanges)}`);
  assert(RunJournal.auditFromManifest(manifest) === "INCOMPLETE", "дыра не дала INCOMPLETE");
  // repair: повторная ВЫДАЧА того же факта (источник — буфер, не перепрогон)
  drv.killSeq = null;
  j.setReissueSource("facts", (seq) => issued[seq] ?? null);
  const f = await j.finalize({ execution: "COMPLETED" });
  assert(f.auditStatus === "COMPLETE", `после repair аудит ${f.auditStatus}`);
  assert(f.repairHistory.some((h) => h.seq === 2 && h.outcome === "repaired"), "история repair не сохранена");
  assert((await j.records()).some((r) => r.kind === "repair"), "repair-записи нет в архиве");
  assert(f.runSealStatus === "SEALED", "восстановленная летопись не помешала SEALED");
});

await check("невосстановимый пропуск ⇒ INCOMPLETE, permanent не маскируется", async () => {
  class FactGapDriver extends InMemoryDriver {
    async putIfAbsent(record, canonical) {
      if (record.kind === "causal-fact" && record.order.seq === 1) { const e = new Error("x"); e.code = "E_IO"; throw e; }
      return super.putIfAbsent(record, canonical);
    }
  }
  const j = await openJournal(new FactGapDriver());
  for (let s = 0; s < 3; s++) {
    await j.recordFact({ tier: "fact", type: "fact.element.birth", causalTick: s, seq: s, payload: {}, envelope: { correlationId: `f${s}` } });
  }
  j.setReissueSource("facts", () => null); // источник не может выдать
  const f = await j.finalize({ execution: "COMPLETED" });
  assert(f.auditStatus === "INCOMPLETE", "permanent-пропуск замаскирован");
  const facts = f.manifest.streams.find((s) => s.streamId === "facts");
  assert(JSON.stringify(facts.permanentRanges) === JSON.stringify([{ from: 1, to: 1 }]), "permanentRanges неверны");
});

await check("читатель отвергает противоречивый manifest (§7, четыре правила)", () => {
  const good = { streams: [{ streamId: "facts", producerId: "kernel", expectedSeqPolicy: "dense-from-0",
    firstObservedSeq: 0, sourceHighWaterMark: 4, recordedSeqRanges: [{ from: 0, to: 4 }], missingSeqRanges: [],
    duplicateCount: 0, conflictCount: 0, recoverableRanges: [], permanentRanges: [], evidenceSource: "t", computedBy: "t", computationVersion: "1" }] };
  assert(RunJournal.verifyManifest(good, "COMPLETE").ok, "здоровый manifest отвергнут");
  const forge = (fn) => { const m = JSON.parse(JSON.stringify(good)); fn(m.streams[0]); return RunJournal.verifyManifest(m); };
  assert(!forge((s) => { s.recordedSeqRanges = [{ from: 0, to: 3 }, { from: 2, to: 4 }]; }).ok, "внутреннее пересечение диапазонов принято");
  assert(!forge((s) => { s.missingSeqRanges = [{ from: 2, to: 2 }]; }).ok, "missing∩recorded принято");
  assert(!forge((s) => { s.sourceHighWaterMark = 1; }).ok, "HWM < последнего seq принят");
  assert(!RunJournal.verifyManifest(good, "INCOMPLETE").ok, "ложный заявленный auditStatus принят");
  // край 4: доказательство покрытия и корректность форм
  const gap = forge((s) => { s.sourceHighWaterMark = 100; });
  assert(!gap.ok && gap.reasons.some((r) => r.includes("покрытие неполно")), "подлог «recorded 0..10, HWM=100, missing=[]» принят как полный");
  assert(!forge((s) => { s.recordedSeqRanges = [{ from: 4, to: 1 }]; }).ok, "from>to принят");
  assert(!forge((s) => { s.permanentRanges = [{ from: 3, to: 3 }]; }).ok, "permanent ⊄ missing принят");
  assert(!forge((s) => { s.expectedSeqPolicy = "dense-from-42"; }).ok, "неизвестная политика принята");
  assert(!forge((s) => { s.firstObservedSeq = 2; }).ok, "firstObservedSeq ≠ min(recorded) принят");
});

console.log("\nReplay и ярусы:");

await check("три раздельных порядка + командная цепочка по correlationId", async () => {
  const j = await openJournal();
  const { commandId, factId } = await applyCommandChain(j, 200);
  await j.recordFact({ tier: "fact", type: "fact.element.birth", causalTick: 50, seq: 1, payload: {}, envelope: { correlationId: "b1" } });
  await j.appendClaim({ tier: "claim", type: "claim.measurement.series-stats", snapshotTick: 60, emittedSeq: 0,
    payload: { mean: 1 }, provenance: { detectorId: "analyzer.series-stats", detectorVersion: "1.0.0", configHash: H, producerInvocationId: H, emissionIndexWithinInvocation: 0, analysisRevisionId: "live" }, envelope: { correlationId: "s60" } });
  const r = await j.replay();
  assert(r.causal[0].body.causalTick === 50 && r.causal.every((x) => !x.kind.startsWith("observer")),
    "причинный порядок неверен или содержит наблюдательное");
  assert(r.emission.length === 1 && r.emission[0].kind === "observer-claim", "порядок эмиссии неверен");
  const seqs = r.receipt.map((x) => x.order.archiveSeq);
  assert(JSON.stringify(seqs) === JSON.stringify([...seqs].sort((a, b) => a - b)), "порядок приёма неверен");
  const chain = r.chains.find((c) => c.commandId === commandId);
  assert(chain.command && chain.fact?.id === factId && chain.result?.body.kernelFactId === factId, "цепочка команды не связана");
});

await check("наблюдательное fail-open: невалидный claim → infra, физический ярус не тронут", async () => {
  const j = await openJournal();
  const bad = { tier: "claim", type: "claim.x", snapshotTick: 1, snapshotRange: { fromTick: 0, toTick: 2 }, emittedSeq: 0, payload: {}, provenance: {}, envelope: { correlationId: "x" } };
  const id = await j.appendClaim(bad);
  assert(id === null && j.infraFailureCount === 1, "невалидный claim не ушёл в infra");
  await applyCommandChain(j, 10);
  const f = await j.finalize({ execution: "COMPLETED" });
  assert(f.runSealStatus === "SEALED" && f.auditStatus === "COMPLETE", "наблюдательный сбой задел физические оси");
});

await check("revision после finalize несёт parentRunIdentityHash; recovery-evidence по схеме", async () => {
  const j = await openJournal();
  const { commandId } = await j.submitCommand({ body: { cmd: "x" }, requestedTick: 7 });
  await j.resolveCommand(commandId, "OUTCOME_UNKNOWN", { tick: 7 });
  const f = await j.finalize({ execution: "ABORTED", terminationReason: "авария", terminalTick: 7, checkpointAbsenceJustification: "хост погиб" });
  const rec = await j.appendRevision({
    revisionKind: "recovery-evidence", analysisRevisionId: "rev-1",
    subjectRef: commandId, evidenceSource: "скан backend 04:2x", verificationMethod: "sha256-сверка",
    proposedInterpretation: { likelyOutcome: "APPLIED" }, envelope: { correlationId: commandId },
  });
  assert(rec.body.parentRunIdentityHash === f.runIdentityHash, "родительская идентичность не проставлена");
  assert(j.final.runSealStatus === "UNSEALED" && j.final.runIdentityClass === "causal-indeterminate",
    "revision изменила статусы родителя");
});

console.log("\nКрая приёмки шага 5 (Э1–Э8):");

await check("Э1: подложная несогласованность ⇒ SEALED недостижим; аварийно — только ABORTED+UNSEALED", async () => {
  const j = await openJournal();
  const { commandId, factId } = await applyCommandChain(j, 100);
  // подлог мимо штатных путей: второй факт с чужим commandId
  await j._append("causal-fact", "fact:forged", {
    tier: "fact", type: "fact.command.apply", causalTick: 101, seq: 7, factId: "fact:forged",
    payload: { commandId: "command:999:ghost" }, envelope: { correlationId: "command:999:ghost", causationId: "fact:forged-нет" },
  }, { tick: 101, seq: 7 });
  await expectCode(() => j.finalize({ execution: "COMPLETED" }), "E_JOURNAL_INCONSISTENT", "COMPLETED при противоречии");
  const f = await j.finalize({ execution: "ABORTED", terminationReason: "аварийное сохранение противоречивого журнала", terminalTick: 101, checkpointAbsenceJustification: "журнал противоречив" });
  assert(f.runSealStatus === "UNSEALED", "противоречивый журнал получил не-UNSEALED");
  assert(f.consistencyViolations.length > 0, "нарушения не приложены к финализации");
  return `${f.consistencyViolations.length} нарушений приложено, SEALED недостижим`;
});

await check("Э2: невалидный resolveCommand → E_SCHEMA, команда ОСТАЁТСЯ PENDING, повтор допустим", async () => {
  const j = await openJournal();
  const { commandId } = await j.submitCommand({ body: { cmd: "x" }, requestedTick: 5 });
  const factId = await j.recordFact({ tier: "fact", type: "fact.command.apply", causalTick: 5, seq: 0, payload: { commandId }, envelope: { correlationId: commandId } });
  await expectCode(() => j.resolveCommand(commandId, "APPLIED", { tick: -5, kernelFactId: factId }), "E_SCHEMA", "отрицательный тик");
  const c = j._commands.get(commandId);
  assert(c.outcome === "PENDING" && c.journalStatus === "RECORDED", `частичный commit: ${c.outcome}/${c.journalStatus}`);
  const r = await j.resolveCommand(commandId, "APPLIED", { tick: 5, kernelFactId: factId });
  assert(r.outcome === "APPLIED" && r.journalStatus === "RESULT_RECORDED", "корректный повтор не прошёл");
  const f = await j.finalize({ execution: "COMPLETED" });
  assert(f.runSealStatus === "SEALED", "после честного повтора SEALED недостижим");
});

await check("Э3: requestedTick и scheduledTick при одном числе ⇒ РАЗНЫЕ runIdentityHash", async () => {
  const a = await openJournal();
  {
    const { commandId } = await a.submitCommand({ body: { cmd: "set-param" }, requestedTick: 100 });
    const fid = await a.recordFact({ tier: "fact", type: "fact.command.apply", causalTick: 100, seq: 0, payload: { commandId }, envelope: { correlationId: commandId } });
    await a.resolveCommand(commandId, "APPLIED", { tick: 100, kernelFactId: fid });
  }
  const fa = await a.finalize({ execution: "COMPLETED" });
  const b = await openJournal();
  {
    const { commandId } = await b.submitCommand({ body: { cmd: "set-param" }, scheduledTick: 100 });
    const fid = await b.recordFact({ tier: "fact", type: "fact.command.apply", causalTick: 100, seq: 0, payload: { commandId }, envelope: { correlationId: commandId } });
    await b.resolveCommand(commandId, "APPLIED", { tick: 100, kernelFactId: fid });
  }
  const fb = await b.finalize({ execution: "COMPLETED" });
  assert(fa.runIdentityHash !== fb.runIdentityHash, "семантика временного контракта схлопнута в идентичности");
});

await check("Э5: повторная доставка ObserverFailure идемпотентна; иной индекс — иной id", async () => {
  const j = await openJournal();
  const failure = { tier: "claim", type: "claim.observer.failure", failureStage: "DECODE",
    producerInvocationId: H, failureIndexWithinInvocation: 0,
    detectorId: "analyzer.series-stats", detectorVersion: "1.0.0", configHash: H,
    errorCode: "E_VIEW_UNKNOWN", errorCategory: "schema", envelope: { correlationId: "snap-9" } };
  const id1 = await j.appendObserverFailure(failure);
  const id2 = await j.appendObserverFailure(JSON.parse(JSON.stringify(failure)));
  assert(id1 === id2, "повторная доставка породила другой id");
  const stored = (await j.records()).filter((r) => r.kind === "observer-failure");
  assert(stored.length === 1, `повторная доставка создала ${stored.length} записи`);
  const id3 = await j.appendObserverFailure({ ...JSON.parse(JSON.stringify(failure)), failureIndexWithinInvocation: 1, errorCode: "E_STATE_FORMAT", errorCategory: "state" });
  assert(id3 !== id1 && (await j.records()).filter((r) => r.kind === "observer-failure").length === 2, "второй сбой invocation не различён");
  assert(!id1.includes(":9:") && !/:\d{3,}$/.test(id1), "archiveSeq просочился в id");
});

await check("Э6: reissue-mismatch — повторная выдача, не совпавшая с producer evidence, ⇒ permanent", async () => {
  class FactGapDriver extends InMemoryDriver {
    constructor() { super(); this.dead = true; }
    async putIfAbsent(record, canonical) {
      if (this.dead && record.kind === "causal-fact" && record.order.seq === 1) { const e = new Error("x"); e.code = "E_IO"; throw e; }
      return super.putIfAbsent(record, canonical);
    }
  }
  const drv = new FactGapDriver();
  const j = await openJournal(drv);
  const { contentHash } = await import("../src/lib/canonical.mjs");
  const genuine = { tier: "fact", type: "fact.element.birth", causalTick: 11, seq: 1, factId: "fact:11:1", payload: { element: 1 }, envelope: { correlationId: "f1" } };
  await j.recordFact({ ...genuine, payload: { element: 0 }, causalTick: 10, seq: 0, factId: "fact:10:0", envelope: { correlationId: "f0" } });
  await j.recordFact(genuine); // упадёт → дыра seq 1
  j.noteProduced("facts", 1, "kernel", "dense-from-0", contentHash(genuine)); // evidence подлинного факта
  drv.dead = false;
  j.setReissueSource("facts", { reissue: () => ({ ...genuine, payload: { element: 999 } }) }); // источник лжёт
  const f = await j.finalize({ execution: "COMPLETED" });
  assert(f.repairHistory.some((h) => h.outcome === "mismatch"), "подмена при reissue не обнаружена");
  assert(f.auditStatus === "INCOMPLETE", "подменённый факт закрыл дыру");
  const facts = f.manifest.streams.find((s) => s.streamId === "facts");
  assert(JSON.stringify(facts.permanentRanges) === JSON.stringify([{ from: 1, to: 1 }]), "mismatch не стал permanent");
});

await check("Э7: finalCheckpointRef с неверным тиком → E_SEAL_REQUIREMENTS", async () => {
  const j = await openJournal();
  await applyCommandChain(j, 100);
  await j.appendCheckpoint("final", { tick: 49999 });
  await expectCode(() => j.finalize({ execution: "ABORTED", terminationReason: "стоп", terminalTick: 50000, finalCheckpointRef: "checkpoint:final" }),
    "E_SEAL_REQUIREMENTS", "тик checkpoint ≠ terminalTick");
});

await check("Э8: неудачное открытие не оставляет остатка — _runRef null, повтор чист", async () => {
  class DeadProtocolDriver extends InMemoryDriver {
    constructor() { super(); this.dead = true; }
    async putIfAbsent(record, canonical) {
      if (this.dead && record.kind === "protocol") { const e = new Error("x"); e.code = "E_IO"; throw e; }
      return super.putIfAbsent(record, canonical);
    }
  }
  const drv = new DeadProtocolDriver();
  const j = new RunJournal(drv, { validateRecord });
  try { await j.open(clone(PROTOCOL), clone(ENV)); throw new Error("открылся"); } catch (e) { assert(e.code === "E_IO", e.code); }
  assert(j._runRef === null && j.state === "created" && j.hashes === null, "остаток неудачного открытия");
  drv.dead = false;
  const h = await j.open(clone(PROTOCOL), clone(ENV));
  assert(j.state === "open" && h.documentHash.length === 64, "повторное открытие не удалось");
});

console.log(`\nИтог шага 5: ${pass} прошло, ${fail} провалено.`);
process.exit(fail === 0 ? 0 : 1);
