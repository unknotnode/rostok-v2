/**
 * validate.mjs — валидатор схем шага 0. Без зависимостей.
 *
 * Реализует ПОДМНОЖЕСТВО JSON Schema draft 2020-12, достаточное для схем
 * протокола. Дисциплина принуждения: любое ключевое слово вне поддержанного
 * подмножества — ОШИБКА СХЕМЫ (throw), не молчаливый пропуск. Схема не имеет
 * права дрейфовать за пределы того, что валидатор реально проверяет.
 *
 * Поддержано: type, const, enum, required, properties,
 * additionalProperties (false | schema), propertyNames, items, minItems,
 * maxItems, uniqueItems, minimum, maximum, exclusiveMinimum,
 * exclusiveMaximum, minLength, maxLength, pattern, oneOf, $ref (локальный
 * "#/$defs/..."), $defs.
 *
 * Плюс кросс-проверки (crossChecks), которые JSON Schema выразить не может:
 * они кодируют нормативные законы Д1–Д4 / kernel-abi/2 §9 C6, C8.
 */

const META_KEYS = new Set(["$schema", "$id", "title", "description", "$comment", "examples", "default"]);
import { causalStateHash } from "./causal-hash.mjs";
const SUPPORTED = new Set([
  "type", "const", "enum", "required", "properties", "additionalProperties",
  "propertyNames", "items", "minItems", "maxItems", "uniqueItems",
  "minimum", "maximum", "exclusiveMinimum", "exclusiveMaximum",
  "minLength", "maxLength", "pattern", "oneOf", "$ref", "$defs",
]);

export class SchemaError extends Error {}

function assertSupported(schema, where) {
  for (const k of Object.keys(schema)) {
    if (!META_KEYS.has(k) && !SUPPORTED.has(k)) {
      throw new SchemaError(`схема ${where}: неподдержанное ключевое слово "${k}" — расширь валидатор или упрости схему`);
    }
  }
}

function resolveRef(ref, root, where) {
  if (!ref.startsWith("#/")) throw new SchemaError(`схема ${where}: поддержаны только локальные $ref, получено "${ref}"`);
  let node = root;
  for (const part of ref.slice(2).split("/")) {
    if (node == null || !(part in node)) throw new SchemaError(`схема ${where}: $ref "${ref}" не разрешается`);
    node = node[part];
  }
  return node;
}

function typeOf(v) {
  if (v === null) return "null";
  if (Array.isArray(v)) return "array";
  if (Number.isInteger(v)) return "integer"; // integer также проходит как number
  return typeof v;
}

function deepEqual(a, b) {
  return JSON.stringify(a) === JSON.stringify(b);
}

/**
 * validateNode — возвращает массив ошибок вида { path, message }.
 */
function validateNode(schema, data, root, path, errors) {
  assertSupported(schema, path || "/");

  if (schema.$ref) {
    return validateNode(resolveRef(schema.$ref, root, path), data, root, path, errors);
  }

  if (schema.oneOf) {
    const branchErrors = schema.oneOf.map((branch) => {
      const errs = [];
      validateNode(branch, data, root, path, errs);
      return errs;
    });
    const matches = branchErrors.filter((e) => e.length === 0).length;
    if (matches === 1) return errors;
    if (matches > 1) {
      errors.push({ path, message: `oneOf: подошло ${matches} вариантов, ожидался ровно один` });
      return errors;
    }
    // ни один не подошёл: репортим ошибки ближайшей ветки (минимум ошибок)
    let best = branchErrors[0];
    for (const e of branchErrors) if (e.length < best.length) best = e;
    errors.push({ path, message: "oneOf: ни один вариант не подошёл; ближайший вариант:" });
    errors.push(...best);
    return errors;
  }

  if ("const" in schema) {
    if (!deepEqual(data, schema.const)) {
      errors.push({ path, message: `ожидалось точно ${JSON.stringify(schema.const)}, получено ${JSON.stringify(data)}` });
    }
    return errors;
  }

  if (schema.enum) {
    if (!schema.enum.some((v) => deepEqual(v, data))) {
      errors.push({ path, message: `значение ${JSON.stringify(data)} не входит в enum [${schema.enum.map((v) => JSON.stringify(v)).join(", ")}]` });
    }
    return errors;
  }

  const t = typeOf(data);
  if (schema.type) {
    const ok = schema.type === t || (schema.type === "number" && (t === "integer"));
    if (!ok) {
      errors.push({ path, message: `ожидался тип ${schema.type}, получен ${t}` });
      return errors; // дальше проверять бессмысленно
    }
  }

  if (t === "string") {
    if (schema.minLength !== undefined && data.length < schema.minLength)
      errors.push({ path, message: `строка короче minLength=${schema.minLength}` });
    if (schema.maxLength !== undefined && data.length > schema.maxLength)
      errors.push({ path, message: `строка длиннее maxLength=${schema.maxLength}` });
    if (schema.pattern !== undefined && !new RegExp(schema.pattern).test(data))
      errors.push({ path, message: `строка "${data}" не соответствует pattern ${schema.pattern}` });
  }

  if (t === "integer" || t === "number") {
    if (schema.minimum !== undefined && data < schema.minimum)
      errors.push({ path, message: `${data} < minimum ${schema.minimum}` });
    if (schema.maximum !== undefined && data > schema.maximum)
      errors.push({ path, message: `${data} > maximum ${schema.maximum}` });
    if (schema.exclusiveMinimum !== undefined && data <= schema.exclusiveMinimum)
      errors.push({ path, message: `${data} <= exclusiveMinimum ${schema.exclusiveMinimum}` });
    if (schema.exclusiveMaximum !== undefined && data >= schema.exclusiveMaximum)
      errors.push({ path, message: `${data} >= exclusiveMaximum ${schema.exclusiveMaximum}` });
  }

  if (t === "array") {
    if (schema.minItems !== undefined && data.length < schema.minItems)
      errors.push({ path, message: `массив короче minItems=${schema.minItems}` });
    if (schema.maxItems !== undefined && data.length > schema.maxItems)
      errors.push({ path, message: `массив длиннее maxItems=${schema.maxItems}` });
    if (schema.uniqueItems) {
      const seen = new Set(data.map((v) => JSON.stringify(v)));
      if (seen.size !== data.length) errors.push({ path, message: "uniqueItems: дубликаты в массиве" });
    }
    if (schema.items) {
      data.forEach((item, i) => validateNode(schema.items, item, root, `${path}/${i}`, errors));
    }
  }

  if (t === "object") {
    const props = schema.properties ?? {};
    for (const req of schema.required ?? []) {
      if (!(req in data)) errors.push({ path, message: `отсутствует обязательное поле "${req}"` });
    }
    for (const [key, value] of Object.entries(data)) {
      if (schema.propertyNames) {
        validateNode(schema.propertyNames, key, root, `${path}/(имя:${key})`, errors);
      }
      if (key in props) {
        validateNode(props[key], value, root, `${path}/${key}`, errors);
      } else if (schema.additionalProperties === false) {
        errors.push({ path, message: `неожиданное поле "${key}"` });
      } else if (schema.additionalProperties && typeof schema.additionalProperties === "object") {
        validateNode(schema.additionalProperties, value, root, `${path}/${key}`, errors);
      }
    }
  }

  return errors;
}

/* ── Кросс-проверки нормативных законов (за пределами JSON Schema) ── */

export const crossChecks = {
  "kernel-metadata": (d, errors) => {
    const moves = d.moves ?? [];
    // П1: moveClasses ≡ множество классов из moves (оба направления).
    const declared = new Set(d.moveClasses ?? []);
    const derived = new Set(moves.map((m) => m.class));
    for (const c of derived) if (!declared.has(c)) {
      errors.push({ path: "/moveClasses", message: `П1: класс "${c}" присутствует в moves, но не объявлен в moveClasses` });
    }
    for (const c of declared) if (!derived.has(c)) {
      errors.push({ path: "/moveClasses", message: `П1: класс "${c}" объявлен в moveClasses, но не имеет ни одного move` });
    }
    // Уникальность id ходов.
    const ids = new Set();
    moves.forEach((m, i) => {
      if (ids.has(m.id)) errors.push({ path: `/moves/${i}/id`, message: `дубликат id хода "${m.id}"` });
      ids.add(m.id);
    });
    // П2: вектор конструктивных возможностей согласован с ходами.
    const has = (cls) => moves.some((m) => m.class === cls);
    const g = d.growthCapabilities ?? {};
    const pairs = [
      ["entityGrowth", "create-entity"],
      ["relationGrowth", "create-relation"],
      ["dofActivation", "activate-dof"],
      ["stateExtension", "extend-logical-state"],
    ];
    for (const [cap, cls] of pairs) {
      if (typeof g[cap] === "boolean" && g[cap] !== has(cls)) {
        errors.push({ path: `/growthCapabilities/${cap}`, message: `П2: ${cap}=${g[cap]} противоречит наличию хода класса ${cls} (${has(cls)})` });
      }
    }
    // П2: growthCapable — производное OR всех пяти возможностей.
    const orAll = ["entityGrowth", "relationGrowth", "dofActivation", "stateExtension", "capacityExtension"]
      .some((k) => g[k] === true);
    if (typeof d.growthCapable === "boolean" && d.growthCapable !== orAll) {
      errors.push({ path: "/growthCapable", message: `П2: growthCapable=${d.growthCapable} противоречит OR(growthCapabilities)=${orAll}` });
    }
    // П4: causal × numericClass → допустимые dtype.
    (d.buffers ?? []).forEach((b, i) => {
      if (b.causal === true && b.numericClass === "continuous" && b.dtype !== "f64") {
        errors.push({ path: `/buffers/${i}/dtype`, message: `П4: буфер "${b.name}" причинный непрерывный — только f64, получен ${b.dtype}` });
      }
      if (b.causal === true && b.numericClass === "discrete" && !["u8", "u16", "u32"].includes(b.dtype)) {
        errors.push({ path: `/buffers/${i}/dtype`, message: `П4: буфер "${b.name}" причинный дискретный — u8/u16/u32, получен ${b.dtype}` });
      }
    });
    // Р1: deadRegions ссылаются на существующие буферы.
    const bufNames = new Set((d.buffers ?? []).map((b) => b.name));
    (d.deadRegions ?? []).forEach((r, i) => {
      for (const bn of r.buffers ?? []) {
        if (!bufNames.has(bn)) {
          errors.push({ path: `/deadRegions/${i}/buffers`, message: `мёртвая область "${r.id}" ссылается на несуществующий буфер "${bn}"` });
        }
      }
    });
    // П7: dormant адресует существующий буфер и не выходит за components.
    const bufByName = new Map((d.buffers ?? []).map((b) => [b.name, b]));
    (d.dormant ?? []).forEach((s, i) => {
      const buf = bufByName.get(s.storage?.buffer);
      if (!buf) {
        errors.push({ path: `/dormant/${i}/storage/buffer`, message: `спящая компонента "${s.id}" ссылается на несуществующий буфер "${s.storage?.buffer}"` });
        return;
      }
      const end = (s.storage.componentOffset ?? 0) + (s.storage.componentCount ?? 1);
      if (end > (buf.components ?? 1)) {
        errors.push({ path: `/dormant/${i}/storage`, message: `диапазон компонент [${s.storage.componentOffset}, ${end}) выходит за components=${buf.components} буфера "${buf.name}"` });
      }
    });
  },
  "kernel-state": (d, errors) => {
    // П5/П6: побайтовая согласованность и NaN-политика — той же эталонной
    // реализацией, что и хэш (никакой второй трактовки канона).
    try {
      causalStateHash(d);
    } catch (e) {
      errors.push({ path: "/buffers", message: `${e.code ?? "E_STATE"}: ${e.message}` });
    }
  },
  "step-report": (d, errors) => {
    if (Number.isInteger(d.tickStart) && Number.isInteger(d.tickEnd) && d.tickEnd < d.tickStart + 1) {
      errors.push({ path: "/tickEnd", message: `tickEnd=${d.tickEnd} < tickStart+1=${d.tickStart + 1}` });
    }
    (d.facts ?? []).forEach((f, i) => {
      if (Number.isInteger(f.tick) && (f.tick <= d.tickStart || f.tick > d.tickEnd)) {
        errors.push({ path: `/facts/${i}/tick`, message: `тик факта ${f.tick} вне диапазона (${d.tickStart}, ${d.tickEnd}]` });
      }
    });
  },
  "experiment-protocol": (d, errors) => {
    const cmds = d.commands ?? [];
    for (let i = 1; i < cmds.length; i++) {
      if (cmds[i].tick < cmds[i - 1].tick) {
        errors.push({ path: `/commands/${i}/tick`, message: "команды обязаны быть отсортированы по тику" });
        break;
      }
    }
    const st = d.manifest?.snapshotTransport;
    if (st?.mode === "shared" && d.environment?.crossOriginIsolated !== true) {
      errors.push({ path: "/environment/crossOriginIsolated", message: "Д4.5: режим shared требует подтверждённой cross-origin isolation в environment" });
    }
  },
};

/**
 * Публичный вход: validate(schema, data, schemaName?) → { ok, errors }.
 */
export function validate(schema, data, schemaName) {
  const errors = [];
  validateNode(schema, data, schema, "", errors);
  if (errors.length === 0 && schemaName && crossChecks[schemaName]) {
    crossChecks[schemaName](data, errors);
  }
  return { ok: errors.length === 0, errors };
}
