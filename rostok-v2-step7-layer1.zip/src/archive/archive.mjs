/**
 * archive.mjs — ExperimentArchive (шаг 4, ревизия после приёмки).
 *
 * Законы:
 * - ArchiveValue: только строгие значения, E_ARCHIVE_VALUE вместо
 *   молчаливой нормализации (lib/canonical);
 * - contentHash — SHA-256 канонических байтов
 *   (archive-content/sha256-json-v1); FNV — лишь диагностическая подпись;
 * - append-only обеспечивает ДРАЙВЕР атомарным putIfAbsent со сравнением
 *   канонических байтов: ABSENT→INSERTED, PRESENT_SAME→IDEMPOTENT,
 *   PRESENT_DIFFERENT→CONFLICT;
 * - журнал КОМАНД — причинный, fail-closed: команда сначала надёжно
 *   записывается, только потом применяется; недоступный журнал ⇒ команда
 *   НЕ применяется (E_COMMAND_JOURNAL). Наблюдательные записи —
 *   fail-open (infra-failure, физика не видит);
 * - машина состояний: CREATED → OPEN → FINALIZED → CLOSED; после
 *   FINALIZED причинные записи запрещены, post-analysis — только
 *   revision с parentRunIdentityHash;
 * - три идентичности: documentHash (весь документ), experimentIdentityHash
 *   (семантическая проекция без id/createdAt/environment),
 *   runIdentityHash (experimentIdentityHash + причинный журнал команд).
 */
import { archiveValue, canonicalBytes, contentHash, deepFreeze, CONTENT_HASH_ID } from "../lib/canonical.mjs";

export const RECORD_KINDS = ["protocol", "fact", "claim", "failure", "checkpoint", "command", "command-result", "result", "infra-failure", "revision"];

/** Нормативная семантическая проекция эксперимента (identity, не annotation). */
export const EXPERIMENT_IDENTITY_FIELDS = ["protocol", "kernel", "runtime", "manifest", "seed", "commands", "detectors", "preregistered", "expected"];

export class ArchiveConflictError extends Error {
  constructor(message) { super(message); this.code = "E_ARCHIVE_CONFLICT"; }
}
export class ArchiveStateError extends Error {
  constructor(message) { super(message); this.code = "E_ARCHIVE_STATE"; }
}
export class CommandJournalError extends Error {
  constructor(message) { super(message); this.code = "E_COMMAND_JOURNAL"; }
}

/**
 * Драйвер по умолчанию. putIfAbsent атомарен: между проверкой и записью
 * нет await — интерливинг невозможен внутри операции.
 */
export class InMemoryDriver {
  constructor() { this._records = new Map(); this._order = []; }
  async putIfAbsent(record, canonical) {
    const existing = this._records.get(record.id);
    if (existing) {
      return existing.canonical === canonical
        ? { status: "IDEMPOTENT", record: existing.record }
        : { status: "CONFLICT", record: existing.record };
    }
    this._records.set(record.id, { record, canonical });
    this._order.push(record.id);
    return { status: "INSERTED", record };
  }
  async get(id) { return this._records.get(id)?.record ?? null; }
  async list() { return this._order.map((id) => this._records.get(id).record); }
}

export class ExperimentArchive {
  constructor(driver = new InMemoryDriver(), { maxInfraRetained = 256, validateProtocol = null } = {}) {
    this._driver = driver;
    this._validateProtocol = validateProtocol;
    this._state = "created"; // created | open | finalized | closed
    this._archiveSeq = 0;
    this._protocol = null;
    this._hashes = null;     // { documentHash, experimentIdentityHash }
    this._runIdentityHash = null;
    this._commandSeq = 0;            // К2: только монотонно вверх, пропуски честны
    this._commandQueue = Promise.resolve(); // К2: сериализация причинного журнала
    this.infraFailures = [];
    this.infraFailureCount = 0;
    this._maxInfraRetained = maxInfraRetained;
  }

  get state() { return this._state; }
  get protocol() { return this._protocol; }
  get hashes() { return this._hashes; }
  get hashAlgorithm() { return CONTENT_HASH_ID; }

  _guard(op, allowed) {
    if (!allowed.includes(this._state)) {
      throw new ArchiveStateError(`${op} в состоянии ${this._state} запрещён`);
    }
  }

  /**
   * К1: транзакционное открытие — fail-closed старт эксперимента.
   * Всё вычисляется локально; состояние OPEN присваивается ТОЛЬКО после
   * подтверждённой записи протокола. При отказе экземпляр остаётся
   * CREATED (protocol и hashes = null) и может быть открыт повторно.
   */
  async openExperiment(protocolDoc) {
    this._guard("openExperiment", ["created"]);
    if (this._validateProtocol) {
      const r = this._validateProtocol(protocolDoc);
      if (!r.ok) throw new ArchiveConflictError(`протокол невалиден: ${r.errors.map((e) => `${e.path}: ${e.message}`).join("; ")}`);
    }
    const value = deepFreeze(archiveValue(protocolDoc));
    const documentHash = contentHash(value);
    const projection = {};
    for (const f of EXPERIMENT_IDENTITY_FIELDS) if (f in value) projection[f] = value[f];
    const experimentIdentityHash = contentHash(projection);
    // запись до присвоения состояния:
    await this._append("protocol", `protocol:${value.id}`, value, { tick: -1, seq: -1 });
    this._protocol = value;
    this._hashes = deepFreeze({ documentHash, experimentIdentityHash });
    this._state = "open";
    return this._hashes;
  }

  async _append(kind, id, body, order) {
    if (!RECORD_KINDS.includes(kind)) throw new ArchiveConflictError(`неизвестный вид записи: ${kind}`);
    const value = archiveValue(body); // E_ARCHIVE_VALUE — до любой записи
    const canonical = canonicalBytes(value);
    const record = deepFreeze({
      id, kind,
      contentHash: contentHash(value),
      hashAlgorithm: CONTENT_HASH_ID,
      order: { tick: order.tick, seq: order.seq, archiveSeq: this._archiveSeq++ },
      body: deepFreeze(value),
    });
    const res = await this._driver.putIfAbsent(record, canonical);
    if (res.status === "CONFLICT") {
      throw new ArchiveConflictError(`запись ${id} уже существует с иным содержимым`);
    }
    return res.record;
  }

  /** Fail-open путь наблюдательного контура. */
  async _appendSafe(kind, id, body, order) {
    try {
      return await this._append(kind, id, body, order);
    } catch (e) {
      const inf = deepFreeze({ code: e.code ?? "E_ARCHIVE_WRITE", message: e.message, id, kind });
      this.infraFailureCount++;
      this.infraFailures.push(inf);
      if (this.infraFailures.length > this._maxInfraRetained) {
        this.infraFailures.splice(0, this.infraFailures.length - this._maxInfraRetained);
      }
      try {
        await this._append("infra-failure", `infra:${this._archiveSeq}`, inf, { tick: order.tick, seq: order.seq });
      } catch { /* сбой регистрации сбоя не покидает контур */ }
      return null;
    }
  }

  /* ── причинные записи (запрещены после FINALIZED) ── */

  appendFact(fact) {
    this._guard("appendFact", ["open"]);
    const id = `fact:${fact.tick}:${fact.seq ?? 0}:${contentHash(archiveValue(fact)).slice(0, 12)}`;
    return this._appendSafe("fact", id, fact, { tick: fact.tick, seq: fact.seq ?? 0 });
  }

  /**
   * Причинный журнал команд — FAIL-CLOSED. Ошибка записи НЕ поглощается:
   * вызывающая сторона обязана НЕ применять команду.
   */
  async appendCommand(cmd) {
    this._guard("appendCommand", ["open"]);
    // К2: причинный журнал сериализован собственной FIFO-очередью;
    // commandSeq резервируется монотонно и НИКОГДА не откатывается —
    // неудачная попытка оставляет честный пропуск, повторное
    // использование номера невозможно ни при каком порядке завершения.
    const run = async () => {
      this._guard("appendCommand", ["open"]);
      const value = archiveValue(cmd);
      const seq = ++this._commandSeq;
      const commandId = `command:${seq}:${contentHash(value).slice(0, 12)}`;
      try {
        const rec = await this._append("command", commandId, value, { tick: cmd.tick, seq });
        return { commandId, seq, record: rec };
      } catch (e) {
        throw new CommandJournalError(`журнал команд недоступен, команда НЕ применяется (seq ${seq} — пропуск): ${e.message}`);
      }
    };
    const p = this._commandQueue.then(run);
    this._commandQueue = p.then(() => undefined, () => undefined);
    return p;
  }

  /** Связь предзаписи и факта применения: applied | rejected | failed. */
  appendCommandResult(commandId, result) {
    this._guard("appendCommandResult", ["open"]);
    return this._append("command-result", `${commandId}:result`, { commandId, ...result },
      { tick: result.tick ?? -1, seq: 0 });
  }

  appendCheckpoint(name, state) {
    this._guard("appendCheckpoint", ["open"]);
    return this._appendSafe("checkpoint", `checkpoint:${name}`, state, { tick: state.tick, seq: 0 });
  }

  /* ── наблюдательные записи (fail-open); стабильный eventId — из провенанса ── */

  appendClaim(claim) {
    this._guard("appendClaim", ["open"]);
    const p = claim.provenance ?? {};
    const id = `claim:${p.detectorId}:${p.configHash}:${p.snapshotTick}`;
    return this._appendSafe("claim", id, claim, { tick: claim.tick, seq: 0 });
  }
  appendFailure(failure) {
    this._guard("appendFailure", ["open"]);
    const p = failure.provenance ?? {};
    const id = `failure:${p.detectorId}:${p.configHash}:${p.snapshotTick}:${failure.payload?.seq ?? 0}`;
    return this._appendSafe("failure", id, failure, { tick: failure.tick, seq: failure.payload?.seq ?? 0 });
  }

  /* ── финализация и жизненный цикл ── */

  async finalize(result) {
    this._guard("finalize", ["open"]);
    const commands = (await this._driver.list())
      .filter((r) => r.kind === "command")
      .map((r) => ({ id: r.id, body: r.body }));
    const results = (await this._driver.list())
      .filter((r) => r.kind === "command-result")
      .map((r) => r.body);
    this._runIdentityHash = contentHash({
      experimentIdentityHash: this._hashes.experimentIdentityHash,
      commands, commandResults: results,
    });
    await this._append("result", `result:${this._protocol.id}`,
      { ...archiveValue(result), runIdentityHash: this._runIdentityHash },
      { tick: Number.MAX_SAFE_INTEGER, seq: 0 });
    this._state = "finalized";
    return this._runIdentityHash;
  }

  /** Post-analysis после финализации: только revision с родителем. */
  appendRevision(body) {
    this._guard("appendRevision", ["finalized"]);
    if (!this._runIdentityHash) throw new ArchiveStateError("revision до финализации невозможна");
    return this._append("revision", `revision:${this._archiveSeq}`,
      { parentRunIdentityHash: this._runIdentityHash, ...archiveValue(body) },
      { tick: Number.MAX_SAFE_INTEGER, seq: this._archiveSeq });
  }

  dispose() { this._state = "closed"; }

  async replay() {
    const rows = (await this._driver.list())
      .filter((r) => ["fact", "claim", "failure", "command"].includes(r.kind));
    rows.sort((a, b) =>
      (a.order.tick - b.order.tick) || (a.order.seq - b.order.seq) || (a.order.archiveSeq - b.order.archiveSeq));
    return rows;
  }

  async records() { return this._driver.list(); }
}

/** Sink-адаптер для ObserverRunner. */
export function archiveSink(archive) {
  return {
    appendClaim: (c) => archive.appendClaim(c),
    appendFailure: (f) => archive.appendFailure(f),
  };
}

export { contentHash, canonicalBytes };
