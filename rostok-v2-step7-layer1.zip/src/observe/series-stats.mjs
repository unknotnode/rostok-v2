/**
 * series-stats.mjs — первый анализатор лаборатории (шаг 3, ревизия
 * после приёмки: поправки 1–4).
 *
 * Онлайн-статистика канала input представления series-view@1: среднее,
 * дисперсия, L2-норма, lag-1 (по снимкам) корреляция Пирсона.
 *
 * Дисциплина:
 * - вход — ТОЛЬКО read-only accessor (length, getInput/getHist/getMemory)
 *   и заголовок; массивов, Host, Kernel, пула не существует в области
 *   видимости анализатора;
 * - Float64, фиксированный порядок редукций, компенсированные суммы
 *   Ноймайера (Kahan–Babuška);
 * - длина берётся из представления (view.length), не из константы;
 * - численная защита sqrt — ЯВНАЯ версионированная политика: отрицательная
 *   дисперсия в пределах negVarClampEps зажимается в 0, за пределами —
 *   E_OBSERVER_NUMERIC (молчаливого clamp нет);
 * - checkpoint несёт observerStateFormat, parameters и configHash;
 *   restore выполняет exact-проверку конфигурации → E_STATE_FORMAT;
 * - без Buffer: бинарное состояние через средонезависимый lib/bytes.
 */
import { f64ArrayToBase64, base64ToF64Array } from "../lib/bytes.mjs";
import { contentHash, toValue, deepFreeze } from "../lib/canonical.mjs";

const STATE_FORMAT = "series-stats-state/1";

/** Сумма Ноймайера; порядок обхода i=0…length-1 — закон. */
function kahan(n, term) {
  let s = 0, c = 0;
  for (let i = 0; i < n; i++) {
    const v = term(i);
    const t = s + v;
    if (Math.abs(s) >= Math.abs(v)) c += (s - t) + v;
    else c += (v - t) + s;
    s = t;
  }
  return s + c;
}

export class SeriesStatsObserver {
  constructor(params = {}) {
    const parameters = deepFreeze(toValue({
      channel: "input",
      lagSnapshots: 1,
      negVarClampEps: 1e-18,   // версионированная численная политика
      ...params,
    }));
    this.descriptor = {
      detectorId: "analyzer.series-stats",
      version: "1.0.0",
      parameters,
    };
    this._configHash = contentHash({
      detectorId: this.descriptor.detectorId,
      detectorVersion: this.descriptor.version,
      parameters,
    });
    this._prevInput = null;
    this._prevTick = null;
    this._snapshotsSeen = 0;
  }

  get configHash() { return this._configHash; }

  _guardVariance(v, what) {
    if (v >= 0) return v;
    if (v >= -this.descriptor.parameters.negVarClampEps) return 0; // явная политика
    const e = new Error(`${what} = ${v}: отрицательная дисперсия за пределами negVarClampEps`);
    e.code = "E_OBSERVER_NUMERIC";
    throw e;
  }

  observe(view, header) {
    const n = view.length;
    const mean = kahan(n, (i) => view.getInput(i)) / n;
    const variance = this._guardVariance(
      kahan(n, (i) => (view.getInput(i) - mean) * (view.getInput(i) - mean)) / n, "variance");
    const l2 = Math.sqrt(kahan(n, (i) => view.getInput(i) * view.getInput(i)));

    let lagCorr = null;
    if (this._prevInput && this._prevInput.length === n) {
      const p = this._prevInput;
      const meanP = kahan(n, (i) => p[i]) / n;
      const cov = kahan(n, (i) => (view.getInput(i) - mean) * (p[i] - meanP)) / n;
      const varP = this._guardVariance(
        kahan(n, (i) => (p[i] - meanP) * (p[i] - meanP)) / n, "varP");
      const denom = Math.sqrt(variance * varP);
      lagCorr = denom > 0 ? cov / denom : null;
    }

    // Собственная копия входа — из геттеров; ссылок на снимок не удерживается.
    const copy = new Float64Array(n);
    for (let i = 0; i < n; i++) copy[i] = view.getInput(i);
    this._prevInput = copy;
    this._prevTick = header.tick;
    this._snapshotsSeen += 1;

    // Публикацию в значение выполняет ObserverRunner; здесь — только данные.
    return {
      tier: "claim",
      type: "claim.measurement.series-stats",
      tick: header.tick,
      payload: { mean, variance, l2, lagCorr, channel: "input", length: n },
    };
  }

  /** Полный checkpoint: формат, конфигурация, состояние (поправка 3). */
  checkpoint() {
    return {
      observerStateFormat: STATE_FORMAT,
      detectorId: this.descriptor.detectorId,
      detectorVersion: this.descriptor.version,
      parameters: toValue(this.descriptor.parameters),
      configHash: this._configHash,
      snapshotsSeen: this._snapshotsSeen,
      prevTick: this._prevTick,
      prevLength: this._prevInput ? this._prevInput.length : null,
      prevInput: this._prevInput ? f64ArrayToBase64(this._prevInput) : null,
    };
  }

  restore(state) {
    const exact = (field, got, want) => {
      if (got !== want) {
        const e = new Error(`${field}: ожидалось ${JSON.stringify(want)}, получено ${JSON.stringify(got)}`);
        e.code = "E_STATE_FORMAT";
        throw e;
      }
    };
    exact("observerStateFormat", state.observerStateFormat, STATE_FORMAT);
    exact("detectorId", state.detectorId, this.descriptor.detectorId);
    exact("detectorVersion", state.detectorVersion, this.descriptor.version);
    // Exact-проверка конфигурации: несовпадение параметров — ошибка,
    // молчаливого продолжения не существует. Migration policy не объявлена.
    exact("configHash", state.configHash, this._configHash);
    this._snapshotsSeen = state.snapshotsSeen;
    this._prevTick = state.prevTick;
    if (state.prevInput === null) { this._prevInput = null; return; }
    this._prevInput = base64ToF64Array(state.prevInput, state.prevLength, "prevInput");
  }
}

/** Тестовый наблюдатель-диверсант: падает на каждом снимке. */
export class CrashingObserver {
  constructor() {
    this.descriptor = { detectorId: "analyzer.crash-test", version: "1.0.0", parameters: {} };
    this.calls = 0;
  }
  observe() {
    this.calls++;
    throw new Error("намеренное исключение анализатора");
  }
}
