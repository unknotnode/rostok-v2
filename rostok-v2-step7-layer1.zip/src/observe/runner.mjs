/**
 * runner.mjs — ObserverRunner (ревизия после приёмки шага 3).
 *
 * Гарантии:
 * - наблюдатель получает только read-only accessor представления и
 *   значение заголовка; Host/Kernel/пул недостижимы;
 * - каждый handle возвращается в try/finally ВСЕГДА;
 * - исключение одного наблюдателя не трогает физику, транспорт и соседей;
 * - ГРАНИЦА ПУБЛИКАЦИИ (поправка 2): claim и failure становятся
 *   неизменяемыми ЗНАЧЕНИЯМИ — параметры детектора снимаются в момент
 *   регистрации (замороженная копия + configHash); последующая мутация
 *   descriptor не меняет ранее опубликованное;
 * - failures — полноценные события claim.observer.failure с провенансом;
 * - память ограничена (поправка «sink»): полный поток уходит в sink
 *   (append-only интерфейс), runner держит только кольцо последних
 *   maxRetained записей и счётчики.
 */
import { contentHash, archiveValue, deepFreeze, publishValue } from "../lib/canonical.mjs";

export class ObserverRunner {
  constructor(pool, { viewId, sink = null, maxRetained = 4096 }) {
    this._pool = pool;
    this._viewId = viewId;
    this._sink = sink;
    this._maxRetained = maxRetained;
    this._observers = [];
    this.claims = [];
    this.failures = [];
    this.claimCount = 0;
    this.failureCount = 0;
    this.infraFailures = [];
  }

  register(observer) {
    const d = observer.descriptor ?? {};
    // Снимок конфигурации в момент регистрации: замороженное значение и хэш.
    const parameters = deepFreeze(archiveValue(d.parameters ?? {}));
    const registration = deepFreeze({
      detectorId: d.detectorId ?? "unknown",
      detectorVersion: d.version ?? "0.0.0",
      parameters,
      configHash: contentHash({ detectorId: d.detectorId ?? "unknown", detectorVersion: d.version ?? "0.0.0", parameters }),
    });
    this._observers.push({ observer, registration });
  }

  _retain(list, item) {
    list.push(item);
    if (list.length > this._maxRetained) list.splice(0, list.length - this._maxRetained);
  }

  async _emit(kind, record) {
    this._retain(kind === "claim" ? this.claims : this.failures, record);
    if (kind === "claim") this.claimCount++; else this.failureCount++;
    if (this._sink) {
      try {
        await (kind === "claim" ? this._sink.appendClaim(record) : this._sink.appendFailure(record));
      } catch (e) {
        // Отказ архива — инфраструктурный сбой наблюдательного контура;
        // физика его не видит, но сбой регистрируется явно.
        this._retain(this.infraFailures, publishValue({
          code: e.code ?? "E_ARCHIVE_WRITE",
          message: e.message,
          record: { kind, tick: record.tick, seq: record.payload?.seq ?? null },
        }));
      }
    }
  }

  /** Забирает все доставленные снимки и прогоняет наблюдателей. */
  async pump() {
    const handles = this._pool.takeAll();
    for (const handle of handles) {
      try {
        const headerValue = publishValue(handle.header);
        let view = null;
        for (const { observer, registration } of this._observers) {
          try {
            if (view === null) view = handle.view(this._viewId);
            const raw = observer.observe(view, headerValue);
            if (raw) {
              // Граница публикации: значение + провенанс из регистрации.
              const claim = publishValue({
                ...archiveValue(raw),
                provenance: {
                  detectorId: registration.detectorId,
                  detectorVersion: registration.detectorVersion,
                  parameters: registration.parameters,
                  configHash: registration.configHash,
                  snapshotTick: headerValue.tick,
                },
              });
              await this._emit("claim", claim);
            }
          } catch (e) {
            const failure = publishValue({
              tier: "claim",
              type: "claim.observer.failure",
              tick: headerValue.tick,
              payload: { code: e.code ?? "E_OBSERVER_FAILURE", message: e.message, seq: headerValue.seq },
              provenance: {
                detectorId: registration.detectorId,
                detectorVersion: registration.detectorVersion,
                parameters: registration.parameters,
                configHash: registration.configHash,
                snapshotTick: headerValue.tick,
              },
            });
            await this._emit("failure", failure);
          }
        }
      } finally {
        handle.release();
      }
    }
    return handles.length;
  }
}
