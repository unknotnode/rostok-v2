/**
 * worker-entry.mjs — сторона Worker шага 2: ядро + производитель снимков.
 * Ядро reference-relaxation НЕ изменено (граница шага 2, п.4): снимок
 * строится из чистого checkpoint() и пишется в буфер пула.
 *
 * Политика Д4.3: drop, never block — нет свободного буфера ⇒ снимок
 * пропущен, счётчик dropped растёт, физика не ждёт ни одного тика.
 */
import { parentPort } from "node:worker_threads";
import { ReferenceRelaxationKernel } from "../kernels/reference-relaxation.mjs";
import { causalStateHash } from "../../tools/causal-hash.mjs";
import { encodeSeriesView, SERIES_VIEW_BYTES } from "../snapshot/encode.mjs";

const kernel = new ReferenceRelaxationKernel({ hashFn: causalStateHash });

const freeBuffers = []; // { poolId, buffer } — предоставленные потребителем
let seq = 0;
const stats = { produced: 0, dropped: 0 };

function trySnapshot() {
  const slot = freeBuffers.shift();
  if (!slot) { stats.dropped++; return false; }
  const state = kernel.checkpoint(); // чистое чтение (доказано C4)
  const header = encodeSeriesView(state, slot.buffer);
  header.seq = seq++;
  header.dropped = stats.dropped;
  stats.produced++;
  parentPort.postMessage(
    { type: "snapshot", poolId: slot.poolId, header, buffer: slot.buffer },
    [slot.buffer],
  );
  return true;
}

const extra = {
  /** step с производством снимков каждые `every` тактов внутри батча. */
  stepWithSnapshots(n, every) {
    if (!Number.isInteger(every) || every < 1) {
      const e = new Error("every: целое ≥ 1"); e.code = "E_BAD_ARG"; throw e;
    }
    const tickStart = kernel.checkpoint().tick;
    let remaining = n;
    let produced = 0, dropped0 = stats.dropped;
    while (remaining > 0) {
      const chunk = Math.min(every, remaining);
      kernel.step(chunk);
      remaining -= chunk;
      if (trySnapshot()) produced++;
    }
    const tickEnd = kernel.checkpoint().tick;
    return { tickStart, tickEnd, facts: [], snapshots: { produced, dropped: stats.dropped - dropped0 } };
  },
  snapshotNow() {
    const ok = trySnapshot();
    return { produced: ok, stats: { ...stats } };
  },
  snapshotStats() { return { ...stats, freeBuffers: freeBuffers.length }; },
};

parentPort.on("message", (msg) => {
  if (msg && msg.type === "pool.grant") {
    freeBuffers.push({ poolId: msg.poolId, buffer: msg.buffer });
    return;
  }
  const { id, method, args } = msg;
  try {
    const fn = extra[method] ?? ((...a) => kernel[method](...a));
    const result = fn(...(args ?? []));
    parentPort.postMessage({ id, ok: true, result });
  } catch (e) {
    parentPort.postMessage({ id, ok: false, error: { code: e.code ?? "E_UNKNOWN", message: e.message } });
  }
});
