/**
 * integration-worker-entry.mjs — сторона Worker для Integration Profile.
 * Идентичное ядро в воркере: доказывает DirectKernel ≡ InProcessHost ≡
 * WorkerHost по фактам и fact.seq (обязательный тест О-2). Снимки строятся
 * из чистого checkpoint() (drop, never block), как в reference-воркере.
 */
import { parentPort } from "node:worker_threads";
import { IntegrationRelaxationKernel } from "../kernels/integration-relaxation.mjs";
import { causalStateHash } from "../../tools/causal-hash.mjs";
import { encodeSeriesView } from "../snapshot/encode.mjs";

const kernel = new IntegrationRelaxationKernel({ hashFn: causalStateHash });
const freeBuffers = [];
let seq = 0;
const stats = { produced: 0, dropped: 0 };

function trySnapshot() {
  const slot = freeBuffers.shift();
  if (!slot) { stats.dropped++; return false; }
  const state = kernel.checkpoint();
  const header = encodeSeriesView(state, slot.buffer);
  header.seq = seq++; header.dropped = stats.dropped; stats.produced++;
  parentPort.postMessage({ type: "snapshot", poolId: slot.poolId, header, buffer: slot.buffer }, [slot.buffer]);
  return true;
}

const extra = {
  stepWithSnapshots(n, every) {
    if (!Number.isInteger(every) || every < 1) { const e = new Error("every ≥ 1"); e.code = "E_BAD_ARG"; throw e; }
    const tickStart = kernel.checkpoint().tick;
    let remaining = n, produced = 0, dropped0 = stats.dropped;
    const facts = [];
    while (remaining > 0) {
      const chunk = Math.min(every, remaining);
      const r = kernel.step(chunk);
      for (const f of r.facts) facts.push(f);
      remaining -= chunk;
      if (trySnapshot()) produced++;
    }
    const tickEnd = kernel.checkpoint().tick;
    return { tickStart, tickEnd, facts, snapshots: { produced, dropped: stats.dropped - dropped0 } };
  },
  snapshotNow() { return { produced: trySnapshot(), stats: { ...stats } }; },
  snapshotStats() { return { ...stats, freeBuffers: freeBuffers.length }; },
};

parentPort.on("message", (msg) => {
  if (msg && msg.type === "pool.grant") { freeBuffers.push({ poolId: msg.poolId, buffer: msg.buffer }); return; }
  const { id, method, args } = msg;
  try {
    const fn = extra[method] ?? ((...a) => kernel[method](...a));
    parentPort.postMessage({ id, ok: true, result: fn(...(args ?? [])) });
  } catch (e) {
    parentPort.postMessage({ id, ok: false, error: { code: e.code ?? "E_UNKNOWN", message: e.message } });
  }
});
