/**
 * worker-host.mjs — WorkerHost шага 2.
 *
 * Закрыты оба отложенных пункта приёмки шага 1:
 * 1) ЯВНАЯ FIFO-очередь хоста: «хост сериализует вызовы» — семантика
 *    хоста, не свойство транспорта; RemoteHost унаследует ту же очередь.
 * 2) Авария воркера (error/exit): все pending и все будущие вызовы
 *    отклоняются E_HOST_FAILURE; состояние владения пула не зависает
 *    в неопределённости — хост мёртв целиком и явно.
 *
 * Плюс низкоуровневый канал пула снимков: grantBuffer (transfer к
 * производителю) и onSnapshot (push от производителя).
 */
import { Worker } from "node:worker_threads";

export class WorkerHost {
  constructor(entryUrl) {
    this._worker = new Worker(entryUrl);
    this._pending = new Map();
    this._nextId = 1;
    this._queue = Promise.resolve();
    this._failure = null;
    this._snapshotCb = null;
    this._disposing = false;

    this._worker.on("message", (msg) => {
      if (msg && msg.type === "snapshot") {
        // Т3: исключение потребителя не имеет права вылететь из message
        // handler и повредить runtime — оно перехватывается и маршрутизируется
        // как observer failure; физика в воркере продолжает жить.
        try { this._snapshotCb?.(msg); }
        catch (e) { this._snapshotErrorCb?.(e, msg); }
        return;
      }
      const p = this._pending.get(msg.id);
      if (!p) return;
      this._pending.delete(msg.id);
      if (msg.ok) p.resolve(msg.result);
      else {
        const e = new Error(msg.error.message);
        e.code = msg.error.code;
        p.reject(e);
      }
    });
    this._worker.on("error", (err) => this._fail(`ошибка воркера: ${err.message}`));
    this._worker.on("exit", (code) => {
      if (!this._disposing) this._fail(`воркер завершился с кодом ${code}`);
      else this._fail("хост закрыт (dispose)");
    });
  }

  _fail(reason) {
    if (this._failure) return;
    const e = new Error(reason);
    e.code = "E_HOST_FAILURE";
    this._failure = e;
    for (const [, p] of this._pending) p.reject(e);
    this._pending.clear();
  }

  _call(method, args) {
    // Явная FIFO-очередь: следующий вызов уходит только после ответа на
    // предыдущий. Отказ вызова не ломает очередь и не создаёт
    // параллельного входа.
    const run = () => new Promise((resolve, reject) => {
      if (this._failure) { reject(this._failure); return; }
      const id = this._nextId++;
      this._pending.set(id, { resolve, reject });
      this._worker.postMessage({ id, method, args });
    });
    const p = this._queue.then(run);
    this._queue = p.then(() => undefined, () => undefined);
    return p;
  }

  metadata()          { return this._call("metadata", []); }
  initialize(cfg)     { return this._call("initialize", [cfg]); }
  step(n)             { return this._call("step", [n]); }
  checkpoint()        { return this._call("checkpoint", []); }
  restore(s)          { return this._call("restore", [s]); }
  shutdown()          { return this._call("shutdown", []); }
  stepWithSnapshots(n, every) { return this._call("stepWithSnapshots", [n, every]); }
  snapshotNow()       { return this._call("snapshotNow", []); }
  snapshotStats()     { return this._call("snapshotStats", []); }

  /* низкоуровневый канал пула */
  grantBuffer(poolId, buffer) {
    if (this._failure) throw this._failure;
    this._worker.postMessage({ type: "pool.grant", poolId, buffer }, [buffer]);
  }
  onSnapshot(cb) { this._snapshotCb = cb; }
  onSnapshotError(cb) { this._snapshotErrorCb = cb; }

  async dispose() {
    this._disposing = true;
    await this._worker.terminate();
    this._fail("хост закрыт (dispose)");
  }
}
