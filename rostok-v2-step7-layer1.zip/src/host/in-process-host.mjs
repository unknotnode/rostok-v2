/**
 * in-process-host.mjs — InProcessHost: чистый адаптер синхронного ядра
 * к асинхронному Host ABI. Ноль логики, ноль состояния кроме FIFO-очереди.
 */
export class InProcessHost {
  constructor(kernel) {
    this._kernel = kernel;
    this._queue = Promise.resolve();
  }
  _enqueue(fn) {
    const p = this._queue.then(fn);
    // Очередь переживает rejection: отказ одного вызова не ломает FIFO
    // и не создаёт параллельного входа в ядро.
    this._queue = p.then(() => undefined, () => undefined);
    return p;
  }
  metadata()      { return this._enqueue(() => this._kernel.metadata()); }
  initialize(cfg) { return this._enqueue(() => this._kernel.initialize(cfg)); }
  step(n)         { return this._enqueue(() => this._kernel.step(n)); }
  checkpoint()    { return this._enqueue(() => this._kernel.checkpoint()); }
  restore(s)      { return this._enqueue(() => this._kernel.restore(s)); }
  shutdown()      { return this._enqueue(() => this._kernel.shutdown()); }
  async dispose() {}
}
