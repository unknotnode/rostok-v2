/**
 * integration-relaxation.mjs — Integration Profile ядра Kernel ABI (шаг 6).
 *
 * Нормативная физика релаксации идентична Reference Profile
 * (reference-relaxation-kernel/1 rev3) — тот же закон, тот же RNG, те же
 * векторы такта. Отличие профиля ровно одно: capability causalFacts=true.
 * Ядро порождает причинный поток фактов и ВЛАДЕЕТ nextFactSeq (О-2):
 *   — курсор входит в KernelState, exact-restore и CausalStateHash
 *     (через cursors.nextFactSeq — kernel-state схема допускает без правки);
 *   — номер выделяется только при фактическом создании факта;
 *   — пустой шаг курсор не двигает;
 *   — исчерпание диапазона ⇒ E_SEQ_EXHAUSTED до мутации такта.
 *
 * Идентичность профиля (kernelName/stateFormat) отдельная — три эталона
 * Reference Profile не затрагиваются по построению.
 */

import { deriveStreamSeed, xorshift32Step, KernelError } from "./reference-relaxation.mjs";
import { contentHash } from "../lib/canonical.mjs";

const N = 64;
const KERNEL_NAME = "integration-relaxation";
const KERNEL_VERSION = "1.0.0";
const ABI_VERSION = "kernel-abi/2";
const STATE_FORMAT = "integration-relaxation-state/1";
const FACT_TYPE = "fact.field-relaxed";
const MAX_SEQ = Number.MAX_SAFE_INTEGER;
const CANONICAL_DECIMAL = /^(0|[1-9][0-9]*)$/;

function f64ToBase64(arr) {
  const bytes = new Uint8Array(arr.length * 8);
  const dv = new DataView(bytes.buffer);
  for (let i = 0; i < arr.length; i++) dv.setFloat64(i * 8, arr[i], true);
  return Buffer.from(bytes).toString("base64");
}
function base64ToF64(b64, expectedLength, where) {
  const raw = Buffer.from(b64, "base64");
  if (raw.length !== expectedLength * 8) {
    throw new KernelError("E_STATE_FORMAT", `${where}: ${raw.length} байт вместо ${expectedLength * 8}`);
  }
  const out = new Float64Array(expectedLength);
  const dv = new DataView(raw.buffer, raw.byteOffset, raw.byteLength);
  for (let i = 0; i < expectedLength; i++) out[i] = dv.getFloat64(i * 8, true);
  return out;
}

export class IntegrationRelaxationKernel {
  constructor(opts = {}) {
    this._hashFn = typeof opts.hashFn === "function" ? opts.hashFn : null;
    Object.defineProperty(this, "_hashFn", { writable: false });
    this._phase = "created";
    this._fields = null;
    this._memory = null;
    this._activePage = 0;
    this._phaseCursor = 0;
    this._rngState = 0;
    this._drive = 1.0;
    this._tick = 0;
    this._nextFactSeq = 0;      // О-2: собственность ядра
    this._emitEvery = 1;        // факт каждые emitEvery тактов (п.7/п.10 проверяемы при >1)
    this._emitChecksum = false;
  }

  metadata() {
    return {
      name: KERNEL_NAME, version: KERNEL_VERSION, abiVersion: ABI_VERSION, stateFormat: STATE_FORMAT,
      float: "f64", deterministic: true,
      causalFacts: true,                       // capability (kernel-abi 2.2.0)
      seqScope: "kernel-global",               // A2: единый владелец нумерации
      causalConfig: ["drive", "emitEvery"],    // A1: причинная конфигурация в идентичности
      factStreams: [{ id: "facts", type: FACT_TYPE, seqPolicy: "dense-from-0" }],
      moveClasses: ["modify-state"],
      moves: [{ id: "field.relax", class: "modify-state", atomic: true }],
      growthCapabilities: {
        entityGrowth: false, relationGrowth: false, dofActivation: false,
        stateExtension: false, capacityExtension: false,
      },
      growthCapable: false,
      buffers: [
        { name: "field0", dtype: "f64", components: 1, capacity: N, causal: true, numericClass: "continuous", semantics: "физический канал 0 (роль по activePage)" },
        { name: "field1", dtype: "f64", components: 1, capacity: N, causal: true, numericClass: "continuous", semantics: "физический канал 1 (роль по activePage)" },
        { name: "field2", dtype: "f64", components: 1, capacity: N, causal: true, numericClass: "continuous", semantics: "физический канал 2; в роли output мертв на границе такта" },
        { name: "memory", dtype: "f64", components: 1, capacity: N, causal: true, numericClass: "continuous", semantics: "медленная память 15/16 + 1/16" },
      ],
      dormant: [], ceilings: [{ name: "elements", limit: N }], symmetries: [], views: ["series-view@1"],
      deadRegions: [{
        id: "page.output", kind: "overwrite-before-read",
        buffers: ["field0", "field1", "field2"], roleCursor: "activePage",
        description: "буфер в роли (activePage+1) mod 3 полностью перезаписывается до чтения",
      }],
    };
  }

  initialize(config) {
    if (this._phase === "terminated") throw new KernelError("E_TERMINATED", "ядро завершено");
    if (this._phase === "ready") throw new KernelError("E_ALREADY_INITIALIZED", "повторный initialize");
    if (!config || !Number.isInteger(config.seed) || config.seed < 0 || config.seed > 0xffffffff) {
      throw new KernelError("E_CONFIG", "seed: целое u32 обязательно");
    }
    const params = config.params ?? {};
    const drive = params.drive === undefined ? 1.0 : params.drive;
    if (typeof drive !== "number" || !Number.isFinite(drive)) throw new KernelError("E_CONFIG", "params.drive: конечный f64");
    const emitEvery = params.emitEvery === undefined ? 1 : params.emitEvery;
    if (!Number.isInteger(emitEvery) || emitEvery < 1) throw new KernelError("E_CONFIG", "params.emitEvery: целое ≥ 1");
    if (config.emitChecksum === true && !this._hashFn) {
      throw new KernelError("E_CONFIG", "emitChecksum=true требует hashFn в конструкторе (Р10)");
    }
    this._fields = [new Float64Array(N), new Float64Array(N), new Float64Array(N)];
    for (let i = 0; i < N; i++) this._fields[0][i] = i * 0.015625;
    this._memory = new Float64Array(N);
    this._activePage = 0; this._phaseCursor = 0;
    this._rngState = deriveStreamSeed("noise", config.seed >>> 0);
    this._drive = drive; this._tick = 0; this._nextFactSeq = 0;
    this._emitEvery = emitEvery;
    this._emitChecksum = config.emitChecksum === true;
    this._phase = "ready";
  }

  _guardReady(op) {
    if (this._phase === "terminated") throw new KernelError("E_TERMINATED", `${op} после shutdown`);
    if (this._phase !== "ready") throw new KernelError("E_NOT_INITIALIZED", `${op} до initialize`);
  }

  /** Точное число фактов на интервале (tick, tick+n] при текущем emitEvery. */
  factDemand(n) {
    const t = this._tick;
    return Math.floor((t + n) / this._emitEvery) - Math.floor(t / this._emitEvery);
  }

  step(n = 1) {
    this._guardReady("step");
    if (!Number.isInteger(n) || n < 1) throw new KernelError("E_BAD_ARG", `step(n): целое n ≥ 1`);
    // Fail-closed по исчерпанию: точный спрос номеров считается ДО мутации (О-2 п.9).
    if (this._nextFactSeq + this.factDemand(n) > MAX_SEQ) {
      throw new KernelError("E_SEQ_EXHAUSTED", "диапазон fact.seq исчерпан: такт не выполняется");
    }
    const tickStart = this._tick;
    const facts = [];
    for (let k = 0; k < n; k++) {
      this._tickOnce();
      if (this._tick % this._emitEvery === 0) {
        const seq = this._nextFactSeq++;            // номер только при создании факта
        facts.push({
          tier: "fact", type: FACT_TYPE, tick: this._tick, seq,
          payload: { channel: this._activePage, sample: this._fields[this._activePage][0] },
        });
      }
    }
    const report = { tickStart, tickEnd: this._tick, facts };
    if (this._emitChecksum && this._hashFn) report.checksum = this._hashFn(this.checkpoint());
    return report;
  }

  _tickOnce() {
    const page = this._activePage;
    const input = this._fields[page];
    const hist = this._fields[(page + 2) % 3];
    const output = this._fields[(page + 1) % 3];
    const memory = this._memory;
    const drive = this._drive;
    const p = this._phaseCursor;
    const parity = p % 2;
    let s = this._rngState;
    for (let i = 0; i < N; i++) {
      const R = (i + 1 + p) % N;
      const L = (i + N - 1 - parity) % N;
      s = xorshift32Step(s);
      const noise = (s / 4294967296) - 0.5;
      output[i] = (((input[i] * 0.5) + (input[R] * 0.25))
        + ((hist[L] * 0.125) + (memory[i] * 0.125)))
        + ((noise * drive) * 0.00000095367431640625);
      memory[i] = (memory[i] * 0.9375) + (output[i] * 0.0625);
    }
    this._rngState = s;
    this._activePage = (page + 1) % 3;
    this._phaseCursor = (this._phaseCursor + 1) % N;
    this._tick += 1;
  }

  checkpoint() {
    this._guardReady("checkpoint");
    const buf = (arr) => ({
      dtype: "f64", numericClass: "continuous", causal: true,
      length: N, byteOrder: "little-endian", encoding: "base64", data: f64ToBase64(arr),
    });
    const causalConfig = { drive: this._drive, emitEvery: this._emitEvery };
    return {
      stateFormat: STATE_FORMAT, kernelName: KERNEL_NAME, kernelVersion: KERNEL_VERSION, abiVersion: ABI_VERSION,
      tick: this._tick,
      rng: { streams: { noise: String(this._rngState >>> 0) } },
      buffers: { field0: buf(this._fields[0]), field1: buf(this._fields[1]), field2: buf(this._fields[2]), memory: buf(this._memory) },
      // emitEvery в scalars ⇒ входит в CausalStateHash через замороженную
      // canonicalization (rng/scalars/cursors/buffers). Контракт A1:
      // равный CausalStateHash ⇒ равное допустимое будущее.
      scalars: { drive: this._drive, emitEvery: this._emitEvery },
      // Явная причинная конфигурация и её hash — проверяются при restore.
      causalConfig,
      causalConfigHash: contentHash(causalConfig),
      cursors: { activePage: this._activePage, phaseCursor: this._phaseCursor, nextFactSeq: this._nextFactSeq },
    };
  }

  restore(state) {
    this._guardReady("restore");
    if (!state || typeof state !== "object") throw new KernelError("E_STATE_FORMAT", "state: объект обязателен");
    const exact = (f, got, want) => { if (got !== want) throw new KernelError("E_STATE_FORMAT", `${f}: ожидалось ${JSON.stringify(want)}, получено ${JSON.stringify(got)}`); };
    exact("stateFormat", state.stateFormat, STATE_FORMAT);
    exact("abiVersion", state.abiVersion, ABI_VERSION);
    exact("kernelName", state.kernelName, KERNEL_NAME);
    exact("kernelVersion", state.kernelVersion, KERNEL_VERSION);
    const b = state.buffers ?? {};
    const expected = ["field0", "field1", "field2", "memory"];
    if (Object.keys(b).sort().join(",") !== [...expected].sort().join(",")) {
      throw new KernelError("E_STATE_FORMAT", `buffers: ожидался состав {${expected.join(", ")}}`);
    }
    for (const name of expected) {
      const d = b[name];
      exact(`buffers.${name}.dtype`, d.dtype, "f64");
      exact(`buffers.${name}.numericClass`, d.numericClass, "continuous");
      exact(`buffers.${name}.causal`, d.causal, true);
      exact(`buffers.${name}.encoding`, d.encoding, "base64");
      exact(`buffers.${name}.byteOrder`, d.byteOrder, "little-endian");
      exact(`buffers.${name}.length`, d.length, N);
    }
    const fields = [base64ToF64(b.field0.data, N, "field0"), base64ToF64(b.field1.data, N, "field1"), base64ToF64(b.field2.data, N, "field2")];
    const memory = base64ToF64(b.memory.data, N, "memory");
    const rngStr = state.rng?.streams?.noise;
    if (typeof rngStr !== "string" || !CANONICAL_DECIMAL.test(rngStr)) throw new KernelError("E_STATE_FORMAT", "rng.streams.noise: каноническая десятичная строка");
    const rng = Number(rngStr);
    if (!Number.isSafeInteger(rng) || rng < 0 || rng > 0xffffffff) throw new KernelError("E_STATE_FORMAT", "rng.streams.noise: вне u32");
    const page = state.cursors?.activePage, cursor = state.cursors?.phaseCursor, nfs = state.cursors?.nextFactSeq;
    if (!Number.isInteger(page) || page < 0 || page > 2) throw new KernelError("E_STATE_FORMAT", "cursors.activePage: 0…2");
    if (!Number.isInteger(cursor) || cursor < 0 || cursor >= N) throw new KernelError("E_STATE_FORMAT", "cursors.phaseCursor: 0…63");
    // Exact-restore ОБЯЗАН продолжить нумерацию без повторов (О-2 п.6/11).
    if (!Number.isSafeInteger(nfs) || nfs < 0) throw new KernelError("E_STATE_FORMAT", "cursors.nextFactSeq: целое 0…MAX_SAFE_INTEGER");
    const drive = state.scalars?.drive;
    if (typeof drive !== "number" || !Number.isFinite(drive)) throw new KernelError("E_STATE_FORMAT", "scalars.drive: конечный f64");
    // A1: причинная конфигурация восстанавливается ИЗ checkpoint, а не наследуется
    // от инициализации нового экземпляра. Структура и hash проверяются.
    const cc = state.causalConfig;
    if (!cc || typeof cc !== "object") throw new KernelError("E_STATE_FORMAT", "causalConfig: объект обязателен");
    if (!Number.isInteger(cc.emitEvery) || cc.emitEvery < 1) throw new KernelError("E_STATE_FORMAT", "causalConfig.emitEvery: целое ≥ 1");
    if (typeof cc.drive !== "number" || !Number.isFinite(cc.drive)) throw new KernelError("E_STATE_FORMAT", "causalConfig.drive: конечный f64");
    if (contentHash({ drive: cc.drive, emitEvery: cc.emitEvery }) !== state.causalConfigHash) {
      throw new KernelError("E_STATE_FORMAT", "causalConfigHash не совпадает с causalConfig");
    }
    // Кросс-сверка: emitEvery/drive в scalars обязаны совпасть с causalConfig
    // (иначе CausalStateHash и объявленная конфигурация рассинхронизированы).
    if (state.scalars?.emitEvery !== cc.emitEvery) throw new KernelError("E_STATE_FORMAT", "scalars.emitEvery ≠ causalConfig.emitEvery");
    if (drive !== cc.drive) throw new KernelError("E_STATE_FORMAT", "scalars.drive ≠ causalConfig.drive");
    if (!Number.isInteger(state.tick) || state.tick < 0 || !Number.isSafeInteger(state.tick)) throw new KernelError("E_STATE_FORMAT", "tick: 0…MAX_SAFE_INTEGER");
    this._fields = fields; this._memory = memory; this._rngState = rng >>> 0;
    this._activePage = page; this._phaseCursor = cursor; this._nextFactSeq = nfs;
    this._drive = cc.drive; this._emitEvery = cc.emitEvery; this._tick = state.tick;
  }

  shutdown() { this._phase = "terminated"; this._fields = null; this._memory = null; }
}
