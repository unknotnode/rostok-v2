/**
 * reference-relaxation.mjs — эталонное контрольное ядро шага 1.
 * Реализует синхронный PhysicsKernel по kernel-abi/2.0.0 и спецификации
 * protocol/kernels/reference-relaxation-kernel-1.md (rev 2).
 *
 * Ядро намеренно скучное. Его единственная задача — оживить все разделы
 * ABI и доказать полноту checkpoint. Никакой предметной физики Rost/0k.
 */

const N = 64;
const KERNEL_NAME = "reference-relaxation";
const KERNEL_VERSION = "1.0.0";
const ABI_VERSION = "kernel-abi/2";
const STATE_FORMAT = "reference-relaxation-state/1";

export class KernelError extends Error {
  constructor(code, message, details) {
    super(message);
    this.code = code;
    if (details !== undefined) this.details = details;
  }
}

/* ── RNG: xorshift32 + derivation (спецификация §2, закреплено векторами) ── */

function fnv1a32(str) {
  let h = 0x811c9dc5;
  for (const b of new TextEncoder().encode(str)) {
    h ^= b;
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
}

export function deriveStreamSeed(name, master) {
  const s = (fnv1a32(name) ^ master) >>> 0;
  return s === 0 ? 0x9e3779b9 : s;
}

export function xorshift32Step(s) {
  s ^= s << 13; s >>>= 0;
  s ^= s >>> 17;
  s ^= s << 5;  s >>>= 0;
  return s;
}

/* ── сериализация буферов: канонический base64 little-endian ── */

function f64ToBase64(arr) {
  // Явная LE-запись: эталон не зависит от порядка байтов CPU.
  const bytes = new Uint8Array(arr.length * 8);
  const dv = new DataView(bytes.buffer);
  for (let i = 0; i < arr.length; i++) dv.setFloat64(i * 8, arr[i], true);
  return Buffer.from(bytes).toString("base64");
}

function base64ToF64(b64, expectedLength, where) {
  const raw = Buffer.from(b64, "base64");
  if (raw.length !== expectedLength * 8) {
    throw new KernelError("E_STATE_FORMAT", `${where}: ${raw.length} байт вместо ${expectedLength * 8}`);
  }
  const out = new Float64Array(expectedLength);
  const dv = new DataView(raw.buffer, raw.byteOffset, raw.byteLength);
  for (let i = 0; i < expectedLength; i++) out[i] = dv.getFloat64(i * 8, true);
  return out;
}

const CANONICAL_DECIMAL = /^(0|[1-9][0-9]*)$/;

/* ── ядро ── */

export class ReferenceRelaxationKernel {
  /**
   * hashFn — эталонная функция CausalStateHash. Замороженная зависимость
   * конструктора (Р3): после создания не изменяется, скрытого состояния
   * исполнения не существует. Обязательна, если emitChecksum=true.
   */
  constructor(opts = {}) {
    this._hashFn = typeof opts.hashFn === "function" ? opts.hashFn : null;
    Object.freeze && Object.defineProperty(this, "_hashFn", { writable: false });
    this._phase = "created"; // created | ready | terminated
    this._fields = null;     // [Float64Array, Float64Array, Float64Array]
    this._memory = null;
    this._activePage = 0;    // 0..2
    this._phaseCursor = 0;   // 0..63
    this._rngState = 0;      // u32
    this._drive = 1.0;
    this._tick = 0;
    this._emitChecksum = false;
  }

  metadata() {
    // Чистая, допустима в любом состоянии.
    return {
      name: KERNEL_NAME,
      version: KERNEL_VERSION,
      abiVersion: ABI_VERSION,
      stateFormat: STATE_FORMAT,
      float: "f64",
      deterministic: true,
      moveClasses: ["modify-state"],
      moves: [{ id: "field.relax", class: "modify-state", atomic: true }],
      growthCapabilities: {
        entityGrowth: false, relationGrowth: false, dofActivation: false,
        stateExtension: false, capacityExtension: false,
      },
      growthCapable: false,
      buffers: [
        { name: "field0", dtype: "f64", components: 1, capacity: N, causal: true, numericClass: "continuous", semantics: "физический канал 0 (роль по activePage)" },
        { name: "field1", dtype: "f64", components: 1, capacity: N, causal: true, numericClass: "continuous", semantics: "физический канал 1 (роль по activePage)" },
        { name: "field2", dtype: "f64", components: 1, capacity: N, causal: true, numericClass: "continuous", semantics: "физический канал 2; в роли output содержимое на границе такта мертво (документированное исключение спецификации §1)" },
        { name: "memory", dtype: "f64", components: 1, capacity: N, causal: true, numericClass: "continuous", semantics: "медленная память 15/16 + 1/16" },
      ],
      dormant: [],
      ceilings: [{ name: "elements", limit: N }],
      symmetries: [],
      views: ["series-view@1"],
      deadRegions: [{
        id: "page.output",
        kind: "overwrite-before-read",
        buffers: ["field0", "field1", "field2"],
        roleCursor: "activePage",
        description: "буфер в роли (activePage+1) mod 3 полностью перезаписывается до любого чтения; его содержимое на границе такта не влияет на будущее",
      }],
    };
  }

  initialize(config) {
    if (this._phase === "terminated") throw new KernelError("E_TERMINATED", "ядро завершено");
    if (this._phase === "ready") throw new KernelError("E_ALREADY_INITIALIZED", "повторный initialize");
    if (!config || !Number.isInteger(config.seed) || config.seed < 0 || config.seed > 0xffffffff) {
      throw new KernelError("E_CONFIG", "seed: целое u32 обязательно");
    }
    const params = config.params ?? {};
    const drive = params.drive === undefined ? 1.0 : params.drive;
    if (typeof drive !== "number" || !Number.isFinite(drive)) {
      throw new KernelError("E_CONFIG", "params.drive: конечный f64");
    }
    if (config.emitChecksum === true && !this._hashFn) {
      throw new KernelError("E_CONFIG", "emitChecksum=true требует hashFn в конструкторе (Р3): скрытая деградация checksum запрещена");
    }
    this._fields = [new Float64Array(N), new Float64Array(N), new Float64Array(N)];
    // Единственная нормативная форма инициализации (У6): i * 0.015625
    for (let i = 0; i < N; i++) this._fields[0][i] = i * 0.015625;
    this._memory = new Float64Array(N);
    this._activePage = 0;
    this._phaseCursor = 0;
    this._rngState = deriveStreamSeed("noise", config.seed >>> 0);
    this._drive = drive;
    this._tick = 0;
    this._emitChecksum = config.emitChecksum === true;
    this._phase = "ready";
  }

  _guardReady(op) {
    if (this._phase === "terminated") throw new KernelError("E_TERMINATED", `${op} после shutdown`);
    if (this._phase !== "ready") throw new KernelError("E_NOT_INITIALIZED", `${op} до initialize`);
  }

  step(n = 1) {
    this._guardReady("step");
    if (!Number.isInteger(n) || n < 1) throw new KernelError("E_BAD_ARG", `step(n): целое n ≥ 1, получено ${JSON.stringify(n)}`);
    const tickStart = this._tick;
    for (let k = 0; k < n; k++) this._tickOnce();
    const report = { tickStart, tickEnd: this._tick, facts: [] };
    if (this._emitChecksum && this._hashFn) report.checksum = this._hashFn(this.checkpoint());
    return report;
  }

  _tickOnce() {
    const page = this._activePage;
    const input = this._fields[page];
    const hist = this._fields[(page + 2) % 3];
    const output = this._fields[(page + 1) % 3];
    const memory = this._memory;
    const drive = this._drive;
    const p = this._phaseCursor;
    const parity = p % 2;
    let s = this._rngState;

    // Нормативный такт — байт-в-байт со спецификацией §3:
    //   u         = rng.noise()                       // u32
    //   noise     = (u / 4294967296) - 0.5            // [−0.5, 0.5)
    //   output[i] = ( ( (input[i] * 0.5) + (input[R(i)] * 0.25) )
    //             + ( (hist[L(i)] * 0.125) + (memory[i] * 0.125) ) )
    //             + ( (noise * drive) * 0.00000095367431640625 )   // 2^-20
    //   memory[i] = (memory[i] * 0.9375) + (output[i] * 0.0625)    // 15/16, 1/16
    // In-place-закон (У4): output[i] из СТАРОГО memory[i], затем сразу
    // новый memory[i]. Один проход; разбиение на два прохода — изменение закона.
    for (let i = 0; i < N; i++) {
      const R = (i + 1 + p) % N;
      const L = (i + N - 1 - parity) % N;
      s = xorshift32Step(s);
      const noise = (s / 4294967296) - 0.5;
      output[i] = (((input[i] * 0.5) + (input[R] * 0.25))
        + ((hist[L] * 0.125) + (memory[i] * 0.125)))
        + ((noise * drive) * 0.00000095367431640625);
      memory[i] = (memory[i] * 0.9375) + (output[i] * 0.0625);
    }

    this._rngState = s;
    this._activePage = (page + 1) % 3;               // ротация ролей без копирования
    this._phaseCursor = (this._phaseCursor + 1) % N;
    this._tick += 1;
  }

  checkpoint() {
    this._guardReady("checkpoint");
    // Чистое чтение: RNG не тянется, состояние не мутирует.
    const buf = (arr) => ({
      dtype: "f64", numericClass: "continuous", causal: true,
      length: N, byteOrder: "little-endian", encoding: "base64",
      data: f64ToBase64(arr),
    });
    return {
      stateFormat: STATE_FORMAT,
      kernelName: KERNEL_NAME,
      kernelVersion: KERNEL_VERSION,
      abiVersion: ABI_VERSION,
      tick: this._tick,
      rng: { streams: { noise: String(this._rngState >>> 0) } },
      buffers: {
        field0: buf(this._fields[0]),
        field1: buf(this._fields[1]),
        field2: buf(this._fields[2]),
        memory: buf(this._memory),
      },
      scalars: { drive: this._drive },
      cursors: { activePage: this._activePage, phaseCursor: this._phaseCursor },
    };
  }

  restore(state) {
    this._guardReady("restore");
    if (!state || typeof state !== "object") throw new KernelError("E_STATE_FORMAT", "state: объект обязателен");
    // Exact-совместимость версии 1 (Р3): каждое нормативное поле проверяется,
    // подложные дескрипторы при верном stateFormat не проходят.
    const exact = (field, got, want) => {
      if (got !== want) throw new KernelError("E_STATE_FORMAT", `${field}: ожидалось ${JSON.stringify(want)}, получено ${JSON.stringify(got)}`);
    };
    exact("stateFormat", state.stateFormat, STATE_FORMAT);
    exact("abiVersion", state.abiVersion, ABI_VERSION);
    exact("kernelName", state.kernelName, KERNEL_NAME);
    exact("kernelVersion", state.kernelVersion, KERNEL_VERSION);
    const b = state.buffers ?? {};
    const expectedBuffers = ["field0", "field1", "field2", "memory"];
    const gotBuffers = Object.keys(b).sort();
    if (gotBuffers.join(",") !== [...expectedBuffers].sort().join(",")) {
      throw new KernelError("E_STATE_FORMAT", `buffers: ожидался точный состав {${expectedBuffers.join(", ")}}, получен {${gotBuffers.join(", ")}}`);
    }
    for (const name of expectedBuffers) {
      const d = b[name];
      exact(`buffers.${name}.dtype`, d.dtype, "f64");
      exact(`buffers.${name}.numericClass`, d.numericClass, "continuous");
      exact(`buffers.${name}.causal`, d.causal, true);
      exact(`buffers.${name}.encoding`, d.encoding, "base64");
      exact(`buffers.${name}.byteOrder`, d.byteOrder, "little-endian");
      exact(`buffers.${name}.length`, d.length, N);
    }
    const fields = [
      base64ToF64(b.field0.data, N, "field0"),
      base64ToF64(b.field1.data, N, "field1"),
      base64ToF64(b.field2.data, N, "field2"),
    ];
    const memory = base64ToF64(b.memory.data, N, "memory");
    const rngStr = state.rng?.streams?.noise;
    if (typeof rngStr !== "string" || !CANONICAL_DECIMAL.test(rngStr)) {
      throw new KernelError("E_STATE_FORMAT", "rng.streams.noise: каноническая десятичная строка");
    }
    const rng = Number(rngStr);
    if (!Number.isSafeInteger(rng) || rng < 0 || rng > 0xffffffff) {
      throw new KernelError("E_STATE_FORMAT", "rng.streams.noise: вне диапазона u32");
    }
    const page = state.cursors?.activePage;
    const cursor = state.cursors?.phaseCursor;
    if (!Number.isInteger(page) || page < 0 || page > 2) throw new KernelError("E_STATE_FORMAT", "cursors.activePage: 0…2");
    if (!Number.isInteger(cursor) || cursor < 0 || cursor >= N) throw new KernelError("E_STATE_FORMAT", "cursors.phaseCursor: 0…63");
    const drive = state.scalars?.drive;
    if (typeof drive !== "number" || !Number.isFinite(drive)) throw new KernelError("E_STATE_FORMAT", "scalars.drive: конечный f64");
    if (!Number.isInteger(state.tick) || state.tick < 0 || !Number.isSafeInteger(state.tick)) {
      throw new KernelError("E_STATE_FORMAT", "tick: целое 0…MAX_SAFE_INTEGER");
    }
    // Атомарное применение после полной валидации.
    this._fields = fields;
    this._memory = memory;
    this._rngState = rng >>> 0;
    this._activePage = page;
    this._phaseCursor = cursor;
    this._drive = drive;   // У7: restore ОБЯЗАН заменить drive
    this._tick = state.tick;
  }

  shutdown() {
    // Повторный shutdown — no-op.
    this._phase = "terminated";
    this._fields = null;
    this._memory = null;
  }
}
