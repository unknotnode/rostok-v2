/**
 * pool.mjs — SnapshotPool: ownership-протокол Д4 на стороне потребителя.
 *
 * Машина состояний буфера (владелец в скобках):
 *   WORKER-FREE (производитель) → FILLING → IN-TRANSIT → HELD (потребитель)
 *   → release() → transfer обратно → WORKER-FREE
 *
 * Возврат — ЯВНАЯ операция протокола (handle.release()); физически это
 * transfer того же ArrayBuffer назад производителю, поэтому чтение после
 * возврата невозможно на уровне движка (буфер отсоединён), а не по
 * договорённости.
 *
 * Обнаруживаемые нарушения (E_OWNERSHIP): двойной возврат; возврат
 * чужого/неизвестного буфера; устаревший seq. Чтение после возврата →
 * E_USE_AFTER_RETURN (отсоединённый буфер).
 *
 * Политика: drop, never block — решается на стороне производителя
 * (нет свободного буфера → снимок пропущен, счётчик растёт); пул только
 * учитывает и возвращает.
 */
import { getViewCodec } from "./view-registry.mjs";

export class PoolDisposedError extends Error {
  constructor(message) { super(message); this.code = "E_POOL_DISPOSED"; }
}

export class OwnershipError extends Error {
  constructor(message) { super(message); this.code = "E_OWNERSHIP"; }
}

export class SnapshotPool {
  /**
   * host — WorkerHost с låg-уровневыми grantBuffer(poolId, buf) и
   * onSnapshot(cb). poolSize ≥ 3 (Д4.2).
   */
  constructor(host, { poolSize = 3, byteLength }) {
    if (!Number.isInteger(poolSize) || poolSize < 3) {
      throw new OwnershipError(`Д4.2: кольцо снимков требует ≥3 буферов, запрошено ${poolSize}`);
    }
    this._host = host;
    this._byteLength = byteLength;
    this._records = new Map(); // poolId → { state: "worker"|"held"|"closed", seq: number|null }
    this._pendingHandles = [];
    this._lifecycle = "active"; // active | disposed (Т4)
    this._telemetry = { delivered: 0, returned: 0, returnedLocal: 0, inFlight: 0, highWaterMark: 0, leakedAtDispose: 0 };

    host.onSnapshot((msg) => this._receive(msg));
    for (let id = 0; id < poolSize; id++) {
      this._records.set(id, { state: "worker", seq: null });
      host.grantBuffer(id, new ArrayBuffer(byteLength));
    }
  }

  _receive({ poolId, header, buffer }) {
    if (this._lifecycle !== "active") throw new PoolDisposedError("receive после dispose");
    const rec = this._records.get(poolId);
    if (!rec || rec.state !== "worker") {
      throw new OwnershipError(`снимок из буфера ${poolId} в недопустимом состоянии ${rec?.state}`);
    }
    rec.state = "held";
    rec.seq = header.seq;
    this._telemetry.delivered++;
    this._telemetry.inFlight++;
    if (this._telemetry.inFlight > this._telemetry.highWaterMark) {
      this._telemetry.highWaterMark = this._telemetry.inFlight;
    }
    const handle = this._makeHandle(poolId, header, buffer);
    this._pendingHandles.push(handle);
  }

  _makeHandle(poolId, header, buffer) {
    const pool = this;
    let released = false;
    return {
      header,
      poolId,
      seq: header.seq,
      /**
       * Декодирование по viewId через реестр (долг 2): ownership-слой не
       * знает физический смысл нагрузки.
       */
      view(viewId) {
        if (released) {
          const e = new Error(`чтение после возврата буфера ${poolId}`);
          e.code = "E_USE_AFTER_RETURN";
          throw e;
        }
        if (!header.views.includes(viewId)) {
          const e = new Error(`снимок не содержит представления ${viewId}: [${header.views.join(", ")}]`);
          e.code = "E_VIEW_UNSUPPORTED";
          throw e;
        }
        return getViewCodec(viewId).decode(buffer);
      },
      release(seqOverride) {
        if (released) throw new OwnershipError(`двойной возврат буфера ${poolId}`);
        pool._release(poolId, seqOverride !== undefined ? seqOverride : header.seq, buffer);
        released = true;
      },
    };
  }

  _release(poolId, seq, buffer) {
    const rec = this._records.get(poolId);
    if (!rec) throw new OwnershipError(`возврат чужого буфера: poolId ${poolId} не принадлежит пулу`);
    if (rec.state !== "held") throw new OwnershipError(`возврат буфера ${poolId} в состоянии ${rec.state} (двойной возврат?)`);
    if (rec.seq !== seq) throw new OwnershipError(`устаревший seq при возврате буфера ${poolId}: ${seq}, актуален ${rec.seq}`);
    // Правило Т4: после dispose пула или аварии хоста возврат закрывает
    // handle ЛОКАЛЬНО — буфер не зависает в HELD, transfer невозможен.
    if (this._lifecycle !== "active") { this._closeLocally(rec); return; }
    try {
      this._host.grantBuffer(poolId, buffer); // transfer назад: буфер отсоединяется у потребителя
    } catch (e) {
      if (e.code === "E_HOST_FAILURE") { this._closeLocally(rec); return; }
      throw e;
    }
    rec.state = "worker";
    rec.seq = null;
    this._telemetry.returned++;
    this._telemetry.inFlight--;
  }

  _closeLocally(rec) {
    rec.state = "closed";
    rec.seq = null;
    this._telemetry.returnedLocal++;
    this._telemetry.inFlight--;
  }

  /** Т4: жизненный цикл. Удерживаемые на момент dispose буферы — leaked. */
  dispose() {
    if (this._lifecycle !== "active") return;
    this._lifecycle = "disposed";
    this._telemetry.leakedAtDispose = this._telemetry.inFlight;
    this._pendingHandles = [];
  }

  get lifecycle() { return this._lifecycle; }

  /** Забрать все доставленные и ещё не выданные снимки. */
  takeAll() {
    if (this._lifecycle !== "active") throw new PoolDisposedError("takeAll после dispose");
    const out = this._pendingHandles;
    this._pendingHandles = [];
    return out;
  }

  /** Телеметрия потребителя; produced/dropped живут у производителя (host.snapshotStats). */
  telemetry() { return { ...this._telemetry }; }
}
