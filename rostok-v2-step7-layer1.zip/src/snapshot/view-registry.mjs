/**
 * view-registry.mjs — реестр кодеков представлений (долг 2).
 * Разводит ownership и декодирование: SnapshotPool владеет буферами и
 * ничего не знает о физическом смысле нагрузки; кодек выбирается по
 * viewId из заголовка. Новое представление = регистрация кодека,
 * инфраструктурный класс пула не меняется.
 */
import { decodeSeriesView, SERIES_VIEW_ID } from "./encode.mjs";

const codecs = new Map();

export function registerView(viewId, codec) {
  if (codecs.has(viewId)) throw new Error(`кодек ${viewId} уже зарегистрирован`);
  codecs.set(viewId, codec);
}

export function getViewCodec(viewId) {
  const c = codecs.get(viewId);
  if (!c) {
    const e = new Error(`представление ${viewId} не зарегистрировано`);
    e.code = "E_VIEW_UNKNOWN";
    throw e;
  }
  return c;
}

registerView(SERIES_VIEW_ID, { decode: decodeSeriesView });
