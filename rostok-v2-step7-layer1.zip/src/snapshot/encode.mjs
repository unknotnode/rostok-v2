/**
 * encode.mjs — кодировщик series-view@1 (сторона производителя).
 * Читает ЧИСТЫЙ checkpoint ядра (никакого доступа к живому состоянию —
 * checkpoint уже является копией) и пишет ролево-каноническую полезную
 * нагрузку в предоставленный ArrayBuffer из пула.
 *
 * Мёртвая роль (page.output) не читается и не пишется — её не существует
 * в представлении (protocol/views/series-view-1.md).
 *
 * REFERENCE-ONLY, NOT SCALABLE (приёмка шага 2, долг 1): путь
 * checkpoint→base64→decode→target допустим только как доказательный
 * адаптер контрольного ядра. До первого реального ядра вводится
 * kernel-owned KernelSnapshotEncoder: принадлежит пакету ядра, получает
 * внутренний read-only state accessor и viewId, пишет разрешённые поля
 * НАПРЯМУЮ в target (одна копия, без base64 и промежуточных аллокаций).
 * Ядро по-прежнему не знает анализаторов; checkpoint остаётся только
 * форматом восстановления.
 */

import { base64ToF64Array } from "../lib/bytes.mjs";

export const SERIES_VIEW_ID = "series-view@1";
export const SERIES_VIEW_BYTES = 1536; // 3 канала × 64 × 8
const N = 64;

const decodeF64 = (b64, where) => base64ToF64Array(b64, N, where);

/**
 * encodeSeriesView(state, target) — state: KernelState (checkpoint),
 * target: ArrayBuffer ≥ 1536 байт. Возвращает заголовок без seq/dropped
 * (их назначает производитель-пул).
 */
export function encodeSeriesView(state, target) {
  if (target.byteLength < SERIES_VIEW_BYTES) {
    throw new Error(`буфер пула ${target.byteLength} байт < ${SERIES_VIEW_BYTES}`);
  }
  const page = state.cursors.activePage;
  const input = decodeF64(state.buffers[`field${page}`].data, "input");
  const hist = decodeF64(state.buffers[`field${(page + 2) % 3}`].data, "hist");
  const memory = decodeF64(state.buffers.memory.data, "memory");

  const dv = new DataView(target);
  for (let i = 0; i < N; i++) {
    dv.setFloat64(i * 8, input[i], true);
    dv.setFloat64(512 + i * 8, hist[i], true);
    dv.setFloat64(1024 + i * 8, memory[i], true);
  }
  return {
    snapshotSchema: "snapshot/1",
    stateFormat: state.stateFormat,
    tick: state.tick,
    views: [SERIES_VIEW_ID],
    byteLength: SERIES_VIEW_BYTES,
  };
}

/**
 * Чтение полезной нагрузки на стороне потребителя — ЗАКОН O1.
 *
 * Кодек возвращает НЕ TypedArray, а read-only accessor: данные копируются
 * в замыкание, наружу отдаются только геттеры. Анализатор физически не
 * может ни мутировать вход соседа (массивы недостижимы), ни удержать
 * ссылку на буфер пула (accessor независим от его жизненного цикла).
 * Заморозка объекта запрещает и подмену самих геттеров.
 */
export function decodeSeriesView(buffer) {
  if (buffer.byteLength === 0) {
    const e = new Error("чтение после возврата буфера: ArrayBuffer отсоединён");
    e.code = "E_USE_AFTER_RETURN";
    throw e;
  }
  const dv = new DataView(buffer);
  const read = (off) => {
    const a = new Float64Array(N);
    for (let i = 0; i < N; i++) a[i] = dv.getFloat64(off + i * 8, true);
    return a;
  };
  const input = read(0), hist = read(512), memory = read(1024);
  const guard = (i) => {
    if (!Number.isInteger(i) || i < 0 || i >= N) throw new RangeError(`индекс ${i} вне [0, ${N})`);
  };
  return Object.freeze({
    viewId: SERIES_VIEW_ID,
    length: N,
    getInput(i) { guard(i); return input[i]; },
    getHist(i) { guard(i); return hist[i]; },
    getMemory(i) { guard(i); return memory[i]; },
  });
}
