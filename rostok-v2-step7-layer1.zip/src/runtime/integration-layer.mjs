/**
 * integration-layer.mjs — Runtime Integration Layer, runtime-integration/
 * 1.0.0-draft4.1.
 *
 * Commit-bundle: полный следующий immutable root-state строится ВНЕ общих
 * структур, пока rollback разрешён; принятие перехода — одно переключение
 * корневой ссылки #runtimeState плюс одно переключение ссылки custody
 * retention (prepareCommit заранее построил новое хранилище). install не
 * содержит user-кода, IO, await, валидации и намеренных throw. Абсолютной
 * аппаратной атомарности JS не даёт: непредвиденный runtime-failure во
 * время установки ⇒ немедленный CAUSAL_INDETERMINATE (доказать атомарность
 * уже нельзя), а не обычный rollback. Установленный bundle — источник
 * истины; локальный TransitionStaging после установки диагностический.
 *
 * seal читает ИСКЛЮЧИТЕЛЬНО приватный #runtimeState; наружу — только
 * deep-frozen snapshots. Порядок seal: структура → finalize/repair →
 * replay → перестройка factsRoot по каждому маркеру (missing после repair =
 * нарушение) → сверка transitionEvidenceHash и transactionId → биекция
 * {identityChain}={committed}={WAL STEP_COMMIT}={0..reportSeq-1} → SEALED.
 */

import { contentHash, archiveValue } from "../lib/canonical.mjs";
import { causalStateHash } from "../../tools/causal-hash.mjs";
import { encodeSeriesView, decodeSeriesView, SERIES_VIEW_BYTES } from "../snapshot/encode.mjs";

export const KERNEL_EPOCH_PINNED = 0;
const HEX = /^[0-9a-f]{16,64}$/;
export class RuntimeError extends Error { constructor(code, message) { super(message); this.code = code; } }

function deepFreeze(o) {
  if (o && typeof o === "object" && !Object.isFrozen(o)) { Object.freeze(o); for (const k of Object.keys(o)) deepFreeze(o[k]); }
  return o;
}
const frozenClone = (o) => deepFreeze(structuredClone(o));

/* ── FactRetentionBuffer (A4): reserve → prepareCommit → applyPrepared ── */
export class FactRetentionBuffer {
  #config; #store; #transferred; #reserved;
  constructor({ depth = 4096, retentionPolicy = "ephemeral-custody", implVersion = "1.0.0" } = {}) {
    if (!Number.isInteger(depth) || depth < 1) throw new RuntimeError("E_RETENTION_CONFIG", "depth: целое ≥ 1");
    if (!["ephemeral-custody", "retained-custody"].includes(retentionPolicy)) throw new RuntimeError("E_RETENTION_CONFIG", `retentionPolicy: неизвестна (${retentionPolicy})`);
    this.#config = Object.freeze({ depth, retentionPolicy, implVersion });
    this.#store = new Map(); this.#transferred = new Set(); this.#reserved = 0;
  }
  get bufferIdentityHash() { return contentHash(this.#config); }
  identity() { return { bufferIdentityHash: this.bufferIdentityHash, ...this.#config }; }
  get size() { return this.#store.size; }
  get available() { return this.#config.depth - this.#store.size - this.#reserved; }
  reserve(count) {
    if (!Number.isInteger(count) || count < 0) throw new RuntimeError("E_RETENTION_CONFIG", "reserve: count ≥ 0");
    if (count > this.available) throw new RuntimeError("E_RETENTION_EXHAUSTED", `retention исчерпан: спрос ${count}, свободно ${this.available}`);
    this.#reserved += count; return { count, prepared: false, applied: false };
  }
  cancelReservation(token) { if (!token.applied && !token.cancelled) { this.#reserved -= token.count; token.cancelled = true; } }
  /** Pre-commit: валидирует и СТРОИТ новое хранилище, НЕ трогая текущее (может бросить). */
  prepareCommit(token, facts) {
    if (token.prepared) throw new RuntimeError("E_RETENTION_STATE", "резерв уже подготовлен");
    if (facts.length !== token.count) throw new RuntimeError("E_FACT_DEMAND_MISMATCH", `зарезервировано ${token.count}, произведено ${facts.length}`);
    const seen = new Set();
    for (const f of facts) { if (seen.has(f.seq)) throw new RuntimeError("E_FACT_DEMAND_MISMATCH", `дубль seq ${f.seq}`); seen.add(f.seq); }
    const nextStore = new Map(this.#store);
    for (const f of facts) nextStore.set(f.seq, frozenClone(f));
    token.prepared = true;
    return { nextStore, count: token.count, token };
  }
  /** Install-фаза: одно переключение ссылки хранилища + число. Без throw по построению. */
  applyPrepared(prepared) { this.#store = prepared.nextStore; this.#reserved -= prepared.count; prepared.token.applied = true; }
  reissue(seq) { return this.#store.has(seq) ? structuredClone(this.#store.get(seq)) : null; }
  releaseToArchive(seq) { this.#transferred.add(seq); if (this.#config.retentionPolicy === "ephemeral-custody") this.#store.delete(seq); }
  isTransferred(seq) { return this.#transferred.has(seq); }
}

/* ── snapshot-транспорт: drop, never block; освобождает все handles (P1.16) ── */
class SnapshotRing {
  constructor(depth) { this._free = Array.from({ length: depth }, () => new ArrayBuffer(SERIES_VIEW_BYTES)); this._delivered = []; this._seq = 0; this.telemetry = { produced: 0, dropped: 0 }; }
  produce(state) { const buf = this._free.shift(); if (!buf) { this.telemetry.dropped++; return false; } const header = encodeSeriesView(state, buf); header.seq = this._seq++; this._delivered.push({ header, buf }); this.telemetry.produced++; return true; }
  takeAll() { const o = this._delivered; this._delivered = []; return o; }
  release(buf) { this._free.push(buf); }
}

/* ── TransitionStaging: CREATED→VALIDATED→STAGED→COMMITTING→COMMITTED→PUBLISHED|PUBLISH_PARTIAL|ROLLED_BACK ── */
export class TransitionStaging {
  constructor(reportSeq) { this.reportSeq = reportSeq; this.phase = "CREATED"; }
  _to(next, from) { if (this.phase !== from) throw new RuntimeError("E_STAGING_PHASE", `staging ${this.reportSeq}: ${next} из ${this.phase}`); this.phase = next; }
  validated() { this._to("VALIDATED", "CREATED"); }
  staged() { this._to("STAGED", "VALIDATED"); }
  beginCommit() { this._to("COMMITTING", "STAGED"); }             // проверка перехода ДО install
  markCommitted() { this.phase = "COMMITTED"; }                    // post-install, простое присваивание
  publish(full) { this.phase = full ? "PUBLISHED" : "PUBLISH_PARTIAL"; }
  rollback() { if (["COMMITTING", "COMMITTED", "PUBLISHED", "PUBLISH_PARTIAL"].includes(this.phase)) throw new RuntimeError("E_STAGING_PHASE", `rollback после ${this.phase}`); this.phase = "ROLLED_BACK"; }
}

/* ── evidence (A6): плоские firstFactSeq/lastFactSeq в commitment ── */
export function factsRoot(facts) { return contentHash(facts.map((f) => ({ seq: f.seq, tick: f.tick ?? f.causalTick, type: f.type, payload: f.payload }))); }
export function transitionEvidence(e) {
  return { reportSeq: e.reportSeq, kernelEpoch: e.kernelEpoch, causalConfigHash: e.causalConfigHash,
    tickStart: e.tickStart, tickEnd: e.tickEnd, stateHashBefore: e.stateHashBefore, stateHashAfter: e.stateHashAfter,
    factCount: e.factCount, firstFactSeq: e.firstFactSeq, lastFactSeq: e.lastFactSeq, factsRoot: e.factsRoot };
}
export function transitionEvidenceHash(e) { return contentHash(transitionEvidence(e)); }
export function transactionId(reportSeq, before, after) { return contentHash({ reportSeq, before, after }); }

export function validateIdentityChain(chain, anchors = null) {
  const v = [];
  for (let i = 0; i < chain.length; i++) {
    const r = chain[i];
    if (r.kernelEpoch !== KERNEL_EPOCH_PINNED) v.push({ invariant: "EPOCH", message: `reportSeq ${r.reportSeq}` });
    if (!HEX.test(r.stateHashBefore) || !HEX.test(r.stateHashAfter) || !HEX.test(r.factsRoot)) v.push({ invariant: "HASH_FORMAT", message: `reportSeq ${r.reportSeq}` });
    if (!(r.tickStart <= r.tickEnd)) v.push({ invariant: "TICK_RANGE", message: `reportSeq ${r.reportSeq}` });
    if (i === 0) { if (r.reportSeq !== 0) v.push({ invariant: "SEQ_ANCHOR", message: `${r.reportSeq}` }); }
    else { const p = chain[i - 1];
      if (r.reportSeq !== p.reportSeq + 1) v.push({ invariant: "SEQ_MONO", message: `${p.reportSeq}→${r.reportSeq}` });
      if (p.stateHashAfter !== r.stateHashBefore) v.push({ invariant: "CHAIN_HASH", message: `${p.reportSeq}→${r.reportSeq}` });
      if (p.tickEnd !== r.tickStart) v.push({ invariant: "CHAIN_TICK", message: `${p.tickEnd}≠${r.tickStart}` });
    }
  }
  if (anchors && chain.length) {
    if (chain[0].stateHashBefore !== anchors.initialStateHash) v.push({ invariant: "INIT_ANCHOR", message: "init" });
    if (chain[chain.length - 1].stateHashAfter !== anchors.terminalStateHash) v.push({ invariant: "TERM_ANCHOR", message: "term" });
  }
  return v;
}

/** Покрытие: биекция identityChain ↔ committed ↔ WAL ↔ 0..reportSeq-1 (чистая, тестируемая). */
export function verifyCommitCoverage(rs) {
  const v = [];
  const walCommits = rs.wal.filter((m) => m.marker === "STEP_COMMIT");
  const ids = rs.identityChain.map((x) => x.reportSeq);
  const cms = rs.committed.map((x) => x.reportSeq);
  const wls = walCommits.map((x) => x.reportSeq);
  const eq = (a) => a.length === rs.reportSeq && a.every((x, i) => x === i);
  if (!eq(ids) || !eq(cms) || !eq(wls)) v.push({ why: "COVERAGE_BIJECTION", ids, cms, wls, reportSeq: rs.reportSeq });
  if (new Set(cms).size !== cms.length) v.push({ why: "MARKER_DUP" });
  for (let i = 0; i < rs.committed.length; i++) if (rs.committed[i].reportSeq !== i) v.push({ why: "MARKER_INDEX", at: i });
  return v;
}
/** Evidence: перестройка factsRoot из журнала, сверка hash/transactionId/chain, missing = нарушение. */
export function verifyCommittedEvidence(rs, replayResult) {
  const v = [];
  const bySeq = new Map(); for (const rec of replayResult.causal) if (rec.kind === "causal-fact") bySeq.set(rec.body.seq, rec.body);
  for (let i = 0; i < rs.committed.length; i++) {
    const m = rs.committed[i]; const ev = m.evidence; const id = rs.identityChain[i];
    if (transitionEvidenceHash(ev) !== m.transitionEvidenceHash) { v.push({ reportSeq: m.reportSeq, why: "MARKER_SELF" }); continue; }
    if (transactionId(ev.reportSeq, ev.stateHashBefore, ev.stateHashAfter) !== m.transactionId) v.push({ reportSeq: m.reportSeq, why: "TXID" });
    if (!id || id.factsRoot !== ev.factsRoot || id.stateHashBefore !== ev.stateHashBefore || id.stateHashAfter !== ev.stateHashAfter || id.firstFactSeq !== ev.firstFactSeq || id.lastFactSeq !== ev.lastFactSeq) v.push({ reportSeq: m.reportSeq, why: "CHAIN_DISAGREE" });
    if (ev.factCount > 0) {
      const facts = []; let missing = false;
      for (let s = ev.firstFactSeq; s <= ev.lastFactSeq; s++) { const b = bySeq.get(s); if (!b) { missing = true; break; } facts.push({ seq: b.seq, tick: b.causalTick, type: b.type, payload: b.payload }); }
      if (missing) v.push({ reportSeq: m.reportSeq, why: "FACT_MISSING_AFTER_REPAIR" });
      else if (facts.length !== ev.factCount || factsRoot(facts) !== ev.factsRoot) v.push({ reportSeq: m.reportSeq, why: "FACTS_ROOT_MISMATCH" });
    }
  }
  return v;
}

export function assertEpoch(e) { if (e !== KERNEL_EPOCH_PINNED) throw new RuntimeError("E_UNSUPPORTED_EPOCH", `kernelEpoch=${e}`); }
export function assertCausalFactsCapability(metadata, report) {
  const enabled = metadata.causalFacts === true;
  if (!enabled && report.facts && report.facts.length > 0) throw new RuntimeError("E_CAUSALFACTS_DISABLED", `causalFacts=false обязан facts:[], получено ${report.facts.length}`);
  return enabled;
}
export function assertMetadataConsistency(metadata) {
  if (metadata.causalFacts === true) {
    if (!Array.isArray(metadata.factStreams) || metadata.factStreams.length === 0) throw new RuntimeError("E_METADATA_INCONSISTENT", "causalFacts=true требует factStreams");
    if (metadata.seqScope !== "kernel-global") throw new RuntimeError("E_METADATA_INCONSISTENT", `seqScope=${metadata.seqScope}`);
    if (!Array.isArray(metadata.causalConfig)) throw new RuntimeError("E_METADATA_INCONSISTENT", "causalFacts=true требует causalConfig-декларацию");
  }
  return metadata.causalFacts === true;
}

export class RuntimeIntegrationLayer {
  #host; #journal; #retention; #observers; #diagnostic; #ring;
  #phase; #tickInFlight; #metadata; #causalFactsEnabled; #initialStateHash; #invocationBase;
  #validateMetadata; #emittedSeq; #emissionIndex;
  #runtimeState;   // единый нормативный корень
  diag;

  constructor({ host, journal, retention, observers = [], diagnostic = false, snapshotDepth = 3, validateMetadata = null }) {
    this.#host = host; this.#journal = journal; this.#retention = retention ?? new FactRetentionBuffer();
    this.#observers = observers; this.#diagnostic = diagnostic === true; this.#ring = new SnapshotRing(snapshotDepth);
    this.#phase = "CREATED"; this.#tickInFlight = false; this.#metadata = null; this.#causalFactsEnabled = false;
    this.#initialStateHash = null; this.#invocationBase = null; this.#validateMetadata = validateMetadata;
    this.#emittedSeq = 0; this.#emissionIndex = 0;
    this.#runtimeState = Object.freeze({ identityChain: Object.freeze([]), committed: Object.freeze([]), wal: Object.freeze([]), reportSeq: 0, nextExpectedSeq: 0 });
    this.diag = { snapshotsProduced: 0, snapshotsDropped: 0, factsSeen: 0, claimsEmitted: 0 };
    journal.setReissueSource("facts", { reissue: (seq) => this.#retention.reissue(seq) });
  }
  get phase() { return this.#phase; }
  get initialStateHash() { return this.#initialStateHash; }
  get reportSeq() { return this.#runtimeState.reportSeq; }
  // диагностические deep-frozen снапшоты (без ссылок на внутренние объекты)
  get identityChainSnapshot() { return frozenClone(this.#runtimeState.identityChain); }
  get committedSnapshot() { return frozenClone(this.#runtimeState.committed); }
  get walSnapshot() { return frozenClone(this.#runtimeState.wal); }
  environmentDoc(base = {}) { return { ...base, runtime: "runtime-integration/1", bufferIdentityHash: this.#retention.bufferIdentityHash }; }

  async open() {
    if (this.#phase !== "CREATED") throw new RuntimeError("E_PHASE", `open в фазе ${this.#phase}`);
    this.#metadata = await this.#host.metadata();
    if (this.#validateMetadata) { const r = this.#validateMetadata(this.#metadata); if (!r || r.ok !== true) throw new RuntimeError("E_METADATA_INVALID", `metadata не проходит схему: ${JSON.stringify(r && r.errors)}`); }
    this.#causalFactsEnabled = assertMetadataConsistency(this.#metadata);
    const cp = await this.#host.checkpoint();
    // P1.12: causalConfig и causalConfigHash присутствуют строго парно
    // (строгий валидатор не выражает both-or-neither без запрещённых ключевых слов).
    const hasCfg = cp.causalConfig !== undefined, hasHash = cp.causalConfigHash !== undefined;
    if (hasCfg !== hasHash) throw new RuntimeError("E_METADATA_INCONSISTENT", "causalConfig и causalConfigHash обязаны присутствовать парно");
    if (this.#causalFactsEnabled) {                       // P1.13: metadata.causalConfig ↔ checkpoint
      const declared = [...this.#metadata.causalConfig].sort();
      const actual = Object.keys(cp.causalConfig ?? {}).sort();
      if (JSON.stringify(declared) !== JSON.stringify(actual)) throw new RuntimeError("E_METADATA_INCONSISTENT", `causalConfig metadata ${JSON.stringify(declared)} ≠ checkpoint ${JSON.stringify(actual)}`);
      if (contentHash(cp.causalConfig) !== cp.causalConfigHash) throw new RuntimeError("E_METADATA_INCONSISTENT", "causalConfigHash checkpoint не совпадает");
    }
    this.#initialStateHash = causalStateHash(cp); this.#invocationBase = this.#initialStateHash;
    this.#runtimeState = Object.freeze({ ...this.#runtimeState, nextExpectedSeq: Number.isSafeInteger(cp.cursors?.nextFactSeq) ? cp.cursors.nextFactSeq : 0 });
    this.#phase = "OPEN";
    return { initialStateHash: this.#initialStateHash, nextExpectedSeq: this.#runtimeState.nextExpectedSeq };
  }
  #invocationId(d, v, o) { return contentHash({ run: this.#invocationBase, detectorId: d, version: v, ordinal: o }); }

  async #rollbackOrIndeterminate(cp, before) {
    try { await this.#host.restore(cp); if (causalStateHash(await this.#host.checkpoint()) === before) return "rolled-back"; } catch { /* */ }
    this.#phase = "CAUSAL_INDETERMINATE"; return "indeterminate";
  }

  async tick(batch = 1, { dropSnapshots = false, dropFactSeqs = null, failAt = null } = {}) {
    if (this.#phase !== "OPEN") throw new RuntimeError("E_PHASE", `tick в фазе ${this.#phase}`);
    if (this.#tickInFlight) throw new RuntimeError("E_CONCURRENT_TICK", "tick уже выполняется");
    this.#tickInFlight = true;
    const rs0 = this.#runtimeState;
    const reportSeq = rs0.reportSeq;
    const staging = new TransitionStaging(reportSeq);
    let token = null;
    try {
      const cp = await this.#host.checkpoint();
      const before = causalStateHash(cp);
      const emitEvery = (cp.scalars && Number.isInteger(cp.scalars.emitEvery)) ? cp.scalars.emitEvery : 1;
      const t = cp.tick ?? 0;
      const demand = this.#causalFactsEnabled ? (Math.floor((t + batch) / emitEvery) - Math.floor(t / emitEvery)) : 0;
      token = this.#retention.reserve(demand);

      let report;
      try { report = await this.#host.step(batch); }
      catch (e) { this.#retention.cancelReservation(token); staging.rollback(); throw e; }
      const after = causalStateHash(await this.#host.checkpoint());

      let prepared = null, marker = null, identity = null, nextState = null;
      try {
        if (failAt === "validate") throw new RuntimeError("E_IO", "сбой на валидации");
        assertCausalFactsCapability(this.#metadata, report);
        assertEpoch(KERNEL_EPOCH_PINNED);
        let expect = rs0.nextExpectedSeq;
        for (const f of report.facts) { if (f.seq !== expect) throw new RuntimeError("E_SEQ_MONOTONIC", `seq ${f.seq}≠${expect}`); expect++; }
        if (report.facts.length !== demand) throw new RuntimeError("E_FACT_DEMAND_MISMATCH", `report ${report.facts.length}≠demand ${demand}`);
        staging.validated();

        if (failAt === "stage") throw new RuntimeError("E_IO", "сбой на staging");
        const cfs = report.facts.map((f) => this.#causalFactFromReport(f));
        const root = factsRoot(cfs);
        const ev = {
          reportSeq, kernelEpoch: KERNEL_EPOCH_PINNED, causalConfigHash: cp.causalConfigHash,
          tickStart: report.tickStart, tickEnd: report.tickEnd, stateHashBefore: before, stateHashAfter: after,
          factCount: cfs.length, firstFactSeq: cfs.length ? cfs[0].seq : null, lastFactSeq: cfs.length ? cfs[cfs.length - 1].seq : null, factsRoot: root,
        };
        ev.transitionEvidenceHash = transitionEvidenceHash(ev);
        ev.transactionId = transactionId(reportSeq, before, after);
        staging.staged();

        // Полное построение следующего immutable root-state ДО install:
        if (failAt === "prepare") throw new RuntimeError("E_IO", "сбой до prepareCommit");
        prepared = this.#retention.prepareCommit(token, cfs);
        if (failAt === "afterPrepare") throw new RuntimeError("E_IO", "сбой после prepareCommit, до identity");
        identity = deepFreeze({ reportSeq, tickStart: ev.tickStart, tickEnd: ev.tickEnd, kernelEpoch: KERNEL_EPOCH_PINNED,
          stateHashBefore: before, stateHashAfter: after, factCount: ev.factCount, factCountDeclared: ev.factCount,
          firstFactSeq: ev.firstFactSeq, lastFactSeq: ev.lastFactSeq, factsRoot: root });
        if (failAt === "afterIdentity") throw new RuntimeError("E_IO", "сбой после identity, до marker");
        marker = deepFreeze({ marker: "STEP_COMMIT", reportSeq, transitionEvidenceHash: ev.transitionEvidenceHash, transactionId: ev.transactionId, evidence: ev, facts: cfs });
        if (failAt === "afterMarker") throw new RuntimeError("E_IO", "сбой после marker, до install");
        nextState = Object.freeze({
          identityChain: Object.freeze([...rs0.identityChain, identity]),
          committed: Object.freeze([...rs0.committed, marker]),
          wal: Object.freeze([...rs0.wal, marker]),
          reportSeq: reportSeq + 1, nextExpectedSeq: expect,
        });
        staging.beginCommit();      // проверка COMMITTING ДО install (может бросить — ещё pre-commit)
      } catch (prep) {
        this.#retention.cancelReservation(token); token = null;
        if (!["COMMITTING"].includes(staging.phase)) { try { staging.rollback(); } catch {} }
        const outcome = await this.#rollbackOrIndeterminate(cp, before);
        void outcome; throw prep;   // общее состояние нетронуто: partial persist невозможен
      }

      // ── INSTALL: без user-кода/IO/await/валидации/намеренных throw ──
      try {
        this.#runtimeState = nextState;          // переключение корня
        this.#retention.applyPrepared(prepared); // переключение ссылки custody
        staging.markCommitted();
      } catch (unexpected) {
        this.#phase = "CAUSAL_INDETERMINATE";    // атомарность недоказуема
        throw new RuntimeError("E_CAUSAL_INDETERMINATE", `сбой во время install: ${unexpected.message}`);
      }
      token = null;

      // ── PUBLISH (фаза 2): committed ≠ published ──
      let allPublished = true;
      for (const cf of marker.facts) {
        try {
          const body = { ...archiveValue(cf), factId: cf.factId };
          this.#journal.noteProduced("facts", cf.seq, "kernel", "dense-from-0", contentHash(body));
          const drop = dropFactSeqs && dropFactSeqs.has(cf.seq);
          if (!drop) { const fid = await this.#journal.recordFact(cf); if (fid) this.#retention.releaseToArchive(cf.seq); else allPublished = false; }
          else allPublished = false;
        } catch { allPublished = false; }
      }
      staging.publish(allPublished);

      // ── post-commit наблюдение: полностью поглощается ──
      let observationStatus = "OK";
      try {
        if (!dropSnapshots) this.#ring.produce(await this.#host.checkpoint());
        else this.#ring.telemetry.dropped++;
        await this.#pump();
      } catch { observationStatus = "FAILED"; }

      return { committed: true, report, identity, publishStatus: allPublished ? "PUBLISHED" : "PARTIAL", stagingPhase: staging.phase, observationStatus };
    } finally { this.#tickInFlight = false; }
  }

  #causalFactFromReport(f) { const factId = `fact:${f.seq}`; return { tier: "fact", type: f.type, causalTick: f.tick, seq: f.seq, factId, payload: f.payload, envelope: { correlationId: factId } }; }

  async #pump() {
    for (const { header, buf } of this.#ring.takeAll()) {
      try {
        const view = decodeSeriesView(buf);
        for (let oi = 0; oi < this.#observers.length; oi++) {
          const obs = this.#observers[oi];
          try {
            const raw = obs.observe(view, header);
            if (raw) {
              await this.#journal.appendClaim({ tier: "claim", type: raw.type, emittedSeq: this.#emittedSeq++, snapshotTick: header.tick, payload: raw.payload,
                provenance: { detectorId: obs.descriptor.detectorId, detectorVersion: obs.descriptor.version, configHash: obs.configHash,
                  producerInvocationId: this.#invocationId(obs.descriptor.detectorId, obs.descriptor.version, oi), emissionIndexWithinInvocation: this.#emissionIndex++, analysisRevisionId: "live" },
                envelope: { correlationId: `claim:${this.#invocationId(obs.descriptor.detectorId, obs.descriptor.version, oi)}:${this.#emissionIndex}` } });
              if (this.#diagnostic) this.diag.claimsEmitted++;
            }
          } catch (e) {
            const code = (typeof e.code === "string" && /^E_[A-Z0-9_]+$/.test(e.code)) ? e.code : "E_OBSERVER_FAILURE";
            try { await this.#journal.appendObserverFailure({ tier: "claim", type: "claim.observer.failure", failureStage: "OBSERVE", errorCode: code, errorCategory: "logic",
              producerInvocationId: this.#invocationId(obs.descriptor?.detectorId ?? "?", obs.descriptor?.version ?? "?", oi),
              detectorId: obs.descriptor?.detectorId ?? "unknown", detectorVersion: obs.descriptor?.version ?? "0", configHash: obs.configHash ?? "0".repeat(64),
              failureIndexWithinInvocation: this.#emissionIndex++, snapshotTick: header.tick, envelope: { correlationId: `ofail:${this.#emissionIndex}` } }); } catch {}
          }
        }
      } catch { /* decode одного handle — не роняет пул */ } finally { this.#ring.release(buf); }
    }
  }

  /** seal читает только приватный commit store; проверки — чистыми функциями. */
  async seal(opts) {
    if (this.#phase === "CAUSAL_INDETERMINATE") throw new RuntimeError("E_CAUSAL_INDETERMINATE", "герметизация запрещена после неопределённого перехода");
    if (this.#phase !== "OPEN") throw new RuntimeError("E_PHASE", `seal в фазе ${this.#phase}`);
    this.#phase = "SEALING";
    try {
      const rs = this.#runtimeState;
      const terminalStateHash = causalStateHash(await this.#host.checkpoint());
      const chainV = validateIdentityChain(rs.identityChain, { initialStateHash: this.#initialStateHash, terminalStateHash });
      const covV = verifyCommitCoverage(rs);
      if (opts.execution === "COMPLETED" && (chainV.length || covV.length)) { this.#phase = "OPEN"; throw new RuntimeError("E_JOURNAL_INCONSISTENT", `структура/покрытие (${chainV.length + covV.length}): ${chainV[0]?.message ?? covV[0]?.why}`); }
      const final = await this.#journal.finalize(opts);        // finalize/repair
      const evV = verifyCommittedEvidence(rs, await this.#journal.replay()); // перепроверка ПОСЛЕ repair
      if (opts.execution === "COMPLETED" && evV.length) { this.#phase = "OPEN"; throw new RuntimeError("E_JOURNAL_INCONSISTENT", `evidence после repair (${evV.length}): ${evV[0].why}`); }
      this.#phase = final.runSealStatus === "SEALED" ? "SEALED" : "UNSEALED";
      return final;
    } catch (e) { if (this.#phase === "SEALING") this.#phase = "SEAL_FAILED"; throw e; }
  }
  close() { if (!["SEALED", "UNSEALED", "SEAL_FAILED", "CAUSAL_INDETERMINATE", "CREATED"].includes(this.#phase)) throw new RuntimeError("E_PHASE", `close в фазе ${this.#phase}`); this.#phase = "CLOSED"; }
}
