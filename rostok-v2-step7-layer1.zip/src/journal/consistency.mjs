/**
 * consistency.mjs — JournalConsistencyValidator (Ф2, §11).
 *
 * Второй уровень принуждения: схема проверяет форму отдельной записи,
 * этот валидатор — топологию ссылок всего набора. Журнал — ориентированный
 * причинный гиперграф: вершины — записи, рёбра — commandId, causationId,
 * correlationId, kernelFactId. Нарушения причинной структуры:
 *
 * И1 отсутствующая ссылка (висячий commandId / kernelFactId / causationId)
 * И2 ссылка на объект другого типа
 * И3 ссылка на запись другого запуска (runRef)
 * И4 APPLIED при fact.command.reject (исход ↔ тип факта)
 * И5 два разных терминальных результата одной команды
 * И6 один факт, присвоенный двум командам
 * И7 цикл causationId
 *
 * Вход — сырые архивные записи ({id, kind, runRef, body, order});
 * выход — список нарушений {invariant, message}. Пустой список = журнал
 * причинно согласован.
 */

export function validateJournalConsistency(records) {
  const violations = [];
  const add = (invariant, message) => violations.push({ invariant, message });

  const byId = new Map();
  for (const r of records) byId.set(r.id, r);

  const commands = records.filter((r) => r.kind === "command-record");
  const results = records.filter((r) => r.kind === "command-result");
  const facts = records.filter((r) => r.kind === "causal-fact");
  const commandIds = new Set(commands.map((r) => r.body.commandId));

  /* И5: единственность терминального результата */
  const resultByCommand = new Map();
  for (const res of results) {
    const cid = res.body.commandId;
    if (resultByCommand.has(cid)) {
      const prev = resultByCommand.get(cid);
      if (prev.contentHash !== res.contentHash) {
        add("И5", `команда ${cid}: два разных терминальных результата (${prev.body.commandOutcome} и ${res.body.commandOutcome})`);
      }
    } else resultByCommand.set(cid, res);
  }

  /* И6: один факт — двум командам */
  const factOwner = new Map();
  for (const res of results) {
    const fid = res.body.kernelFactId;
    if (!fid) continue;
    if (factOwner.has(fid) && factOwner.get(fid) !== res.body.commandId) {
      add("И6", `факт ${fid} присвоен двум командам: ${factOwner.get(fid)} и ${res.body.commandId}`);
    } else factOwner.set(fid, res.body.commandId);
  }

  for (const res of results) {
    const cid = res.body.commandId;
    /* И1/И2/И3: commandId */
    if (!commandIds.has(cid)) {
      const target = byId.get(cid);
      if (!target) add("И1", `command-result ${res.id}: commandId ${cid} не существует`);
      else if (target.kind !== "command-record") add("И2", `command-result ${res.id}: commandId указывает на ${target.kind}`);
    } else {
      const target = commands.find((c) => c.body.commandId === cid);
      if (target && target.runRef !== res.runRef) {
        add("И3", `command-result ${res.id}: команда принадлежит запуску ${target.runRef}, результат — ${res.runRef}`);
      }
    }
    /* И1/И2/И3/И4: kernelFactId */
    const fid = res.body.kernelFactId;
    const outcome = res.body.commandOutcome;
    if (fid) {
      const fact = byId.get(fid);
      if (!fact) add("И1", `command-result ${res.id}: kernelFactId ${fid} не существует`);
      else if (fact.kind !== "causal-fact") add("И2", `command-result ${res.id}: kernelFactId указывает на ${fact.kind}`);
      else {
        if (fact.runRef !== res.runRef) add("И3", `command-result ${res.id}: факт из запуска ${fact.runRef}`);
        if (outcome === "APPLIED" && fact.body.type !== "fact.command.apply") {
          add("И4", `command-result ${res.id}: APPLIED при факте ${fact.body.type}`);
        }
        if (outcome === "REJECTED" && fact.body.type !== "fact.command.reject") {
          add("И4", `command-result ${res.id}: REJECTED при факте ${fact.body.type}`);
        }
      }
    } else if (outcome === "APPLIED" || outcome === "REJECTED") {
      add("И4", `command-result ${res.id}: ${outcome} без подтверждающего факта ядра`);
    }
  }

  /* И1/И2/И3 для causationId всех записей; И7 — цикл */
  for (const r of records) {
    const cz = r.body.envelope?.causationId;
    if (!cz) continue;
    const target = byId.get(cz);
    if (!target) { add("И1", `${r.id}: causationId ${cz} не существует`); continue; }
    if (target.runRef !== r.runRef) add("И3", `${r.id}: causationId из запуска ${target.runRef}`);
  }
  // И7: обход цепочек causationId
  for (const r of records) {
    const seen = new Set();
    let cur = r;
    while (cur) {
      if (seen.has(cur.id)) { add("И7", `цикл causationId через ${cur.id}`); break; }
      seen.add(cur.id);
      const cz = cur.body.envelope?.causationId;
      cur = cz ? byId.get(cz) ?? null : null;
    }
  }

  // дедупликация одинаковых сообщений (обход И7 репортит цикл с каждой вершины)
  const uniq = [];
  const seenMsg = new Set();
  for (const v of violations) {
    const k = v.invariant + "|" + v.message;
    if (!seenMsg.has(k)) { seenMsg.add(k); uniq.push(v); }
  }
  return uniq;
}
