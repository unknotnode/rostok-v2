/**
 * run-journal.mjs — реализация two-tier-journal/1.0.0 (§11).
 *
 * RunJournal — журнальный слой запуска поверх контракта драйвера шага 4
 * (атомарный putIfAbsent + канонические байты). Generic-архив шага 4
 * остаётся базой хранения; семантика эксперимента (оси статуса, команды,
 * полнота, идентичность) с этого шага живёт здесь.
 *
 * Законы, реализованные кодом:
 * - commandOutcome: PENDING → APPLIED | REJECTED | FAILED_BY_KERNEL |
 *   OUTCOME_UNKNOWN — терминально, ровно один переход (E_TRANSITION);
 * - journalStatus: RECORDED → RESULT_RECORDED | RESULT_MISSING; отказ
 *   записи результата НЕ меняет исход и НЕ меняет runIdentityHash —
 *   он меняет только seal (У1);
 * - три оси: execution / seal / audit; SEALED при COMPLETED или ABORTED
 *   (Ф1: для ABORTED обязательны terminationReason, terminalTick и
 *   checkpoint либо явное обоснование); OUTCOME_UNKNOWN ⇒ только
 *   ABORTED+UNSEALED, runIdentityClass = causal-indeterminate (Ф4);
 * - манифест полноты — проверяемые диапазоны (§7), читатель отвергает
 *   противоречивый манифест; auditStatus пересчитывается, не читается;
 * - repair (В4): только повторная выдача уже порождённого факта из
 *   детерминированного источника; обязателен до finalize; история
 *   repair остаётся в архиве;
 * - replay: три раздельных нормативных порядка + командные цепочки по
 *   correlationId (§2).
 */
import { archiveValue, canonicalBytes, contentHash, deepFreeze } from "../lib/canonical.mjs";
import { EXPERIMENT_IDENTITY_FIELDS, InMemoryDriver } from "../archive/archive.mjs";
import { validateJournalConsistency } from "./consistency.mjs";

export const JOURNAL_KINDS = [
  "protocol", "causal-fact", "command-record", "command-result",
  "observer-claim", "observer-failure", "infrastructure-failure",
  "checkpoint", "repair", "result", "post-analysis-revision",
];

const err = (code, message) => { const e = new Error(message); e.code = code; return e; };

const TERMINAL_OUTCOMES = ["APPLIED", "REJECTED", "FAILED_BY_KERNEL", "OUTCOME_UNKNOWN"];

/* ── трекер полноты потока: диапазоны, HWM, дубликаты, конфликты ── */
class StreamTracker {
  constructor(streamId, producerId, expectedSeqPolicy) {
    this.streamId = streamId;
    this.producerId = producerId;
    this.expectedSeqPolicy = expectedSeqPolicy; // "dense-from-0" | "dense-from-1" | "sparse"
    this.recorded = new Set();
    this.highWaterMark = null;
    this.duplicateCount = 0;
    this.conflictCount = 0;
    this.repaired = new Set();
    this.permanent = new Set();
    this.evidence = new Map(); // seq → contentHash (producer evidence)
  }
  noteProduced(seq) {
    if (this.highWaterMark === null || seq > this.highWaterMark) this.highWaterMark = seq;
  }
  noteRecorded(seq) { this.recorded.add(seq); this.noteProduced(seq); }
  ranges(set) {
    const seqs = [...set].sort((a, b) => a - b);
    const out = [];
    for (const s of seqs) {
      const last = out[out.length - 1];
      if (last && s === last.to + 1) last.to = s;
      else out.push({ from: s, to: s });
    }
    return out;
  }
  missing() {
    if (this.highWaterMark === null) return [];
    const start = this.expectedSeqPolicy === "dense-from-1" ? 1 : 0;
    const miss = new Set();
    for (let s = start; s <= this.highWaterMark; s++) {
      if (!this.recorded.has(s)) miss.add(s);
    }
    return this.ranges(miss);
  }
  manifestEntry(computedBy, computationVersion, hasSource) {
    const missingRanges = this.missing();
    const missingSet = new Set();
    for (const r of missingRanges) for (let s = r.from; s <= r.to; s++) missingSet.add(s);
    const permanentNow = new Set([...this.permanent].filter((s) => missingSet.has(s)));
    const recoverableNow = hasSource
      ? new Set([...missingSet].filter((s) => !permanentNow.has(s)))
      : new Set();
    return {
      streamId: this.streamId,
      producerId: this.producerId,
      expectedSeqPolicy: this.expectedSeqPolicy,
      firstObservedSeq: this.recorded.size ? Math.min(...this.recorded) : null,
      sourceHighWaterMark: this.highWaterMark,
      recordedSeqRanges: this.ranges(this.recorded),
      missingSeqRanges: missingRanges,
      duplicateCount: this.duplicateCount,
      conflictCount: this.conflictCount,
      recoverableRanges: this.ranges(recoverableNow),   // ⊆ missing
      permanentRanges: this.ranges(permanentNow),       // ⊆ missing
      evidenceSource: "journal-tracker",
      computedBy, computationVersion,
    };
  }
}

export class RunJournal {
  /**
   * driver — контракт putIfAbsent шага 4; validateRecord(schemaName, data)
   * → {ok, errors} — инъецируемый схемный валидатор (журнал не тянет fs).
   */
  constructor(driver = new InMemoryDriver(), { validateRecord = null, maxInfraRetained = 256 } = {}) {
    this._driver = driver;
    this._validateRecord = validateRecord;
    this._state = "created"; // created | open | finalized | closed
    this._archiveSeq = 0;
    this._protocol = null;
    this._runRef = null;
    this._hashes = null;
    this._envHash = null;
    this._commandSeq = 0;
    this._commandQueue = Promise.resolve();
    this._commands = new Map(); // commandId → { seq, body, tick, tickField, outcome, journalStatus, kernelFactId, resolvedTick }
    this._factIdToCommand = new Map();
    this._streams = new Map();
    this._reissueSources = new Map(); // streamId → (seq) => fact|null
    this.infraFailureCount = 0;
    this.infraFailures = [];
    this._maxInfra = maxInfraRetained;
    this._final = null;
  }

  get state() { return this._state; }
  get hashes() { return this._hashes; }
  get final() { return this._final; }

  _guard(op, allowed) {
    if (!allowed.includes(this._state)) throw err("E_ARCHIVE_STATE", `${op} в состоянии ${this._state}`);
  }

  _schema(schemaName, data) {
    if (!this._validateRecord) return;
    const r = this._validateRecord(schemaName, data);
    if (!r.ok) {
      throw err("E_SCHEMA", `${schemaName}: ${r.errors.map((e) => `${e.path}: ${e.message}`).join("; ")}`);
    }
  }

  _stream(streamId, producerId, policy) {
    if (!this._streams.has(streamId)) this._streams.set(streamId, new StreamTracker(streamId, producerId, policy));
    return this._streams.get(streamId);
  }

  async _append(kind, id, body, order, runRef = this._runRef) {
    if (!JOURNAL_KINDS.includes(kind)) throw err("E_ARCHIVE_CONFLICT", `неизвестный вид: ${kind}`);
    const value = archiveValue(body);
    const canonical = canonicalBytes(value);
    const record = deepFreeze({
      id, kind, runRef,
      contentHash: contentHash(value),
      order: { tick: order.tick, seq: order.seq, archiveSeq: this._archiveSeq++ },
      body: deepFreeze(value),
    });
    const res = await this._driver.putIfAbsent(record, canonical);
    if (res.status === "CONFLICT") throw err("E_ARCHIVE_CONFLICT", `запись ${id}: иное содержимое`);
    return { record: res.record, inserted: res.status === "INSERTED", duplicate: res.status === "IDEMPOTENT" };
  }

  _infra(code, message, ref) {
    const inf = deepFreeze({ code, message, ref });
    this.infraFailureCount++;
    this.infraFailures.push(inf);
    if (this.infraFailures.length > this._maxInfra) this.infraFailures.splice(0, this.infraFailures.length - this._maxInfra);
    return this._append("infrastructure-failure", `infra:${this._archiveSeq}`, {
      kind: "infrastructure-failure", code, message: String(message),
      subsystem: ref?.subsystem ?? "journal", envelope: { correlationId: ref?.correlationId ?? "infra" },
    }, { tick: -1, seq: 0 }).catch(() => null);
  }

  /* ── открытие (транзакционное, К1) ── */

  async open(protocolDoc, environmentDoc) {
    this._guard("open", ["created"]);
    const value = deepFreeze(archiveValue(protocolDoc));
    const env = deepFreeze(archiveValue(environmentDoc ?? {}));
    const documentHash = contentHash(value);
    const projection = {};
    for (const f of EXPERIMENT_IDENTITY_FIELDS) if (f in value) projection[f] = value[f];
    const experimentIdentityHash = contentHash(projection);
    const executionEnvironmentHash = contentHash(env);
    // К1 полностью: ни один внутренний остаток (включая _runRef) не
    // мутируется до подтверждённой записи протокола.
    await this._append("protocol", `protocol:${value.id}`, value, { tick: -1, seq: -1 }, value.id);
    this._runRef = value.id;
    this._protocol = value;
    this._envHash = executionEnvironmentHash;
    this._hashes = deepFreeze({ documentHash, experimentIdentityHash, executionEnvironmentHash });
    this._state = "open";
    return this._hashes;
  }

  /* ── команды: fail-closed запись, машина исходов ── */

  submitCommand(cmd) {
    this._guard("submitCommand", ["open"]);
    const run = async () => {
      this._guard("submitCommand", ["open"]);
      const value = archiveValue(cmd);
      const seq = ++this._commandSeq;
      const commandId = `command:${seq}:${contentHash(value).slice(0, 12)}`;
      const tickField = "scheduledTick" in value ? "scheduledTick" : "requestedTick";
      const record = {
        kind: "command-record", commandId, commandSeq: seq,
        body: value.body ?? {}, [tickField]: value[tickField] ?? value.tick ?? 0,
        envelope: { correlationId: commandId },
      };
      this._schema("command-record", record);
      try {
        await this._append("command-record", commandId, record, { tick: record[tickField], seq });
      } catch (e) {
        throw err("E_COMMAND_JOURNAL", `журнал команд недоступен, команда НЕ применяется (seq ${seq} — пропуск): ${e.message}`);
      }
      this._commands.set(commandId, {
        seq, body: record.body, tick: record[tickField], tickField,
        outcome: "PENDING", journalStatus: "RECORDED", kernelFactId: null, resolvedTick: null,
      });
      return { commandId, seq };
    };
    const p = this._commandQueue.then(run);
    this._commandQueue = p.then(() => undefined, () => undefined);
    return p;
  }

  /** Факт ядра (fact.command.apply|reject) — причинная летопись, fail-open. */
  async recordFact(fact) {
    this._guard("recordFact", ["open"]);
    const factId = fact.factId ?? `fact:${fact.causalTick}:${fact.seq ?? 0}`;
    const body = { ...archiveValue(fact), factId };
    this._schema("causal-fact", body);
    const tracker = this._stream("facts", "kernel", "dense-from-0");
    try {
      const res = await this._append("causal-fact", factId, body, { tick: body.causalTick, seq: body.seq ?? 0 });
      if (res.duplicate) tracker.duplicateCount++;
      else tracker.noteRecorded(body.seq ?? 0);
      const cmdId = body.payload?.commandId;
      if (cmdId) {
        if (this._factIdToCommand.has(factId) && this._factIdToCommand.get(factId) !== cmdId) {
          tracker.conflictCount++;
        }
        this._factIdToCommand.set(factId, cmdId);
      }
      return factId;
    } catch (e) {
      if (e.code === "E_ARCHIVE_CONFLICT") { tracker.conflictCount++; }
      await this._infra(e.code ?? "E_ARCHIVE_WRITE", e.message, { correlationId: factId });
      tracker.noteProduced(body.seq ?? 0); // дыра летописи видима
      return null;
    }
  }

  /** Производитель сообщает верхнюю границу выданных seq (для manifest). */
  noteProduced(streamId, seq, producerId = "kernel", policy = "dense-from-0", factContentHash = null) {
    const t = this._stream(streamId, producerId, policy);
    t.noteProduced(seq);
    if (factContentHash) t.evidence.set(seq, factContentHash);
  }

  /**
   * Разрешение исхода команды. Терминально; APPLIED/REJECTED требуют
   * kernelFactId. Отказ записи result ⇒ journalStatus=RESULT_MISSING
   * (исход сохранён, идентичность не меняется — меняется seal).
   */
  async resolveCommand(commandId, outcome, { tick, kernelFactId = null } = {}) {
    this._guard("resolveCommand", ["open"]);
    const c = this._commands.get(commandId);
    if (!c) throw err("E_UNKNOWN_COMMAND", `command-result для неизвестной команды ${commandId}`);
    if (c.outcome !== "PENDING") {
      throw err("E_TRANSITION", `команда ${commandId} уже терминальна: ${c.outcome} → ${outcome} запрещён`);
    }
    if (!TERMINAL_OUTCOMES.includes(outcome)) throw err("E_TRANSITION", `неизвестный исход ${outcome}`);
    if ((outcome === "APPLIED" || outcome === "REJECTED") && !kernelFactId) {
      throw err("E_TRANSITION", `${outcome} без подтверждающего факта ядра запрещён (§3)`);
    }
    // Транзакционность (край 2 приёмки шага 5): кандидат строится и
    // валидируется ДО любой мутации памяти. Отказ схемы — ошибка вызова
    // (E_SCHEMA), команда остаётся PENDING; повторный корректный вызов
    // допустим. Контракт для Runtime: если ядро уже физически применило
    // воздействие, а корректный resolveCommand невозможен — Runtime
    // обязан вызвать resolveCommand(id, "OUTCOME_UNKNOWN", …). Только
    // отказ ЗАПИСИ уже подтверждённого исхода даёт RESULT_MISSING.
    const tickField = outcome === "APPLIED" ? "appliedTick" : "resolvedTick";
    const body = {
      kind: "command-result", commandId, commandOutcome: outcome,
      [tickField]: tick ?? 0, kernelFactId,
      envelope: { correlationId: commandId, ...(kernelFactId ? { causationId: kernelFactId } : {}) },
    };
    this._schema("command-result", body);       // может бросить: память не тронута
    c.outcome = outcome;                        // подтверждённый исход — только теперь
    c.resolvedTick = tick ?? null;
    c.kernelFactId = kernelFactId;
    try {
      await this._append("command-result", `${commandId}:result`, body, { tick: tick ?? -1, seq: c.seq });
      c.journalStatus = "RESULT_RECORDED";
    } catch (e) {
      c.journalStatus = "RESULT_MISSING"; // У1: исход известен, seal пострадает
      await this._infra(e.code ?? "E_ARCHIVE_WRITE", e.message, { correlationId: commandId });
    }
    return { outcome: c.outcome, journalStatus: c.journalStatus };
  }

  /* ── наблюдательный ярус: fail-open ── */

  async appendClaim(claim) {
    this._guard("appendClaim", ["open"]);
    try {
      this._schema("observer-claim", claim);
      const p = claim.provenance;
      const id = `claim:${p.producerInvocationId}:${p.emissionIndexWithinInvocation}`;
      await this._append("observer-claim", id, claim,
        { tick: claim.snapshotTick ?? claim.snapshotRange.toTick, seq: claim.emittedSeq });
      return id;
    } catch (e) {
      await this._infra(e.code ?? "E_ARCHIVE_WRITE", e.message, { correlationId: "claim" });
      return null;
    }
  }

  async appendObserverFailure(failure) {
    this._guard("appendObserverFailure", ["open"]);
    try {
      this._schema("observer-failure", failure);
      // Край 5: детерминированная идентичность эмиссии сбоя. archiveSeq —
      // только порядок приёма, в id не входит: повторная доставка того же
      // логического сбоя идемпотентна, как у ObserverClaim.
      const id = `ofail:${failure.producerInvocationId}:${failure.failureStage}:${failure.failureIndexWithinInvocation}`;
      await this._append("observer-failure", id, failure,
        { tick: failure.snapshotTick ?? -1, seq: failure.failureIndexWithinInvocation });
      return id;
    } catch (e) {
      await this._infra(e.code ?? "E_ARCHIVE_WRITE", e.message, { correlationId: "ofail" });
      return null;
    }
  }

  appendCheckpoint(name, state) {
    this._guard("appendCheckpoint", ["open"]);
    return this._append("checkpoint", `checkpoint:${name}`, state, { tick: state.tick ?? -1, seq: 0 })
      .then((r) => r.record, async (e) => { await this._infra(e.code, e.message, { correlationId: name }); return null; });
  }

  /* ── repair (В4): повторная выдача уже порождённого факта ── */

  /**
   * ReissueSource: { reissue(seq) → fact|null } либо функция (нормализуется).
   * Пять условий recoverability (В4) — контракт источника; журнал
   * дополнительно сверяет content identity повторно выданного факта с
   * producer evidence (noteProduced с хэшем), если evidence существует.
   */
  setReissueSource(streamId, source) {
    this._reissueSources.set(streamId, typeof source === "function" ? { reissue: source } : source);
  }

  async _attemptRepairs() {
    const history = [];
    for (const [streamId, tracker] of this._streams) {
      const source = this._reissueSources.get(streamId);
      for (const range of tracker.missing()) {
        for (let seq = range.from; seq <= range.to; seq++) {
          if (!source) { tracker.permanent.add(seq); history.push({ streamId, seq, outcome: "permanent" }); continue; }
          const fact = source.reissue(seq); // детерминированная ПОВТОРНАЯ ВЫДАЧА, не реконструкция
          if (fact === null || fact === undefined) {
            tracker.permanent.add(seq); history.push({ streamId, seq, outcome: "failed" });
            continue;
          }
          const factId = fact.factId ?? `fact:${fact.causalTick}:${fact.seq ?? seq}`;
          const body = { ...archiveValue(fact), factId };
          this._schema("causal-fact", body);
          const ev = tracker.evidence.get(seq);
          if (ev && contentHash(body) !== ev) {
            tracker.permanent.add(seq);
            history.push({ streamId, seq, outcome: "mismatch", code: "E_REISSUE_MISMATCH" });
            continue;
          }
          try {
            await this._append("causal-fact", factId, body, { tick: body.causalTick, seq });
            tracker.noteRecorded(seq);
            tracker.repaired.add(seq);
            history.push({ streamId, seq, outcome: "repaired" });
          } catch (e) {
            tracker.permanent.add(seq);
            history.push({ streamId, seq, outcome: "failed", code: e.code });
          }
        }
      }
    }
    for (const h of history) {
      await this._append("repair", `repair:${this._archiveSeq}`, { ...h, envelope: { correlationId: `${h.streamId}:${h.seq}` } },
        { tick: -1, seq: h.seq }).catch(() => null);
    }
    return history;
  }

  /* ── manifest и аудит ── */

  buildManifest() {
    return {
      computedAtArchiveSeq: this._archiveSeq,
      streams: [...this._streams.values()].map((t) =>
        t.manifestEntry("run-journal", "1.0.0", this._reissueSources.has(t.streamId))),
    };
  }

  static auditFromManifest(manifest) {
    const incomplete = manifest.streams.some((s) => s.missingSeqRanges.length > 0 || s.permanentRanges.length > 0);
    return incomplete ? "INCOMPLETE" : "COMPLETE";
  }

  /**
   * Читатель ОТВЕРГАЕТ противоречивый manifest (§7, край 4 приёмки шага 5).
   * Для плотных политик доказывается ПОКРЫТИЕ: recorded ∪ missing =
   * весь ожидаемый диапазон [start … HWM] и recorded ∩ missing = ∅.
   * Отсутствие сведений о хвосте диапазона — не «полнота», а подлог.
   */
  static verifyManifest(manifest, declaredAudit) {
    const reasons = [];
    const KNOWN_POLICIES = ["dense-from-0", "dense-from-1", "sparse"];
    const wellFormed = (ranges, name, streamId) => {
      for (const r of ranges) {
        if (!Number.isInteger(r.from) || !Number.isInteger(r.to) || r.from < 0 || r.to < 0) {
          reasons.push(`${streamId}: ${name}: нецелые/отрицательные границы`); return false;
        }
        if (r.from > r.to) { reasons.push(`${streamId}: ${name}: from ${r.from} > to ${r.to}`); return false; }
      }
      return true;
    };
    const toSet = (ranges) => {
      const s = new Set();
      for (const r of ranges) for (let q = r.from; q <= r.to; q++) s.add(q);
      return s;
    };
    const subset = (a, b) => [...a].every((x) => b.has(x));

    for (const s of manifest.streams) {
      if (!KNOWN_POLICIES.includes(s.expectedSeqPolicy)) {
        reasons.push(`${s.streamId}: неизвестная expectedSeqPolicy "${s.expectedSeqPolicy}"`);
        continue;
      }
      if (!wellFormed(s.recordedSeqRanges, "recorded", s.streamId)) continue;
      if (!wellFormed(s.missingSeqRanges, "missing", s.streamId)) continue;
      if (!wellFormed(s.recoverableRanges, "recoverable", s.streamId)) continue;
      if (!wellFormed(s.permanentRanges, "permanent", s.streamId)) continue;

      // Внутренние пересечения списка — нарушение сами по себе: toSet
      // склеил бы дубликаты молча, а молчаливых склеек не существует.
      const overlapInside = (ranges, name) => {
        const sorted = [...ranges].sort((a, b) => a.from - b.from);
        for (let i = 1; i < sorted.length; i++) {
          if (sorted[i].from <= sorted[i - 1].to) {
            reasons.push(`${s.streamId}: ${name}: диапазоны пересекаются ([${sorted[i - 1].from},${sorted[i - 1].to}] и [${sorted[i].from},${sorted[i].to}])`);
            return true;
          }
        }
        return false;
      };
      if (overlapInside(s.recordedSeqRanges, "recorded")) continue;
      if (overlapInside(s.missingSeqRanges, "missing")) continue;

      const rec = toSet(s.recordedSeqRanges);
      const mis = toSet(s.missingSeqRanges);
      const rcv = toSet(s.recoverableRanges);
      const perm = toSet(s.permanentRanges);

      for (const q of mis) if (rec.has(q)) { reasons.push(`${s.streamId}: missing∩recorded ≠ ∅ (seq ${q})`); break; }
      if (!subset(perm, mis)) reasons.push(`${s.streamId}: permanent ⊄ missing`);
      if (!subset(rcv, mis)) reasons.push(`${s.streamId}: recoverable ⊄ missing`);
      for (const q of rcv) if (perm.has(q)) { reasons.push(`${s.streamId}: recoverable∩permanent ≠ ∅`); break; }

      const hwm = s.sourceHighWaterMark;
      if (hwm !== null) {
        for (const q of [...rec, ...mis]) {
          if (q > hwm) { reasons.push(`${s.streamId}: seq ${q} за пределами high-water mark ${hwm}`); break; }
        }
        const lastRecorded = rec.size ? Math.max(...rec) : null;
        if (lastRecorded !== null && hwm < lastRecorded) {
          reasons.push(`${s.streamId}: high-water mark ${hwm} < последнего seq ${lastRecorded}`);
        }
        // ПОКРЫТИЕ для плотных политик:
        if (s.expectedSeqPolicy !== "sparse") {
          const start = s.expectedSeqPolicy === "dense-from-1" ? 1 : 0;
          for (let q = start; q <= hwm; q++) {
            if (!rec.has(q) && !mis.has(q)) {
              reasons.push(`${s.streamId}: покрытие неполно — seq ${q} отсутствует и в recorded, и в missing`);
              break;
            }
          }
        }
      } else if (s.expectedSeqPolicy !== "sparse" && (rec.size || mis.size)) {
        reasons.push(`${s.streamId}: плотная политика без sourceHighWaterMark недоказуема`);
      }
      if (s.firstObservedSeq !== null && rec.size && s.firstObservedSeq !== Math.min(...rec)) {
        reasons.push(`${s.streamId}: firstObservedSeq ${s.firstObservedSeq} ≠ min(recorded)`);
      }
    }
    if (declaredAudit !== undefined && declaredAudit !== RunJournal.auditFromManifest(manifest)) {
      reasons.push(`заявленный auditStatus ${declaredAudit} ≠ пересчёту ${RunJournal.auditFromManifest(manifest)}`);
    }
    return { ok: reasons.length === 0, reasons };
  }

  /* ── финализация: три оси, идентичность, класс ── */

  _commandLedger() {
    return [...this._commands.entries()]
      .map(([commandId, c]) => ({ commandSeq: c.seq, commandId, body: c.body,
        [c.tickField]: c.tick,   // край 3: requestedTick и scheduledTick НЕ схлопываются
        commandOutcome: c.outcome, resolvedTick: c.resolvedTick, kernelFactId: c.kernelFactId }))
      .sort((a, b) => a.commandSeq - b.commandSeq);
  }

  /** Схемы записей по видам — для повторной проверки при финализации. */
  static RECORD_SCHEMAS = {
    "causal-fact": "causal-fact",
    "command-record": "command-record",
    "command-result": "command-result",
    "observer-claim": "observer-claim",
    "observer-failure": "observer-failure",
    "infrastructure-failure": "infrastructure-failure",
    "post-analysis-revision": "post-analysis-revision",
  };

  async _validateJournal() {
    const records = await this.records();
    const violations = [];
    for (const r of records) {
      const schemaName = RunJournal.RECORD_SCHEMAS[r.kind];
      if (!schemaName || !this._validateRecord) continue;
      const res = this._validateRecord(schemaName, r.body);
      if (!res.ok) {
        violations.push({ invariant: "СХЕМА", message: `${r.id}: ${res.errors.map((e) => `${e.path}: ${e.message}`).join("; ")}` });
      }
    }
    violations.push(...validateJournalConsistency(records));
    return violations;
  }

  async finalize({ execution, terminationReason = null, terminalTick = null, finalCheckpointRef = null, checkpointAbsenceJustification = null, result = {} }) {
    this._guard("finalize", ["open"]);
    const cmds = this._commandLedger();
    if (cmds.some((c) => c.commandOutcome === "PENDING")) {
      throw err("E_FINALIZE_PENDING", "финализация при незавершённых командах запрещена");
    }
    const hasUnknown = cmds.some((c) => c.commandOutcome === "OUTCOME_UNKNOWN");
    const hasMissing = [...this._commands.values()].some((c) => c.journalStatus === "RESULT_MISSING");
    if (hasUnknown && execution !== "ABORTED") {
      throw err("E_FINALIZE_INDETERMINATE", "OUTCOME_UNKNOWN: финализация допустима только как ABORTED (§3)");
    }
    // В4: repair обязателен до финализации
    const repairHistory = await this._attemptRepairs();

    // Край 1 приёмки шага 5: герметизация НЕДОСТИЖИМА без доказанной
    // согласованности причинного гиперграфа. Повторная схемная проверка
    // всех записей + JournalConsistencyValidator стоят на воротах SEALED.
    const consistencyViolations = await this._validateJournal();
    if (consistencyViolations.length > 0 && execution !== "ABORTED") {
      throw err("E_JOURNAL_INCONSISTENT",
        `причинная структура записей противоречива (${consistencyViolations.length}): ` +
        consistencyViolations.slice(0, 3).map((v) => `[${v.invariant}] ${v.message}`).join("; ") +
        "; допустимо только аварийное сохранение ABORTED+UNSEALED");
    }

    const manifest = this.buildManifest();
    const auditStatus = RunJournal.auditFromManifest(manifest);

    let seal;
    if (consistencyViolations.length > 0 || hasUnknown || hasMissing) seal = "UNSEALED";
    else if (execution === "COMPLETED") seal = "SEALED";
    else if (execution === "ABORTED") {
      // Ф1: герметичный обрыв требует полной атрибуции остановки
      if (terminationReason && Number.isInteger(terminalTick) && (finalCheckpointRef || checkpointAbsenceJustification)) {
        if (finalCheckpointRef) {
          // Верификация ссылки: существование, вид, принадлежность запуску, тик.
          const cp = (await this.records()).find((r) => r.id === finalCheckpointRef);
          if (!cp) throw err("E_SEAL_REQUIREMENTS", `finalCheckpointRef ${finalCheckpointRef}: запись не существует`);
          if (cp.kind !== "checkpoint") throw err("E_SEAL_REQUIREMENTS", `finalCheckpointRef указывает на ${cp.kind}`);
          if (cp.runRef !== this._runRef) throw err("E_SEAL_REQUIREMENTS", "finalCheckpointRef из другого запуска");
          if (cp.body.tick !== terminalTick) {
            throw err("E_SEAL_REQUIREMENTS", `тик checkpoint ${cp.body.tick} ≠ terminalTick ${terminalTick}`);
          }
        }
        seal = "SEALED";
      } else {
        throw err("E_SEAL_REQUIREMENTS",
          "ABORTED+SEALED требует terminationReason, terminalTick и checkpoint либо явного обоснования его отсутствия (Ф1)");
      }
    } else throw err("E_TRANSITION", `неизвестный runExecutionStatus ${execution}`);

    const runIdentityHash = contentHash({
      experimentIdentityHash: this._hashes.experimentIdentityHash,
      executionEnvironmentHash: this._envHash,
      commands: cmds,
    });
    const runIdentityClass = hasUnknown ? "causal-indeterminate" : "causal-confirmed";
    const final = {
      runExecutionStatus: execution, runSealStatus: seal, auditStatus,
      runIdentityHash, runIdentityClass,
      terminationReason, terminalTick, finalCheckpointRef, checkpointAbsenceJustification,
      consistencyViolations, manifest, repairHistory, ...archiveValue(result),
    };
    await this._append("result", `result:${this._runRef}`, final, { tick: Number.MAX_SAFE_INTEGER, seq: 0 });
    this._final = deepFreeze(final);
    this._state = "finalized";
    return this._final;
  }

  /** Сравнение — только causal-confirmed (Ф4). */
  static compare(finalA, finalB) {
    if (finalA.runIdentityClass !== "causal-confirmed" || finalB.runIdentityClass !== "causal-confirmed") {
      throw err("E_IDENTITY_CLASS", "сравнение runIdentityHash разрешено только между causal-confirmed запусками");
    }
    return finalA.runIdentityHash === finalB.runIdentityHash;
  }

  appendRevision(body) {
    this._guard("appendRevision", ["finalized"]);
    const rec = {
      kind: "post-analysis-revision",
      parentRunIdentityHash: this._final.runIdentityHash,
      ...archiveValue(body),
    };
    this._schema("post-analysis-revision", rec);
    return this._append("post-analysis-revision", `revision:${this._archiveSeq}`, rec,
      { tick: Number.MAX_SAFE_INTEGER, seq: this._archiveSeq }).then((r) => r.record);
  }

  dispose() { this._state = "closed"; }

  /* ── replay: три раздельных нормативных порядка ── */

  async replay() {
    const all = await this._driver.list();
    const mine = all.filter((r) => r.runRef === this._runRef);
    const causal = mine
      .filter((r) => ["causal-fact", "command-record", "command-result"].includes(r.kind))
      .sort((a, b) => (a.order.tick - b.order.tick) || (a.order.seq - b.order.seq) || (a.order.archiveSeq - b.order.archiveSeq));
    const emission = mine
      .filter((r) => ["observer-claim", "observer-failure"].includes(r.kind))
      .sort((a, b) => {
        const pa = a.body.provenance?.producerInvocationId ?? a.body.producerInvocationId ?? "";
        const pb = b.body.provenance?.producerInvocationId ?? b.body.producerInvocationId ?? "";
        if (pa !== pb) return pa < pb ? -1 : 1;
        return (a.body.emittedSeq ?? 0) - (b.body.emittedSeq ?? 0) || (a.order.archiveSeq - b.order.archiveSeq);
      });
    const receipt = [...mine].sort((a, b) => a.order.archiveSeq - b.order.archiveSeq);
    const chains = [];
    for (const cr of mine.filter((r) => r.kind === "command-record")) {
      const cid = cr.body.commandId;
      chains.push({
        commandId: cid,
        command: cr,
        fact: mine.find((r) => r.kind === "causal-fact" && r.body.envelope.correlationId === cid) ?? null,
        result: mine.find((r) => r.kind === "command-result" && r.body.commandId === cid) ?? null,
      });
    }
    return { causal, emission, receipt, chains };
  }

  async records() { return (await this._driver.list()).filter((r) => r.runRef === this._runRef); }
}
