# kernel-abi/2 — Спецификация ABI причинного ядра

Статус: 2.1.0 — аддитивная ревизия поверх зафиксированной 2.0.0
(добавлены deadRegions и уточнение семантики хэша; ничего из 2.0.0 не
изменено и не удалено, идентификатор канонизации прежний).
Канонизация: causal-state-hash/fnv1a64-le-v1, вектор a7cdfd3b306c5a77.
Источник истины. Код подчиняется этому документу.
Наследует kernel-abi/1 (синхронное ядро / асинхронный хост) и Д1–Д4.

Журнал ревизии: draft → rc1: (П1) графовый moveSet заменён на
moveClasses+moves; (П2) булев growthCapable заменён вектором
growthCapabilities с производным полем; (П3) extend-state разведён на
activate-dof / extend-logical-state / extend-capacity, последний —
команда среды, не ход ядра; (П4) буферы получили оси causal ×
numericClass вместо dynamical; (П5) нормативный checkpoint — только
каноническое base64 little-endian; (П6) checksum заменён на
CausalStateHash по полному причинному состоянию; (П7) dormant адресует
компоненты буферов, не буферы целиком; (П8) симметрии — версионированные
декларации закона, не свободные строки.

---

## 1. Двухуровневая модель

PhysicsKernel — синхронный, чистая вычислительная машина.
KernelHost — асинхронный (InProcess → Worker → Remote), FIFO;
Worker — хост по умолчанию с шага 1.

```ts
interface PhysicsKernel {
  metadata(): KernelMetadata;            // чистая, допустима всегда
  initialize(config: KernelConfig): void;
  step(n?: number): StepReport;          // n ≥ 1; step(n) ≡ n × step(1)
  checkpoint(): KernelState;             // чистое чтение, без RNG/IO
  restore(state: KernelState): void;
  shutdown(): void;                      // терминально
}
```

CREATED → initialize → READY → (step|checkpoint|restore)* → shutdown →
TERMINATED. Нарушения — коды §7.

## 2. KernelMetadata

Схема: `schema/kernel-metadata.schema.json`.

Идентичность: `name`, `version` (semver), `abiVersion`="kernel-abi/2",
`stateFormat`, `float`="f64", `deterministic`=true.

### 2.1. Ходы: классы и конкретика (П1, П3)

`moveClasses` лаборатории (закрытый enum):
modify-state, create-entity, remove-entity, create-relation,
remove-relation, activate-dof, extend-logical-state.

`moves` ядра: массив { id (namespaced), class ∈ moveClasses,
atomic: bool }. Классы дают лаборатории субстрат-агностичные выводы;
moves описывают конкретную физику. Составной ход (например слияние
носителей) декларируется отдельным атомарным move только если его
результат семантически неэквивалентен согласованной композиции
существующих ходов (сохранение заряда/фазы/истории носителя).

`extend-capacity` НЕ является классом хода ядра: физическое
пересоздание/увеличение буферов — команда среды (fact.command.apply)
и никогда автоматически не считается событием морфогенеза. Ядро само
вправе выполнять activate-dof; extend-logical-state допустим, только
если механизм заранее объявлен законом ядра.

### 2.2. Вектор конструктивных возможностей (П2)

```
growthCapabilities: {
  entityGrowth, relationGrowth, dofActivation,
  stateExtension, capacityExtension: boolean
}
growthCapable: boolean  // производное = OR всех пяти
```

Валидатор принуждает согласованность: entityGrowth ⇔ есть move класса
create-entity; relationGrowth ⇔ create-relation; dofActivation ⇔
activate-dof; stateExtension ⇔ extend-logical-state; capacityExtension
не имеет хода ядра (возможность среды); growthCapable = OR вектора.
Лаборатория различает рост числа сущностей и рост внутреннего
пространства состояний.

### 2.3. Буферы: causal × numericClass (П4)

Каждый буфер: name, dtype, components (≥1), capacity,
causal: bool, numericClass: "continuous" | "discrete", semantics.

Нормативные правила:
- causal + continuous → только f64;
- causal + discrete → u8/u16/u32 допустимы (курсоры, поколения,
  маски, счётчики, состояния дискретных автоматов);
- noncausal (производные кэши) → в KernelState НЕ входят;
- дискретность/структурность не освобождает от причинности:
  причинный курсор обязан быть в checkpoint (§5).

### 2.4. Спящие степени свободы (П7)

```
dormant: [{
  id: "link.phase",
  storage: { buffer, componentOffset, componentCount },
  capacity,
  coupling: { kind:"declared", channelId:"name@N" }
          | { kind:"none", justification }
}]
```

Спящая DOF — компонента/диапазон существующего буфера, не обязательно
отдельный буфер. Кросс-проверки: buffer существует;
offset+count ≤ components буфера. Компонента без канала инертна по
построению — её молчание не результат (Д3.2).

### 2.5. Потолки и симметрии (П8)

`ceilings` — явные потолки; занятость — штатная наблюдаемая рантайма.

`symmetries` — версионированные декларации симметрий ЗАКОНА ядра:
{ id (namespaced), version, scope:"law", actionRef? }.
Симметрии, найденные наблюдателем, — исключительно claims второго
яруса журнала и в metadata не хранятся никогда.

`views` — представления снимка ("graph-view@1", "lattice-view@1", ...).

`deadRegions` (необязательное) — декларация мёртвых ролевых областей:
{ id, kind:"overwrite-before-read", buffers, roleCursor, description }.
Область, чьё содержимое на границе такта полностью перезаписывается до
любого чтения; КАКОЙ именно буфер мёртв, определяется курсором роли
(например activePage), а не именем. Избыточность объявляется явно, а
не комментарием конкретного ядра.

## 3. KernelConfig

seed (uint32 master), params (валидирует ядро, E_CONFIG),
emitChecksum. RNG-потоки деривируются от master по именам;
Math.random запрещён по репозиторию (линт+CI).

## 4. StepReport и ярус фактов

```ts
interface StepReport {
  tickStart, tickEnd: number;   // tickEnd ≥ tickStart+1
  facts: FactEvent[];           // тик каждого ∈ (tickStart, tickEnd]
  checksum?: string;            // CausalStateHash (§5a), 16 hex
}
```

Факты: fact.element.birth, fact.link.create, fact.dormant.activate,
fact.command.apply, ... Провенанс у факта синтаксически отсутствует
(Д2.3). Заявления в StepReport появиться не могут.

## 5. KernelState и закон полноты (П5)

Содержит: stateFormat, kernelName, kernelVersion, abiVersion, tick,
полное состояние RNG-потоков, ВСЕ причинные буферы (включая дискретные
курсоры, очереди, временные буферы, переживающие границу такта),
scalars, cursors. Производные некаузальные кэши не входят.

Нормативное кодирование буфера — ТОЛЬКО каноническое бинарное:
{ dtype, numericClass, causal:true, length, byteOrder:"little-endian",
encoding:"base64", data }. Буфер в checkpoint самоописателен:
реклассификация буфера (causal/numericClass) меняет идентичность
состояния. JSON-массив чисел запрещён в checkpoint: он не сохраняет
payload NaN, −0 и сырое IEEE-754 представление. Человекочитаемый
экспорт числами — отдельный диагностический формат, не checkpoint.

**Закон полноты:** restore(checkpoint()) + step(k) бит-идентичен
непрерванному прогону — сравнение по сырым байтам буферов.

## 5a. CausalStateHash — causal-state-hash/fnv1a64-le-v1 (П6)

Хэш ПОЛНОГО причинного состояния. Канонизация имеет собственный
версионированный идентификатор: смена любой детали канонизации =
новый идентификатор, иначе идентичность экспериментов меняется молча.
Эталонная реализация: `tools/causal-hash.mjs`; закреплённый вектор:
`fixtures/hash-vector.json`.

Канонический байтовый поток (все многобайтовые целые — little-endian):

1. **Строки** кодируются как u32-LE длина в байтах + байты UTF-8.
   Никаких разделителей: длина-префикс исключает неоднозначность.
2. **Порядок полей** (фиксирован): str(идентификатор канонизации
   "causal-state-hash/fnv1a64-le-v1"); str(abiVersion);
   str(kernelName); str(kernelVersion); str(stateFormat);
   str("tick") + str(десятичная запись tick).
3. **Секция rng**: str("rng"), u32 число потоков, далее потоки,
   отсортированные по имени как последовательности байтов UTF-8:
   str(имя) + str(строковая запись значения).
4. **Секция scalars**: str("scalars"), u32 число ключей, ключи по
   байтовой сортировке: str(ключ) + 8 сырых байт IEEE-754 f64 LE.
   +0 и −0 различаются (разные биты). ±Infinity допустимы (их биты
   детерминированы). NaN — ошибка E_NAN_STATE, если схема ядра явно
   не разрешила NaN.
5. **Секция cursors**: str("cursors"), u32 число ключей, ключи по
   байтовой сортировке: str(ключ) + str(десятичная запись значения).
6. **Секция buffers**: str("buffers"), u32 число буферов, буферы по
   байтовой сортировке имён: str(имя) + str(dtype) +
   str(numericClass) + 1 байт causal (0x01) + u32 length (число
   элементов) + u32 byteLength + сырые байты LE. Пустой буфер:
   length=0, byteLength=0, ноль байтов данных — определённое
   поведение, не особый случай. Для f64-буферов выполняется
   NaN-скан (политика п.4); дискретные причинные u8/u16/u32 входят
   в хэш наравне с f64.
7. **Канонические целые**: tick и cursors — целые в диапазоне
   0…9007199254740991 (MAX_SAFE_INTEGER); состояние RNG-потоков —
   ТОЛЬКО канонические десятичные строки ^(0|[1-9][0-9]*)$ (без «+»,
   ведущих нулей и экспоненциальной записи): одно логическое значение
   имеет ровно одно представление, двойственность 123/"123" запрещена
   схемой. Эталон дополнительно проверяет каноничность и бросает
   E_STATE_FORMAT при нарушении.
8. **Хэш**: FNV-1a 64-bit по всему потоку
   (offset 0xcbf29ce484222325, prime 0x100000001b3), результат —
   16 hex-символов в нижнем регистре.

Свойства по построению: хэш не зависит от порядка ключей в JSON
(всюду сортировка); чувствителен к dtype, length, causal,
numericClass, реклассификации и к каждому биту данных, включая
знак нуля и канонические IEEE-754 представления ±Infinity.

**Семантика (нормативно).** causal-state-hash/fnv1a64-le-v1 — хэш
ПОЛНОЙ НОРМАТИВНОЙ ПРИЧИННОЙ ЗАПИСИ (RawCausalRecordHash), включая
разрешённую избыточность мёртвых ролевых областей. Гарантии:
равенство хэшей ДОСТАТОЧНО для битового равенства записи состояния
(и, следовательно, равенства будущего); НЕравенство хэшей НЕ всегда
означает различие будущих траекторий, если ядро декларирует
deadRegions — два состояния, различающиеся только содержимым мёртвой
роли, имеют одинаковое будущее при любой допустимой последовательности
вызовов. Анализаторы и conformance-логика ОБЯЗАНЫ не трактовать
различие в deadRegions как физическое расхождение. Каноническая
эквивалентность будущего (FutureCausalHash с ролевой канонизацией) —
отдельная возможная схема с собственным идентификатором; в 2.x не
вводится.

## 6. Снимки (Д4)

Снимок ≠ checkpoint. Ownership-протокол Д4: кольцо ≥3 transferable /
копия / SAB+epoch (режим в манифесте), drop-not-block, счётчик
пропусков обязателен. Живое состояние не покидает ядро.

## 7. Ошибки

E_ALREADY_INITIALIZED, E_NOT_INITIALIZED, E_TERMINATED, E_STATE_FORMAT,
E_CONFIG, E_BAD_ARG, E_NAN_STATE. Формат { code, message, details? }.

## 8. Детерминизм

Внутри платформы: (версия ядра, config, последовательность вызовов,
журнал команд) → бит-идентичная траектория. Межплатформенно —
эквивалентность по метрикам с допусками; обе гарантии — в протоколе.

## 9. Conformance-законы

C1 детерминизм seed→траектория (CausalStateHash на контрольных тиках).
C2 step(n)≡n×step(1). C3 checkpoint→restore→continue ≡ непрерванный.
C4 чистота checkpoint. C5 терминальность shutdown. C6 metadata по
схеме + кросс-проверки (П1–П4, П7–П8). C7 пассивность анализаторов
(A/B). C8 схемный гейт журнала (гибрид отклоняется). C9 checkpoint
только в каноническом base64-LE; CausalStateHash совпадает с эталонной
реализацией на тест-векторе.

## 10. Реестр артефактов шага 0

Схемы: kernel-metadata, kernel-config, kernel-state, step-report,
event, snapshot-header, experiment-protocol. Валидатор:
tools/validate.mjs (неизвестное ключевое слово схемы — ошибка).
Эталонный хэш: tools/causal-hash.mjs + fixtures/hash-vector.json.
Фикстуры: fixtures/valid, fixtures/invalid; запуск
`node tools/run-fixtures.mjs`, ненулевой код при расхождении.

## 11. Изменение документа

Любое изменение семантики — новая версия abiVersion. Порядок: гипотеза
→ спецификация → критика → исправленная спецификация → код. Статус
rc1 фиксируется в 2.0.0 решением главного архитектора.
