# stability-profile/1 — профиль проверки устойчивости

Статус: ЗАФИКСИРОВАН. Нормативная зависимость `execution-security/1.0.0`
(SHA-256 `e2183492cb8ff692095438cb1803ff0b18ba688d4223349ddd26e3c7cbcb0e05`),
§2a и §5.2. Настоящий документ задаёт конкретные значения; структура
задана законом. Источник предложения не выбирает ни одно значение
отсюда.

Идентификация:

    stabilityProfileId: "stability-profile/1"
    stabilityProfileVersion: "1.0.0"
    applicableKernelAbi: "kernel-abi/2.2.0"
    applicableCalibrationSurfaceId: "calibration-surface/1"

`stabilityProfileHash` = SHA-256 канонического содержимого документа;
закрепляется в foundation. Несовпадение ⇒ `E_STABILITY_PROFILE_MISMATCH`.

---

## 1. Окна

    minimumWindowTransitions:              3
    minimumIdentityPersistenceTransitions: 3

Нижний предел закона — 2/2; настоящий профиль требует 3/3. Значения
профильные, не универсальные: они не зашиваются в общий валидатор
закона. Изменение — новая версия документа, не калибровка.

---

## 2. Правила окна доказательства

    evidenceWindowRules:
      window.firstReportSeq <= window.lastReportSeq
      (lastReportSeq - firstReportSeq + 1) >= minimumWindowTransitions
      все reportSeq окна принадлежат принятым STEP_COMMIT
      окно не пересекает CALIBRATION_BINDING_PENDING
      окно не включает переходы, произведённые в sandbox

---

## 3. Метрики (пересчитываются оболочкой)

    metricDefinitions:
      M1 identityPersistence
         доля переходов окна, в которых sourceNodeId сохраняет
         идентичность узла по правилам shellRecomputationRules
      M2 boundedResponse
         максимальное относительное отклонение наблюдаемой величины узла
         при применении PerturbationCase, нормированное на magnitude
      M3 recoveryWithinWindow
         возврат величины в исходный коридор за durationTransitions
         после снятия возмущения

    acceptanceThresholds:
      M1 >= 1.0            // идентичность сохраняется во всех переходах окна
      M2 <= 4.0            // отклик ограничен, без разгона
      M3 == true           // возврат в коридор обязателен

---

## 4. Правила пересчёта

    shellRecomputationRules:
      источник метрик — только committed causal records
      observer output допустим как индекс окна, не как значение метрики
      все величины пересчитываются из causal replay
      stabilityEvidenceHash вычисляет shell; значение из предложения
        не принимается (⇒ E_STABILITY_METRIC_SOURCE)
      арифметика — Neumaier-суммирование, f64, без locale-зависимости

---

## 5. Набор возмущений

Выполняется полный набор. Все возмущения — над отделённой копией
состояния (§5.6 закона): без production `fact.seq`, без публикации фактов,
без изменения retention custody, replay registry и бюджета, без создания
STEP_COMMIT.

    P1 { perturbationId: "drive.nudge.up",
         targetPath: "causalConfig.drive",
         operation: bounded-add,   magnitude: +0.05,
         durationTransitions: 3,   restoreMode: exact-restore }

    P2 { perturbationId: "drive.nudge.down",
         targetPath: "causalConfig.drive",
         operation: bounded-add,   magnitude: -0.05,
         durationTransitions: 3,   restoreMode: exact-restore }

    P3 { perturbationId: "drive.scale.bounded",
         targetPath: "causalConfig.drive",
         operation: bounded-scale, magnitude: 1.02,
         durationTransitions: 3,   restoreMode: exact-restore }

Ограничения возмущений версии: не меняют state layout, не создают факты
или capabilities, не используют сеть, I/O и persistence, полностью
воспроизводимы, полностью откатываются sandbox-средой, не влияют на
production causal state. `bounded-toggle` в настоящей версии не
используется.

---

## 6. Инварианты

1. Источник предложения не выбирает окно, метрику, порог, возмущение и
   подмножество набора.
2. Набор возмущений конечен и выполняется полностью (детерминированный
   выбор подмножества в настоящей версии не применяется).
3. Любое значение §1–§5 меняется только новой версией документа.
4. Метрика, не пересчитанная оболочкой, не принимается ни в каком виде.
5. Устойчивость даёт право быть рассмотренным, не право на исполнение.
