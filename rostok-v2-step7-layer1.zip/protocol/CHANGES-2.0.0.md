# kernel-abi/2 — семантический diff draft → 2.0.0-rc2

П1. `moveSet` (графовый enum) → `moveClasses` (7 субстрат-агностичных
классов: modify-state, create/remove-entity, create/remove-relation,
activate-dof, extend-logical-state) + `moves` (конкретные ходы ядра:
id, class, atomic). Кросс-проверка: moveClasses ≡ множеству классов
moves в обе стороны. Слияние — отдельный атомарный move только при
семантической неэквивалентности композиции.

П2. `growthCapable: boolean` → `growthCapabilities` (вектор из пяти:
entityGrowth, relationGrowth, dofActivation, stateExtension,
capacityExtension) + производный `growthCapable` = OR. Четыре
возможности принудительно согласованы с классами ходов.

П3. `extend-state` разведён: activate-dof (ход ядра),
extend-logical-state (ход, если объявлен законом), extend-capacity —
НЕ класс хода (исключён из enum), только команда среды; никогда не
событие морфогенеза.

П4. Ось `dynamical` удалена (additionalProperties:false отклоняет её
как неизвестное поле — обход невозможен). Введены обязательные
`causal` × `numericClass`: causal+continuous → только f64;
causal+discrete → u8/u16/u32; noncausal — не входит в KernelState.

П5. KernelState: encoding const "base64", byteOrder const
"little-endian"; number-array запрещён (NaN payload, −0, IEEE-754).
Буфер самоописателен: + numericClass, + causal:true. + kernelName.

П6. checksum → CausalStateHash с собственным идентификатором
canonization: causal-state-hash/fnv1a64-le-v1. Полная канонизация в
§5a: length-prefixed UTF-8 строки, фиксированный порядок полей,
байтовая сортировка секций rng/scalars/cursors/buffers, u32-LE длины,
сырые биты f64 (±0 различимы, ±Inf допустимы, NaN → E_NAN_STATE если
не разрешён схемой ядра), пустой буфер — определённое поведение.
Эталонная реализация tools/causal-hash.mjs; закреплённый вектор
a7cdfd3b306c5a77 (fixtures/hash-vector.json). Кросс-проверка
kernel-state использует ту же реализацию — второй трактовки канона
не существует.

П7. dormant: `name`→`id` + `storage {buffer, componentOffset,
componentCount}`; кросс-проверки существования буфера и
offset+count ≤ components. coupling.channel → channelId "name@N".

П8. symmetries: свободные строки → {id (namespaced), version,
scope:"law", actionRef?}. Симметрии наблюдателя — только claims
второго яруса, в metadata запрещены.

Новые коды ошибок: E_NAN_STATE.

## rc2 → 2.0.0 (финальные правки эталона)

Ф1. NaN-скан переведён на DataView с явным little-endian чтением —
эталон не зависит от порядка байтов CPU, суффикс -le- честен на любой
платформе. Канонический поток не затронут.

Ф2. Канонические целые: tick и cursors — 0…MAX_SAFE_INTEGER (схема +
проверка эталона); состояние RNG — только канонические десятичные
строки ^(0|[1-9][0-9]*)$, двойственность 123/"123" запрещена схемой;
эталон бросает E_STATE_FORMAT при нарушении. Байтовый поток не
изменился: str(String(v)) для канонической строки байт-в-байт
совпадает с прежним представлением.

Ф3. Редакционно: «payload Infinity» → «канонические IEEE-754
представления ±Infinity».

Решение по causal-байту в потоке: оставлен (вердикт ревизора) — хэш
описывает и семантическую классификацию буфера; канон переживёт
будущее ослабление схемы без смены идентификатора.

Контроль: закреплённый вектор a7cdfd3b306c5a77 НЕ изменился после
правок — подтверждение, что канонический поток не затронут.
Прогон: 40/40. Зафиксировано: kernel-abi/2.0.0,
causal-state-hash/fnv1a64-le-v1.


## 2.0.0 → 2.1.0 (аддитивно, по приёмке шага 1)

Р1. KernelMetadata.deadRegions (необязательное поле): декларация
мёртвых ролевых областей kind=overwrite-before-read с курсором роли.
Кросс-проверка: buffers области существуют.
Р2. §5a: нормативная семантика хэша — RawCausalRecordHash; равенство
достаточно для равенства состояния; неравенство при deadRegions не
означает различия будущего. Идентификатор канонизации не изменён.
Р3. reference-relaxation-kernel: hashFn — замороженная зависимость
конструктора; emitChecksum=true без hashFn → E_CONFIG при initialize;
скрытый attachHashFn удалён. restore — exact-валидация всех
нормативных полей (abiVersion, kernelName, kernelVersion, дескрипторы
каждого буфера: dtype/numericClass/causal/encoding/byteOrder/length,
точный состав буферов) с негативными тестами на подмену каждого поля.


## Приёмка шага 2 → долги перед шагом 3

Т1 (отложено до первого реального ядра, помечено в коде):
snapshot-путь через checkpoint/base64 — reference-only; норматив для
реальных ядер — kernel-owned view encoder (read-only accessor + viewId
→ прямая запись в target, одна копия, ноль base64/аллокаций).
Т2 (закрыто): ownership отделён от декодирования — ViewRegistry;
SnapshotPool не знает физический смысл нагрузки; handle.view(viewId).
Т3 (закрыто): доставка снимков аварийно изолирована — ObserverRunner
с try/finally-возвратом; ошибка callback не покидает message handler.
Т4 (закрыто): жизненный цикл пула ACTIVE→DISPOSED; leaked handles
учитываются; release после аварии хоста/dispose закрывает handle
локально (E_HOST_FAILURE не теряет буферы в HELD навсегда); новые
receive/take после завершения → E_POOL_DISPOSED.


## Приёмка шага 3 → поправки O1/2/3/4 (аддитивно к схемам)

O1 (закон): кодек возвращает read-only accessor (length + геттеры) —
массивы и буфер недостижимы для анализатора; мутация входа соседа
невозможна физически. Негативный тест: mutator до/после series-stats.
Схемы: event.provenance.configHash и protocol.detectors[].configHash —
необязательные поля (16 hex). Граница публикации: claim/failure —
замороженные значения, провенанс из снимка конфигурации в момент
регистрации. Observer checkpoint: observerStateFormat + parameters +
configHash, restore exact → E_STATE_FORMAT. Бинарное кодирование
наблюдателей — средонезависимый lib/bytes (без Buffer в научных
модулях). Численная политика series-stats: negVarClampEps —
версионированный параметр, молчаливого clamp нет.

## Приёмка шага 4 → пять законов архива

П1. Закон ArchiveValue (archive-canon/json-v1): только null/boolean/
string/конечные числа/массивы/простые объекты; NaN, ±Inf, undefined,
функции, Symbol, BigInt, циклы, Date/Map/Set/toJSON, сырые TypedArray →
E_ARCHIVE_VALUE. −0 СОХРАНЯЕТСЯ (канон эмитит "-0"; JSON.parse
возвращает −0). Бинарные данные — только нормативным дескриптором.
Ключи — по байтам UTF-8. toValue (JSON-раундтрип) изгнан из архивного
пути и границы публикации.
П2. contentHash = SHA-256 канонических байтов
(archive-content/sha256-json-v1, вектор FIPS в гейте); идемпотентность —
сравнением канонических байтов в драйвере, не хэшем. FNV — только
диагностическая подпись и CausalStateHash траектории.
П3. Журнал команд — причинный, fail-closed: запись подтверждена → только
затем применение; недоступный журнал ⇒ E_COMMAND_JOURNAL, команда не
применяется. Связка command → command-result (applied/rejected/failed).
Наблюдательные записи остаются fail-open (infra-failure, кольцо+счётчик).
П4. Контракт драйвера: атомарный putIfAbsent(record, canonical) →
INSERTED | IDEMPOTENT | CONFLICT; append-only гарантирует драйвер.
Конкурентный тест: 50 гонок одного id → ровно одна запись.
П5. Машина состояний CREATED→OPEN→FINALIZED→CLOSED; после finalize
причинные записи → E_ARCHIVE_STATE, post-analysis — revision с
parentRunIdentityHash. Три идентичности: documentHash /
experimentIdentityHash (семантическая проекция EXPERIMENT_IDENTITY_FIELDS,
без id/createdAt/environment) / runIdentityHash (+ причинный журнал
команд и их результаты). Схемы: configHash → 64 hex (SHA-256).
Стабильный eventId наблюдательных записей — из провенанса
(detectorId+configHash+snapshotTick): повторная доставка идемпотентна.

## Приёмка шага 4-финал → края К1–К4 (закрыты)

К1. openExperiment транзакционен: OPEN присваивается только после
подтверждённой записи протокола; отказ ⇒ CREATED, повторное открытие
допустимо (fail-closed старт).
К2. Причинный журнал команд сериализован собственной FIFO-очередью;
commandSeq монотонен и не откатывается: отказ = честный пропуск,
переиспользование номера невозможно при любом порядке завершения.
К3. ArchiveValue: только собственные перечислимые data-properties со
строковыми ключами (Reflect.ownKeys + дескрипторы); symbol,
неперечислимое, getter/setter → E_ARCHIVE_VALUE; копия на
Object.create(null) — "__proto__" и прочие спец-имена суть обычные
данные. Массивы: посторонние свойства запрещены.
К4. Полный порядок ключей: сортировка по байтам UTF-8 канонически
экранированного JSON-представления ключа — непарные суррогаты
различимы, порядок сравнения совпадает с порядком эмиссии. Для
ASCII-ключей порядок не изменился; ранее опубликованных межмашинных
хэшей не существует, идентификатор archive-canon/json-v1 сохранён с
уточнённой нормой.
О5–О10 и границы 1–10 постановки — зафиксированы черновиком
protocol/journal-2tier-spec-draft.md как обязательства следующего шага.


## two-tier-journal/1 → 1.0.0 (финальная ревизия)

Ф1. SEALED разрешён при COMPLETED и ABORTED; для ABORTED+SEALED —
terminationReason, terminalTick, финальный checkpoint или явное
обоснование отсутствия. Ф2. «Принуждение схемой» разведено: локальная
схемная валидность + межзаписный JournalConsistencyValidator (семь
инвариантов с негативами в §11). Ф3. RecoveryEvidence =
PostAnalysisRevision.kind="recovery-evidence" с запретом менять прошлое.
Ф4. runIdentityClass: causal-confirmed | causal-indeterminate;
сравнения — только confirmed; хэш не изменён. Смежные обязательства
дополнены: execution-security п.11–17, kernel-feedback-gate — три
уровня калибровки + KernelAmendmentProposal.

## Шаг 5 — реализация two-tier-journal/1.0.0 (§11)

RunJournal (src/journal): транзакционное открытие; команды fail-closed
с FIFO и монотонным seq; машина исходов PENDING→терминал ровно один раз
(E_TRANSITION), APPLIED/REJECTED только с фактом ядра; journalStatus
отделён от исхода — отказ result-журнала даёт RESULT_MISSING и UNSEALED
при неизменном runIdentityHash (ЦТ1: hash 195cd390bc54… совпал у
здорового и раненого прогонов); OUTCOME_UNKNOWN ⇒ финализация только
ABORTED+UNSEALED, runIdentityClass=causal-indeterminate, compare()
отвергает (ЦТ2); Ф1: ABORTED+SEALED при полной атрибуции остановки,
E_SEAL_REQUIREMENTS без неё. Идентичность: experimentIdentityHash +
executionEnvironmentHash + причинный журнал (seq, body, tick, outcome,
resolvedTick, kernelFactId). JournalConsistencyValidator
(src/journal/consistency.mjs): семь инвариантов И1–И7 причинного
гиперграфа, 7/7 порч обнаруживаются. Manifest §7: проверяемые
диапазоны, четыре правила отклонения читателем, auditStatus
пересчитывается; repair В4 — только повторная выдача порождённого
факта, история repair в архиве, permanent не маскируется. Replay: три
раздельных порядка + командные цепочки по correlationId. Наблюдательный
ярус fail-open через infra. Гейт шага 5: 14/14.
Generic-архив шага 4 остаётся базой хранения; семантика эксперимента —
в RunJournal (задокументированное разделение, pre-freeze).

## Приёмка шага 5 → края Э1–Э5 + инженерные (закрыты)

Э1. JournalConsistencyValidator стоит на воротах герметизации: finalize
выполняет повторную схемную проверку всех записей + межзаписный
валидатор ДО вычисления статусов; нарушения ⇒ E_JOURNAL_INCONSISTENT
для нормальной финализации; аварийно допустим только ABORTED+UNSEALED
с приложенным списком нарушений. SEALED при противоречивом причинном
гиперграфе недостижим (тест с подложным фактом).
Э2. resolveCommand транзакционен: кандидат CommandResult строится и
валидируется ДО мутации памяти; E_SCHEMA оставляет команду PENDING,
корректный повтор допустим. Контракт для Runtime зафиксирован в коде:
если ядро уже физически применило воздействие, а корректный resolve
невозможен — Runtime обязан вызвать OUTCOME_UNKNOWN. RESULT_MISSING
возникает ТОЛЬКО при отказе записи подтверждённого исхода.
Э3. Ledger сохраняет семантику временного поля: requestedTick и
scheduledTick не схлопываются — одинаковое число при разных контрактах
даёт разные runIdentityHash.
Э4. verifyManifest доказывает ПОКРЫТИЕ: recorded∪missing = [start…HWM]
для плотных политик, recorded∩missing=∅, внутренние пересечения
списков — нарушение, from≤to, permanent/recoverable ⊆ missing и не
пересекаются, firstObservedSeq = min(recorded), неизвестная политика
отклоняется, плотная политика без HWM недоказуема; sparse требует
внешнего источника ожиданий. Подлог «recorded 0..10, HWM=100,
missing=[]» отвергается.
Э5. Стабильная идентичность ObserverFailure: id = producerInvocationId
+ failureStage + failureIndexWithinInvocation (новое обязательное поле
схемы); archiveSeq — только порядок приёма. Повторная доставка
идемпотентна; второй сбой invocation различим.
Инженерные: _runRef присваивается только после подтверждённой записи
протокола (полная транзакционность open); ReissueSource — объект
{reissue(seq)} со сверкой content identity против producer evidence
(noteProduced с хэшем): подмена при повторной выдаче ⇒ mismatch +
permanent, дыра не закрывается ложью; finalCheckpointRef при
ABORTED+SEALED верифицируется (существование, вид, запуск, тик =
terminalTick); recoverable/permanent в manifest — подмножества missing.
Гейт шага 5: 21/21. Эталоны неизменны: 20e11a6290f1c3bd,
4d036ba986b6d554, a7cdfd3b306c5a77.
Нормативная заметка к интеграции: fact.seq — глобальный producer
sequence запуска; локальная нумерация внутри StepReport-батча
запрещена (иначе — streamId по источнику/эпохе).
