# calibration-surface/1 — декларация калибруемой поверхности

Статус: ЗАФИКСИРОВАН. Нормативная зависимость `execution-security/1.0.0`
(SHA-256 `e2183492cb8ff692095438cb1803ff0b18ba688d4223349ddd26e3c7cbcb0e05`).
Настоящий документ определяет, что оболочка вообще имеет право изменять.
Состав поверхности immutable: изменение значения — калибровка, изменение
состава — новая версия настоящего документа.

Идентификация:

    calibrationSurfaceId: "calibration-surface/1"
    calibrationSurfaceVersion: "1.0.0"
    applicableKernelAbi: "kernel-abi/2.2.0"
    applicableProfile: "integration-relaxation/1.0.0"

`calibrationSurfaceHash` = SHA-256 канонического содержимого настоящего
документа; закрепляется в KernelMetadata. Несовпадение ⇒
`E_SURFACE_MISMATCH` до любого предложения.

---

## 1. Разграничение

Калибруемо только то, что меняет траекторию внутри фиксированного
множества допустимых переходов. Не калибруемо ничто, что расширяет само
множество: новый класс операции, канал записи, тип причинного факта,
источник энтропии, канал I/O, механизм памяти, ресурс, область
состояния (⇒ `E_CAPABILITY_ESCALATION` без анализа).

Дополнительная граница настоящей версии: параметры, влияющие на
**расход и нумерацию `fact.seq`**, не исполняются в runtime, поскольку
владение и монотонность `fact.seq` принадлежат immutable foundation.
Обратимость значения параметра не равна обратимости последствий для
причинной нумерации: возврат значения не возвращает израсходованные seq.

---

## 2. Реестр ключей

### 2.1. `drive`

    id:                 "drive"
    type:               f64
    domain:             [0.0, 4.0]            // конечное, без NaN/±Inf
    defaultValue:       1.0
    statePath:          "causalConfig.drive"
    mutability:         calibratable
    monotonicity:       reversible
    maxDelta:           0.25                  // на одно применение
    lifetimeBudget:     { value: 4, scope: run }
    cooldown:           { transitions: 16 }
    reversibility:      reversible
    applicationMode:    between-transitions

Обоснование класса: `drive` — множитель ограниченного шумового вклада
внутри уже разрешённой динамики. Не создаёт операций, каналов, типов
фактов и не влияет на нумерацию. Возврат прежнего значения полностью
восстанавливает конфигурацию без потери семантики ⇒ `reversible`,
runtime-исполнение разрешено.

### 2.2. `emitEvery`

    id:                 "emitEvery"
    type:               integer
    domain:             [1, 64]
    defaultValue:       1
    statePath:          "causalConfig.emitEvery"
    mutability:         declared-not-calibratable
    monotonicity:       irreversible-in-effect
    maxDelta:           n/a
    lifetimeBudget:     { value: 0, scope: run }
    cooldown:           n/a
    reversibility:      irreversible
    applicationMode:    forbidden-in-v1

Обоснование класса: `emitEvery` определяет, в какие такты порождаются
факты, то есть расход `nextFactSeq`. Значение обратимо, последствия для
причинной нумерации — нет. Runtime-применение запрещено ⇒
`E_IRREVERSIBLE_CALIBRATION_DISABLED`. Ключ объявлен явно, чтобы его
недоступность была нормой документа, а не умолчанием.

---

## 3. Инварианты поверхности

1. Ключ, отсутствующий в §2, ⇒ `E_CAPABILITY_ESCALATION`.
2. Значение вне `domain` или превышение `maxDelta` ⇒ отказ capability.
3. `lifetimeBudget.scope` обязателен; исчерпание бюджета ⇒ отказ.
4. `cooldown` считается в принятых переходах, не в wall-clock.
5. `applicationMode: forbidden-in-v1` ⇒ runtime-исполнение закрыто
   независимо от результатов остальных проверок.
6. Ключ, требующий нового state layout, буфера или иной семантики step,
   в настоящем документе не регистрируется.
7. Состав §2 неизменен внутри версии; добавление, удаление или смена
   класса ключа — новая версия документа и новый
   `calibrationSurfaceHash`.

---

## 4. Область v1

Единственный runtime-исполняемый ключ версии — `drive`. `emitEvery`
объявлен и закрыт. Расширение состава, изменение классов и появление
параметрических каналов новых типов — вне области; относится к
`kernel-feedback-gate/1`.
