# authority-registry-schema/1 — схема реестра полномочий

Статус: ЗАФИКСИРОВАН. Нормативная зависимость `execution-security/1.0.0`.
Документ определяет **структуру и правила** реестра доверия, но не
является действующим реестром: он не содержит и не может содержать
конкретных ключей. Действующий trust anchor — отдельный артефакт
развёртывания (§4).

Идентификация:

    authorityRegistrySchemaId: "authority-registry-schema/1"
    authorityRegistrySchemaVersion: "1.0.0"

Хэш настоящего документа постоянен и не зависит от развёртывания.

---

## 1. Запись ключа

    AuthorityKeyRecord {
      authorityId          // идентификатор субъекта, не ключ
      keyId
      algorithm            // "Ed25519" — единственный допустимый в v1
      publicKey            // 32 байта, каноническое кодирование
      status               // ACTIVE | SUSPENDED | REVOKED | RETIRED
      validFromReportSeq
      validUntilReportSeq  // null — без верхней границы
      allowedPolicyIds
    }

`algorithm`, отличный от `Ed25519` ⇒ `E_AUTHORIZATION_ALGORITHM`.
Подписывается ровно 32-байтовый `decisionHash`, не текст решения и не его
сериализация. Приватный ключ не хранится в репозитории, не передаётся
через `ProposalEnvelope`, недоступен ядру, observer и feedback-контуру.
Публичный ключ секретом не является и принадлежит артефакту развёртывания
(§4), а не настоящему документу.

---

## 2. Порядок проверки (нормативный)

    1. authorityRegistryId / authorityRegistryHash binding
    2. key lookup по (authorityId, keyId)
    3. key status и validity (validFrom/validUntil по reportSeq)
    4. policy scope (allowedPolicyIds ∩ authorityPolicyId)
    5. Ed25519 verification над 32-байтовым decisionHash
    6. decision field matching (§5.8 закона)

Пропуск или перестановка этапов запрещены. Отказы по реестру §7 закона:
`E_AUTHORITY_REGISTRY_MISMATCH`, `E_AUTHORITY_UNKNOWN`,
`E_AUTHORITY_KEY_STATUS`, `E_AUTHORITY_KEY_EXPIRED`,
`E_AUTHORITY_POLICY_SCOPE`, `E_AUTHORIZATION_ALGORITHM`,
`E_AUTHORIZATION_MISSING`, `E_AUTHORIZATION_INVALID`,
`E_AUTHORIZATION_POLICY`, `E_DECISION_MISMATCH`, `E_DECISION_EXPIRED`.

---

## 3. Изменение реестра

1. Не является калибровкой и не проходит через `CALIBRATION_PROPOSAL`.
2. Не инициируется ядром, observer или feedback-контуром.
3. Выполняется доверенной offline administrative operation.
4. Порождает новую версию **артефакта развёртывания** и новый
   `authorityRegistryHash`; хэш настоящей схемы при этом не меняется.
5. Не переопределяет задним числом валидность уже принятых решений.

Историческая проверка решения выполняется по версии реестра,
действовавшей в момент принятия `AdministrativeDecision` (по
`authorityRegistryHash` внутри решения), а не по текущему состоянию.
Отзыв ключа позже не делает ранее принятое решение недействительным и не
делает его непроверяемым.

---

## 4. Артефакт развёртывания (trust anchor)

    authority-registry-instance/<deployment-id> {
      deploymentId
      authorityRegistrySchemaId
      authorityRegistrySchemaHash
      parentPolicyId
      parentPolicyHash
      records: [ AuthorityKeyRecord, ... ]   // с реальными publicKey
      issuedAtReportSeq
      registryHash                            // SHA-256 канонического содержимого
    }

Правила:

1. Действующим реестром считается только экземпляр с непустым `records`
   и реальными `publicKey`. Документ с placeholder-значением реестром не
   является и не может быть закреплён как trust anchor.
2. `authorityRegistryHash`, закрепляемый в доверенной конфигурации shell
   и дублируемый в `AdministrativeDecision`, — это `registryHash`
   экземпляра, а не хэш настоящей схемы и не хэш политики.
3. Экземпляр обязан ссылаться на схему и политику по их хэшам;
   несовпадение ⇒ `E_AUTHORITY_REGISTRY_MISMATCH`.
4. Экземпляр может храниться в репозитории (публичный ключ секретом не
   является) либо в отдельном подписанном deployment manifest — выбор
   развёртывания, не закона.
5. Смена любого поля экземпляра — новый `registryHash` и новая версия
   экземпляра; частичная правка записи невозможна.

---

## 5. Инварианты

1. Ключи не принадлежат причинному контуру ни в каком режиме.
2. Источник предложения не выбирает `keyId`, `algorithm` и политику.
3. Схема, политика и экземпляр — три раздельно версионируемых артефакта
   с независимыми хэшами; подмена одного другим запрещена.
4. `validUntilReportSeq: null` означает отсутствие верхней границы, а не
   бессрочность вне статуса: `status` проверяется отдельно.
5. Unsigned actuator недостижим ни при какой политике.
