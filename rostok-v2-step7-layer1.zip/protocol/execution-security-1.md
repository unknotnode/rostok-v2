# execution-security/1.0.0 — нормативный закон

Статус: ЗАФИКСИРОВАН (принят ревизией draft1→draft4). Это единственный
нормативный источник реализации execution-security/1. Переписка и
`execution-security-1-obligations.md` — историческое обоснование, не
источник смысла. При расхождении нормативен настоящий документ.

Версия: `execution-security/1.0.0`. Криптографический примитив: SHA-256.
Подпись: Ed25519. Каноническое кодирование: `archive-canon/json-v1`.

Внешние ссылки (immutable, привязка id+hash из foundation/shell):
`calibration-surface/1`, `stability-profile/1`,
`authority-registry-schema/1`, `authority-policy/1`,
`authority-registry-instance/<deployment-id>` (артефакт развёртывания),
`evidence-merkle/1`, `runtime-integration/1.0.0`, `archive-canon/json-v1`.

---

## 1. Область и доверенная граница

execution-security/1 — классическая защита исполнительной оболочки. Она
не полагается на эмерджентный иммунитет причинного контура: заражённая
оболочка способна выдать подделку за норму, поэтому её защита не может
быть эмерджентной (Р23).

**Защищаемый периметр (execution shell, доверенный):** metadata gate,
staging boundary, immutable commit bundle, retention custody, commit
store, journal publication, repair authority, seal-verification,
CalibrationSurface enforcement, ProposalReplayRegistry, authority
registry, административная авторизация, actuator, calibration application
state machine.

**Причинный контур (потенциально эволюционирующий, недоверенный к
оболочке):** KernelState и разрешённые механизмы его развития. Производит
переходы и факты; передаёт оболочке строго типизированные предложения и
факты. НЕ может: записывать commit marker или CALIBRATION_APPLY, менять
evidence, расширять capabilities, менять policy, владеть ключами подписи,
выбирать policy evaluator, влиять на проверку собственного происхождения.

**Observer и будущий feedback-контур — снаружи доверенной границы**,
недоверенные даже в одном процессе. Могут вызвать отказ наблюдения или
предложить действие, но не могут изменить причинный факт, задним числом
создать commit, удалить обязательство, расширить набор разрешённых
операций или переписать evidence.

**Минимальная TCB (обязательства 1–10 из obligations):** kernel ABI,
валидатор, Worker bootstrap, KernelHost, командный журнал, канонизация,
хэш, release verifier; подписанный release manifest; воспроизводимые
сборки; запрет динамического исполнения (без eval/new Function, без кода
в протоколах/архивах/checkpoint/claims); изоляция процессов; узкий
command plane; capability ceiling; kernel lineage; Gate как единственный
интерфейс к калибруемой области; неизменяемость Gate.

---

## 2. Immutable foundation и calibration surface

**Immutable foundation** (меняется только явной сменой версии закона):
формат состояния, правила идентичности перехода, владение fact.seq
(seqScope=kernel-global), детерминированная семантика step, запрет
скрытого расширения пространства состояний, список классов операций,
правила commit/evidence/seal (runtime-integration/1.0.0), capability
model, закон происхождения новых возможностей, а также идентичность
предложения, replay-защита и validity (§4).

**Calibration surface** — только заранее объявленные параметры внутри уже
разрешённой динамики (документ `calibration-surface/1`).

**Критерий разграничения (норма):** изменение калибровки может менять
траекторию внутри фиксированного множества допустимых переходов, но не
расширять само множество. Способность создать новый класс операции, тип
причинной связи, источник энтропии, канал I/O или механизм памяти — не
калибровка, а изменение закона.

KernelMetadata несёт только неизменяемую ссылку `calibrationSurfaceId` +
`calibrationSurfaceHash`; состав surface в metadata не дублируется.
Изменение значения — калибровка; изменение состава surface — новая
версия профиля (`calibrationSurfaceHash` обязан совпасть с документом,
иначе `E_SURFACE_MISMATCH` до любого предложения).

### 2.1. CalibrationSurface entry

Каждый калибруемый ключ:

    id
    type
    domain                       // допустимое множество/диапазон значений
    defaultValue | initialBinding
    statePath | configPath       // конкретное место в causalConfig
    mutability
    monotonicity                 // reversible | monotonic | irreversible
    maxDelta
    lifetimeBudget               // {value, scope: run|epoch|profile-version|source-node}
    cooldown
    reversibility                // reversible | monotonic | irreversible
    applicationMode              // between-transitions | requires-reinitialize
                                 //  | requires-new-epoch | forbidden-in-v1

`statePath` обязателен: оболочка проверяет конкретное место в causalConfig,
не абстрактный параметр. `lifetimeBudget.scope` обязателен. Ключ,
изменение которого требует нового state layout, буфера или иной семантики
step, НЕ регистрируется как обычная calibration entry.

**Класс исполнения в v1 (по reversibility):**
- `reversible` — runtime execution разрешён;
- `monotonic` — runtime denied ⇒ `E_MONOTONIC_CALIBRATION_DISABLED`
  (только offline amendment / поздняя версия закона);
- `irreversible` — runtime denied ⇒ `E_IRREVERSIBLE_CALIBRATION_DISABLED`
  (только offline / новая версия профиля).

Профиль v1 НЕ переопределяет этот запрет. monotonicity/reversibility
остаются классификационными полями, но не открывают runtime actuator.
execution-security/1.0.0 исполняет только полностью обратимые изменения.

Явно вне surface (⇒ `E_CAPABILITY_ESCALATION` без дальнейшего анализа):
новый класс операции, канал записи, тип причинного факта, источник
энтропии, канал I/O, механизм памяти, ресурс, область состояния.

---

## 3. Нормативные структуры

### 3.1. ProposalEnvelope

    sourceNodeId
    sourceStateHash
    sourceEpoch
    proposalType                 // v1: только CALIBRATION_PROPOSAL
    requestedCapability          // ссылка на CalibrationSurface entry id
    boundedParameters            // {parameterId, proposedValue} в пределах domain/maxDelta
    evidenceWindow               // причинное окно (reportSeq/factSeq)
    supportSet                   // массив SupportAttestation (§3.2)
    supportRoot                  // commitment над supportSet
    stabilityEvidenceHash        // вычислен shell по evidence, НЕ источником
    causalConfigHash
    calibrationSurfaceId
    calibrationSurfaceHash
    parentCommitRefs             // ссылки на принятые STEP_COMMIT
    nonce
    validFromReportSeq
    validUntilReportSeq
    proposalHash                 // §4.1

Неизвестные поля запрещены. proposalType вне {CALIBRATION_PROPOSAL} или
requestedCapability, вводящий новую способность ⇒ `E_CAPABILITY_ESCALATION`.

### 3.2. SupportAttestation

    supporterNodeId
    supporterStateHash
    supporterEpoch
    parentCommitRef
    evidenceWindow { firstReportSeq, lastReportSeq, firstFactSeq, lastFactSeq }
    derivationRoot               // evidence-merkle/1 (§4.2)
    supportClaimHash

Сопровождается `EvidenceDerivationBundle { derivationRoot,
evidenceLeaves | evidenceLeafRefs, inclusionProofs }`. Простое «я
поддерживаю» без derivationRoot не принимается.

### 3.3. EvidenceLeaf (evidence-merkle/1)

    commitMarkerHash
    reportSeq
    factSeq
    factHash
    relationRole

Листья ссылаются только на принятые причинные записи; сортируются
канонически (§4.2); не содержат observer-only данных; не включают само
предложение или производные от него аттестации; ограничены объявленным
evidenceWindow.

### 3.4. AdministrativeDecision

    decisionVersion
    proposalHash
    decision                     // APPROVE | DENY
    calibrationSurfaceId
    calibrationSurfaceHash
    parameterId
    expectedPreviousValue
    approvedNextValue
    approvedBudgetDebit          // верхний одобренный предел
    causalConfigHashBefore
    applicationMode
    validFromReportSeq
    validUntilReportSeq
    authorityPolicyId
    authorityRegistryId
    authorityRegistryHash
    decisionNonce

    decisionHash = contentHash(canonicalAdministrativeDecision без decisionHash)

Подписывается ровно 32-байтовый decisionHash (не JSON-текст, не
сериализация среды, не hex-строка).

### 3.5. Authorization

    authorityId
    keyId
    signatureAlgorithm           // v1: "Ed25519"
    decisionHash
    signature

`actuatorAuthorityId` — идентификатор доверенного субъекта/политики, не
ключ. `authorizationRefs` — ссылки на проверенные Authorization; их
количество и допустимые сочетания задаёт `authorityPolicyId`. Reversible
v1 — одна доверенная подпись; профиль может усилить до M-of-N, но не
разрешить unsigned actuator.

### 3.6. AuthorityKeyRecord (authority-registry-schema/1)

    authorityId
    keyId
    algorithm                    // Ed25519
    publicKey
    status                       // ACTIVE | SUSPENDED | REVOKED | RETIRED
    validFromReportSeq
    validUntilReportSeq
    allowedPolicyIds

Реестр доверия разделён на три раздельно версионируемых артефакта:
`authority-registry-schema/1` (структура записи и порядок проверки),
`authority-policy/1` (сколько и чьих подписей требуется) и
`authority-registry-instance/<deployment-id>` (действующий trust anchor с
реальными `publicKey`). `authorityRegistryHash`, закрепляемый в доверенной
конфигурации shell до открытия run и дублируемый в
`AdministrativeDecision`, — это `registryHash` **экземпляра**, не хэш
схемы и не хэш политики; подмена одного другим запрещена. Документ с
placeholder-значением `publicKey` действующим реестром не является.
Изменение реестра — не калибровка, только доверенная offline-операция,
новая версия экземпляра; не переопределяет задним числом валидность
принятых решений. Историческая проверка — по версии реестра на момент
AdministrativeDecision (`authorityRegistryHash` в решении).

### 3.7. CALIBRATION_APPLY

    calibrationApplyVersion
    proposalHash
    decisionHash
    calibrationSurfaceId
    calibrationSurfaceHash
    authorityPolicyId
    authorityRegistryHash
    parameterId
    previousValue
    nextValue
    budgetDebit                  // == computed == approved (§5)
    actuatorAuthorityId
    authorizationRefs
    applicationMode
    effectiveReportSeq
    causalConfigHashBefore
    causalConfigHashAfter
    preApplicationCheckpointHash

    calibrationApplyHash = contentHash(canonicalCalibrationApply без calibrationApplyHash)

Создаётся и верифицируется execution shell, НЕ ядром; после принятия —
часть нормативной причинной эвиденции. Неизвестные поля запрещены.
calibrationApplyHash вычисляется до входа в CALIBRATION_BINDING_PENDING и
далее неизменен.

### 3.8. StabilityProfile (stability-profile/1)

    stabilityProfileId
    stabilityProfileVersion
    applicableKernelAbi
    applicableCalibrationSurfaceId
    minimumWindowTransitions
    minimumIdentityPersistenceTransitions
    perturbationSet              // массив PerturbationCase
    metricDefinitions
    acceptanceThresholds
    evidenceWindowRules
    shellRecomputationRules

    PerturbationCase { perturbationId, targetPath, operation, magnitude,
                       durationTransitions, restoreMode }
    operation ∈ { bounded-add, bounded-scale, bounded-toggle }

Foundation несёт `stabilityProfileId`, `stabilityProfileHash`. Источник
предложения НЕ выбирает окно, метрику, порог или perturbation. Все
метрики пересчитывает shell по committed records. Нижний предел закона:
minimumWindowTransitions ≥ 2, minimumIdentityPersistenceTransitions ≥ 2,
perturbationSet.length ≥ 1, metricDefinitions.length ≥ 1. Стартовый
эталон профиля для принятого Integration Profile: 3/3 (значение профиля,
не универсальный закон). Изменение любого параметра профиля — новая
версия, не калибровка.

---

## 4. Каноническое кодирование и hash commitments

Каноническое кодирование — `archive-canon/json-v1`: детерминированный
порядок полей, фиксированная ширина/диапазон чисел, без locale-зависимости,
без неоднозначности NaN/Infinity, без неизвестных полей. Второй
несовместимый формат не вводится.

### 4.1. proposalHash

    proposalHash = contentHash(canonicalProposalEnvelope без proposalHash)

Включает как минимум: sourceNodeId, sourceStateHash, sourceEpoch,
proposalType, requestedCapability, boundedParameters, evidenceWindow,
supportRoot, stabilityEvidenceHash, causalConfigHash, calibrationSurfaceId,
calibrationSurfaceHash, parentCommitRefs, nonce, validFromReportSeq,
validUntilReportSeq. Mutable/diagnostic данные в commitment не входят.
Сверка proposalHash — до любых содержательных проверок.

### 4.2. evidence-merkle/1

    leafHash = SHA256("execution-security/evidence-merkle/1/leaf" || canonicalEncode(EvidenceLeaf))
    nodeHash = SHA256("execution-security/evidence-merkle/1/node" || leftHash || rightHash)
    emptyRoot = SHA256("execution-security/evidence-merkle/1/empty")

Domain separation обязателен. Канонический порядок листьев —
лексикографически по каноническому бинарному представлению полей
(commitMarkerHash, reportSeq, factSeq, factHash, relationRole), не по
locale/string сравнению среды. Дубликаты листьев отклоняются (не
удаляются молча). Нечётный уровень: последняя вершина promoted unchanged
на следующий уровень. Один STEP_COMMIT допустим только как одноэлементное
дерево, не как альтернативный формат. `derivationAlgorithm:
"evidence-merkle/1"`, `derivationRoot: <32-byte SHA-256>`; неизвестный
алгоритм ⇒ `E_DERIVATION_ALGORITHM`. SHA-256 и правила дерева профилем не
заменяются.

---

## 5. Порядок проверок (конвейер)

Строго последовательный. Ни один этап не пропускает следующий (структурно,
не только тестово). Сертификат происхождения даёт только право попасть в
очередь policy evaluation, не право на исполнение (устойчивый ≠ полезный).

    Proposal
      → proposalHash verification (§4.1)                 [до содержательных проверок]
      → replay control (§5.5)
      → Origin verification (§5.1)
      → Stability verification (§5.2, shell-side)
      → Support verification (§5.3)
      → Capability verification (§5.4)
      → Policy evaluation
      → Sandbox / симуляция (§5.6)
      → Budget evaluation (§5.7)
      → Administrative authorization (§5.8)
      → Calibration application transaction (§6)

### 5.1. Origin verification
sourceStateHash и parentCommitRefs ссылаются на реально принятые
STEP_COMMIT-маркеры (commit-backed). Предложение выводится из
зафиксированной причинной истории. Единственный недоказуемый источник
причинного утверждения ⇒ отказ. observer-only опора недопустима (§5.9).
Отказ: `E_ORIGIN_NOT_COMMIT_BACKED`, `E_ORIGIN_OBSERVER_ONLY`.

### 5.2. Stability verification (shell-side)
Оболочка пересчитывает stabilityEvidenceHash по committed records и
stability-profile/1: минимальное окно, сохранение идентичности через
несколько переходов, ограниченная чувствительность к bounded
perturbations. Источник не выбирает критерий. stabilityMetrics,
поданные источником вместо shell-пересчёта ⇒ `E_STABILITY_METRIC_SOURCE`.
Окно/устойчивость ниже требований ⇒ `E_STABILITY_INSUFFICIENT`.
Профиль не совпал с ссылкой ⇒ `E_STABILITY_PROFILE_MISMATCH`.

### 5.3. Support verification (§4a кворум + графовая независимость)
supportQuorum ≥ 2, evidenceWindows ≥ 2, запрет self-support cycles,
обязательная causal independence; профиль только усиливает. derivationRoot
каждой аттестации проверяется через evidence-merkle/1 + inclusion proofs.
Два узла независимы только при одновременном: supporterNodeId различны;
разные derivationRoot; ни одна аттестация не использует предложение или
аттестацию другой как основание; evidence windows не совпадают и не
полный дубликат; в подграфе нет пути A→B, B→A и цикла через sourceNodeId;
кворум не сводится к одной общей непосредственной причине. Консервативный
критерий v1: поддержка НЕ независима, если все аттестации имеют один
непосредственный causal ancestor в пределах проверяемого окна. Разные
derivationRoot сами по себе независимости не доказывают. Межэпоховая
поддержка без migration-proof отклоняется (v1: одна совместимая
foundation/surface-версия). Отказы: `E_SUPPORT_QUORUM`, `E_SUPPORT_CYCLE`,
`E_SUPPORT_NOT_INDEPENDENT`, `E_SUPPORT_PROVENANCE`, `E_SUPPORT_EPOCH`,
`E_DERIVATION_ROOT`, `E_DERIVATION_PROOF`, `E_DERIVATION_WINDOW`,
`E_DERIVATION_SELF_REFERENCE`.

### 5.4. Capability verification
Только заранее разрешённая операция в пределах surface. Повторная
проверка type/domain/maxDelta/lifetimeBudget/cooldown/конфликта и
неизменности собственных правил проверки. Класс исполнения (§2.1):
monotonic/irreversible ⇒ соответствующий disabled-код. Выход за surface ⇒
`E_CAPABILITY_ESCALATION`.

### 5.5. Replay control
`ProposalReplayRegistry` (execution shell) хранит: использованные
proposalHash; (sourceNodeId, nonce); финальный статус; ссылку на
административное решение; ссылку на causal application record. Повтор того
же proposalHash идемпотентен (не создаёт actuator, не списывает бюджет, не
проходит pipeline заново); v1 отклоняет до policy evaluation ⇒
`E_PROPOSAL_REPLAY`. (sourceNodeId, nonce) с иным содержимым ⇒
`E_PROPOSAL_NONCE_CONFLICT`. Срок — причинный: validFromReportSeq..
validUntilReportSeq; вне окна ⇒ `E_DECISION_EXPIRED` (для решения) или
отказ предложения. proposalHash с неизвестным полем ⇒ `E_PROPOSAL_HASH`.

### 5.6. Sandbox
Над отделённой копией состояния. Ни один sandbox-run не потребляет
production fact.seq, не публикует факты в production journal, не меняет
retention custody, replay registry или calibration budget, не создаёт
STEP_COMMIT. Perturbations полностью воспроизводимы и откатываемы.

### 5.7. Budget evaluation
Оболочка независимо вычисляет debit; approvedBudgetDebit — верхний предел,
не источник истины. Норма v1 (строгое равенство): computedBudgetDebit ==
approvedBudgetDebit; иначе `E_BUDGET_MISMATCH`. Списание — атомарно с
принятием CALIBRATION_APPLY, один раз на APPROVE.

### 5.8. Administrative authorization (порядок)
    authorityRegistryHash binding
      → key lookup
      → key status/validity
      → policy scope
      → Ed25519 signature verification (над 32-байтовым decisionHash)
      → decision field matching
Несовпадение proposalHash/parameterId/expectedPreviousValue/
approvedNextValue/approvedBudgetDebit/causalConfigHashBefore/
calibrationSurfaceHash/validity ⇒ блок. DENY завершает pipeline (запрещены
CALIBRATION_APPLY, остановка admission, budget, actuator ⇒
`E_DECISION_NOT_APPROVED`). decisionNonce replay: (scope, nonce)→decisionHash;
повтор с иным решением ⇒ `E_DECISION_NONCE_CONFLICT`; повторное применение
одного APPROVE ⇒ `E_DECISION_REPLAY`. Отказы: `E_AUTHORIZATION_MISSING`,
`E_AUTHORIZATION_INVALID`, `E_AUTHORIZATION_POLICY`,
`E_AUTHORIZATION_ALGORITHM`, `E_DECISION_MISMATCH`, `E_DECISION_EXPIRED`,
`E_AUTHORITY_UNKNOWN`, `E_AUTHORITY_KEY_STATUS`, `E_AUTHORITY_KEY_EXPIRED`,
`E_AUTHORITY_POLICY_SCOPE`, `E_AUTHORITY_REGISTRY_MISMATCH`.

### 5.9. Observer-граница
Observer output — diagnostic или индекс для выбора commit-backed evidence
(«проверь окно X»), но не единственный элемент evidence, stability proof
или support proof. Все допускающие утверждения shell воспроизводимо
перестраивает из committed causal records (causal replay).

---

## 6. State machine применения

    NORMAL
      → CALIBRATION_APPLICATION
      → CALIBRATION_BINDING_PENDING
      → NORMAL

    CALIBRATION_APPLICATION      → CAUSAL_INDETERMINATE   (отказ/crash в окне)
    CALIBRATION_BINDING_PENDING  → CAUSAL_INDETERMINATE   (отказ/crash до binding-transition)

Из CAUSAL_INDETERMINATE автоматический возврат в NORMAL запрещён.

**Application-последовательность (fail-closed, без hot-patching):**
stop tick admission → verify AdministrativeDecision → capture
pre-application checkpoint (preApplicationCheckpointHash) → apply
reversible value → compute+verify causalConfigHashAfter → create+accept
CALIBRATION_APPLY → bind к первому переходу → resume admission.

**CALIBRATION_BINDING_PENDING:** допустима ровно одна содержательная
операция — подготовка и принятие ожидаемого transition с нужным
reportSeq, causalConfigHash и calibrationApplyHash. Запрещены: seal, новая
калибровка, смена конфигурации, альтернативный tick, observer-triggered
actuator, пропуск ожидаемого reportSeq. Диагностическое чтение frozen
snapshots разрешено (не меняет состояние). Любой mismatch ⇒ fail-closed.

**Связь с первым переходом:** первый TransitionEvidence под новой
конфигурацией несёт `calibrationApplyHash`. Инварианты:
nextTransition.reportSeq == CALIBRATION_APPLY.effectiveReportSeq;
nextTransition.causalConfigHash == CALIBRATION_APPLY.causalConfigHashAfter;
nextTransition.calibrationApplyHash == calibrationApplyHash. До принятия
этого перехода следующая калибровка запрещена. causalConfigHashBefore не
дублируется в каждом evidence (закреплён в CALIBRATION_APPLY). Неверная
или отсутствующая привязка ⇒ `E_CALIBRATION_BINDING`, Runtime fail-closed.

---

## 7. Реестр кодов отказа (единый, без дублей)

    E_SURFACE_MISMATCH
    E_CAPABILITY_ESCALATION
    E_MONOTONIC_CALIBRATION_DISABLED
    E_IRREVERSIBLE_CALIBRATION_DISABLED
    E_PROPOSAL_HASH
    E_PROPOSAL_REPLAY
    E_PROPOSAL_NONCE_CONFLICT
    E_ORIGIN_NOT_COMMIT_BACKED
    E_ORIGIN_OBSERVER_ONLY
    E_STABILITY_METRIC_SOURCE
    E_STABILITY_INSUFFICIENT
    E_STABILITY_PROFILE_MISMATCH
    E_SUPPORT_QUORUM
    E_SUPPORT_CYCLE
    E_SUPPORT_NOT_INDEPENDENT
    E_SUPPORT_PROVENANCE
    E_SUPPORT_EPOCH
    E_DERIVATION_ROOT
    E_DERIVATION_PROOF
    E_DERIVATION_WINDOW
    E_DERIVATION_SELF_REFERENCE
    E_DERIVATION_ALGORITHM
    E_AUTHORIZATION_MISSING
    E_AUTHORIZATION_INVALID
    E_AUTHORIZATION_POLICY
    E_AUTHORIZATION_ALGORITHM
    E_DECISION_MISMATCH
    E_DECISION_EXPIRED
    E_DECISION_NOT_APPROVED
    E_DECISION_NONCE_CONFLICT
    E_DECISION_REPLAY
    E_AUTHORITY_UNKNOWN
    E_AUTHORITY_KEY_STATUS
    E_AUTHORITY_KEY_EXPIRED
    E_AUTHORITY_POLICY_SCOPE
    E_AUTHORITY_REGISTRY_MISMATCH
    E_BUDGET_MISMATCH
    E_CALIBRATION_BINDING

---

## 8. Инварианты

1. Только CALIBRATION_PROPOSAL; новые capabilities/типы фактов/буферы/
   связи/правила перехода ⇒ E_CAPABILITY_ESCALATION без анализа.
2. runtime исполняет только reversible; monotonic/irreversible denied.
3. Причинный контур не пишет CALIBRATION_APPLY, не владеет ключами, не
   выбирает policy evaluator, не влияет на проверку происхождения.
4. computedBudgetDebit == approvedBudgetDebit; один APPROVE ⇒ ≤1
   применение и ≤1 списание бюджета; DENY не открывает application.
5. Конвейер строго последователен; перескок структурно невозможен.
6. Сертификат происхождения даёт право быть рассмотренным, не право на
   исполнение.
7. Каноническое кодирование инвариантно к порядку полей: один
   семантический объект ⇒ один hash.
8. Применение — часть causal evidence chain через CALIBRATION_APPLY и
   calibrationApplyHash первого перехода; иначе commit-gap запрещён.
9. crash в application/binding window ⇒ CAUSAL_INDETERMINATE, без
   автоматического продолжения (Д-исп-3).
10. Все допускающие утверждения перестроены shell из committed records;
    observer — не единственный источник.

---

## 9. Gate / conformance cases

- proposalHash с неизвестным полем ⇒ E_PROPOSAL_HASH; сверка до проверок.
- каноническое кодирование при ином порядке полей ⇒ тот же hash.
- предложение вне surface ⇒ E_CAPABILITY_ESCALATION без анализа.
- monotonic ⇒ E_MONOTONIC_CALIBRATION_DISABLED; irreversible ⇒
  E_IRREVERSIBLE_CALIBRATION_DISABLED.
- calibrationSurfaceHash≠документ ⇒ E_SURFACE_MISMATCH.
- provenance на несуществующий STEP_COMMIT ⇒ E_ORIGIN_NOT_COMMIT_BACKED.
- observer-only опора ⇒ E_ORIGIN_OBSERVER_ONLY.
- stabilityMetrics от источника вместо shell ⇒ E_STABILITY_METRIC_SOURCE.
- окно/устойчивость ниже профиля ⇒ E_STABILITY_INSUFFICIENT.
- supportSet<2 или окон<2 ⇒ E_SUPPORT_QUORUM.
- self-support cycle ⇒ E_SUPPORT_CYCLE.
- два узла с общим непосредственным ancestor ⇒ E_SUPPORT_NOT_INDEPENDENT
  (несмотря на разные derivationRoot).
- аттестация без derivationRoot / неверный inclusion proof ⇒
  E_SUPPORT_PROVENANCE / E_DERIVATION_PROOF.
- лист вне окна ⇒ E_DERIVATION_WINDOW; лист на предложение/его аттестацию
  ⇒ E_DERIVATION_SELF_REFERENCE; дубликат листа ⇒ отказ дерева;
  неизвестный алгоритм ⇒ E_DERIVATION_ALGORITHM.
- межэпоховая поддержка ⇒ E_SUPPORT_EPOCH.
- повтор proposalHash ⇒ идемпотентно/E_PROPOSAL_REPLAY;
  (nodeId,nonce) с иным телом ⇒ E_PROPOSAL_NONCE_CONFLICT.
- unsigned actuator ⇒ E_AUTHORIZATION_MISSING; подпись не над decisionHash
  ⇒ E_AUTHORIZATION_INVALID; signatureAlgorithm≠Ed25519 ⇒
  E_AUTHORIZATION_ALGORITHM; refs вне policy ⇒ E_AUTHORIZATION_POLICY.
- authorityRegistryHash mismatch ⇒ отклонение ДО key lookup/подписи
  (E_AUTHORITY_REGISTRY_MISMATCH).
- ключ unknown ⇒ E_AUTHORITY_UNKNOWN; suspended/revoked ⇒
  E_AUTHORITY_KEY_STATUS; expired ⇒ E_AUTHORITY_KEY_EXPIRED; вне scope ⇒
  E_AUTHORITY_POLICY_SCOPE.
- unknown-поле в AdministrativeDecision ⇒ отклонение до подписи.
- расхождение полей решения и предложения ⇒ E_DECISION_MISMATCH; вне
  validity ⇒ E_DECISION_EXPIRED.
- DENY с попыткой application ⇒ E_DECISION_NOT_APPROVED.
- (scope,nonce) с иным решением ⇒ E_DECISION_NONCE_CONFLICT; второй
  application по одному APPROVE ⇒ E_DECISION_REPLAY.
- computedBudgetDebit≠approvedBudgetDebit ⇒ E_BUDGET_MISMATCH.
- sandbox, произведший production-факт или потребивший fact.seq ⇒ провал.
- calibrationApplyHash с неизвестным полем ⇒ отказ; отсутствие
  preApplicationCheckpointHash ⇒ отказ.
- CALIBRATION_BINDING_PENDING + seal ⇒ fail-closed; + пропуск reportSeq ⇒
  E_CALIBRATION_BINDING; + observer-действие ⇒ fail-closed.
- первый transition без корректного calibrationApplyHash /
  effectiveReportSeq / causalConfigHashAfter ⇒ E_CALIBRATION_BINDING.
- crash в application/binding window ⇒ CAUSAL_INDETERMINATE.
- один APPROVE, поданный дважды ⇒ ровно одно CALIBRATION_APPLY и одно
  списание бюджета.
- CALIBRATION_APPLY, авторизованный/подписанный источником вместо shell ⇒
  отказ.

---

## 10. Ограничения v1 и out-of-scope

- Только CALIBRATION_PROPOSAL для зарегистрированных ключей.
- Только reversible runtime-калибровка.
- Функциональная полезность и рождение новых способностей — закрыты до
  kernel-feedback-gate/1.
- Durable WAL, автоматическое crash recovery, application replay, budget
  reconstruction после crash — вне области (Т5/Т6). Документ ничего этого
  не обещает. preApplicationCheckpointHash — только точка операторской
  процедуры, не durable recovery.
- Algorithm agility (подпись, Merkle) — только новой версией профиля.
- kernel-feedback-gate/1: три уровня калибровки; расширяющий закон
  уровень → подписанный KernelAmendmentProposal + версия закона. Не
  смешивать с execution-security/1.

---

## 11. Порядок реализации (нормативный)

1. Чистые канонические структуры и валидаторы (§3), canonicalEncode =
   archive-canon/json-v1.
2. Provenance / support / replay (§4.2, §5.1, §5.3, §5.5).
3. Authorization (§3.5–3.6, §5.8).
4. State machine применения (§6).
5. Интеграция с Runtime commit bundle (§6, calibrationApplyHash).

Не начинать с actuator или криптографии в отрыве от структур и
валидаторов. После любой правки — полный регресс семи гейтов + сверка
эталонов; гейт execution-security добавляется восьмым.
