# authority-policy/1 — политики административной авторизации

Статус: ЗАФИКСИРОВАН. Нормативная зависимость `execution-security/1.0.0`,
структура записей — `authority-registry-schema/1`. Документ определяет,
сколько и чьих подписей требуется для применения калибровки. Ключей не
содержит.

Идентификация:

    authorityPolicyDocumentId: "authority-policy/1"
    authorityPolicyDocumentVersion: "1.0.0"

Хэш постоянен и не зависит от развёртывания. Экземпляр реестра
(`authority-registry-instance/<deployment-id>`) ссылается на него как
`parentPolicyHash`.

---

## 1. Структура политики

    AuthorityPolicy {
      authorityPolicyId
      requiredSignatures   // M
      eligibleAuthorities  // N субъектов, из которых набирается M
      appliesTo            // классы reversibility / applicationMode
    }

`requiredSignatures ≥ 1` всегда: unsigned actuator недостижим ни при
какой политике. Профиль развёртывания вправе усилить требование до
M-of-N, но не ослабить его.

---

## 2. Политики версии

    { authorityPolicyId: "policy.reversible.single",
      requiredSignatures: 1,
      eligibleAuthorities: ["authority.operator.primary"],
      appliesTo: { reversibility: ["reversible"],
                   applicationMode: ["between-transitions"] } }

Единственная политика версии. Она покрывает ровно тот класс, который v1
исполняет в runtime: полностью обратимые изменения между переходами.

Для классов `monotonic` и `irreversible` политика не определена
намеренно: их runtime-исполнение закрыто законом
(`E_MONOTONIC_CALIBRATION_DISABLED`,
`E_IRREVERSIBLE_CALIBRATION_DISABLED`), и наличие политики создавало бы
ложное впечатление достижимого пути.

---

## 3. Применение

1. `authorityPolicyId` из `AdministrativeDecision` разрешается по
   настоящему документу; неизвестный идентификатор ⇒
   `E_AUTHORIZATION_POLICY`.
2. Ключ, чей `allowedPolicyIds` не содержит применяемую политику ⇒
   `E_AUTHORITY_POLICY_SCOPE`.
3. Число проверенных `Authorization` меньше `requiredSignatures` ⇒
   `E_AUTHORIZATION_POLICY`; отсутствие подписи ⇒
   `E_AUTHORIZATION_MISSING`.
4. Класс параметра вне `appliesTo` ⇒ отказ до обращения к actuator.

---

## 4. Инварианты

1. Политика не выбирается источником предложения.
2. Политика не изменяется калибровкой; изменение — новая версия
   документа и новый хэш.
3. Ослабление `requiredSignatures` развёртыванием запрещено; допустимо
   только усиление.
4. Отсутствие политики для класса означает недостижимость класса, а не
   свободу выбора.
