# two-tier-journal/1 — Спецификация двухъярусного журнала

Статус: 1.0.0 — ЗАФИКСИРОВАНО (финальная ревизия, поправки Ф1–Ф4
внесены). Реализация — по §11. Изменение семантики = two-tier-journal/2.
Подчиняется kernel-abi/2.1.0, законам архива шага 4 (П1–П5, К1–К4).

## 0. Главный критерий

Лаборатория обязана однозначно различать: (1) что физически произошло;
(2) что наблюдатель заявил; (3) что архив сумел записать; (4) насколько
полна сохранившаяся летопись. Всякая конструкция проверяется этим.

## 1. Таксономия — семь схем + четыре зарезервированных типа

CausalFact, CommandRecord, CommandResult, ObserverClaim,
ObserverFailure, InfrastructureFailure, PostAnalysisRevision — семь
отдельных схем, additionalProperties:false, универсальных nullable-полей
не существует. Политики отказа: команды fail-closed; факты и
обязательные результаты → completeness/seal; наблюдательное — fail-open;
revision — fail-closed, run identity не меняет.

ЗАРЕЗЕРВИРОВАНО (§9): KernelCalibrationProposal,
OperatorCalibrationDecision, KernelCalibrationFact, KernelEpochBoundary.

## 2. Временные контракты и correlation envelope

envelope (у всех): correlationId, causationId?, archiveSeq (порядок
приёма, никогда идентичность), archivedAt? (annotation, вне identity и
вне нормативных порядков). Нормативных порядков три, раздельно:
причинный (causalTick, seq); эмиссии (producerInvocationId, emittedSeq);
приёма (archiveSeq).

- CausalFact: causalTick обязателен.
- CommandRecord: ровно один из requestedTick | scheduledTick.
- CommandResult: ровно один из appliedTick | resolvedTick.
- ObserverClaim: ровно одно из snapshotTick | snapshotRange; emittedSeq.
- ObserverFailure: собственный контракт (§6.2), НЕ наследует Claim.
- InfrastructureFailure: hostTick? | wallClock? | только archiveSeq.
- PostAnalysisRevision: analysisRevisionId + parentRunIdentityHash,
  причинного времени не имеет.

## 3. Команды: две оси и полная цепочка идентичности

```
commandOutcome (слово ядра, причинная семантика):
  PENDING → APPLIED | REJECTED | FAILED_BY_KERNEL | OUTCOME_UNKNOWN
journalStatus (судьба архивной записи):
  RECORDED → RESULT_RECORDED | RESULT_MISSING
```

**Цепочка принуждается схемами записей И межзаписным валидатором
согласованности (доп.5, Ф2).** Схема одной записи проверяет локальную
валидность (наличие commandId, causationId, тип); существование ссылок,
принадлежность одному запуску, соответствие исхода типу факта и
единственность терминального результата — междокументные инварианты
JournalConsistencyValidator (§11).
CommandRecord.commandId → CausalFact fact.command.apply|reject с тем же
commandId → CommandResult с тем же commandId и causationId = id факта.
APPLIED/REJECTED без соответствующего факта ядра невалидны:
CommandResult не имеет права объявить причинный исход сам.
FAILED_BY_KERNEL факта apply не имеет, но обязан иметь подтверждённую
хостом kernel error record. OUTCOME_UNKNOWN подтверждающего факта не
имеет — именно поэтому UNSEALED.

**Решение В1 (нормативно).** Авария хоста между отправкой и
подтверждением: commandOutcome = OUTCOME_UNKNOWN (терминально для
исходной записи запуска). Финализация такого запуска допустима ТОЛЬКО
как ABORTED + UNSEALED; COMPLETED запрещён — неизвестен сам факт
воздействия, честный runIdentityHash «как будто исход известен»
невозможен. runIdentityHash получает специальное представление
неизвестного исхода (literal "outcome-unknown" в записи команды) и —
нормативно, типом (Ф4) — runIdentityClass = "causal-indeterminate":
такой хэш идентифицирует архивную запись неопределённого исполнения, а
не физическую траекторию. Сравнительные научные операции по
runIdentityHash разрешены только между "causal-confirmed"; indeterminate
допускает хранение, расследование и revision, но не утверждение
воспроизводимости. Запуск сохраняется как аварийный научный артефакт. Позднее найденное свидетельство
исходный run не переписывает — только PostAnalysisRevision с
kind = "recovery-evidence" (Ф3, нормативный подтип): обязательны
parentRunIdentityHash, ссылка на исходную неопределённость
(commandId/уязвимую запись), источник свидетельства, метод проверки,
новое предполагаемое толкование; изменять исходные записи,
runSealStatus и auditStatus родителя ЗАПРЕЩЕНО — прошлое дополняется,
но не переписывается.

## 4. Три оси статуса запуска

```
runExecutionStatus: RUNNING | COMPLETED | ABORTED
runSealStatus:      OPEN | SEALED | UNSEALED
auditStatus:        COMPLETE | INCOMPLETE
```

SEALED разрешён при COMPLETED ИЛИ ABORTED (Ф1): оси независимы —
честно остановленный прогон с полностью известной историей не равен
повреждённому журналу. Требования SEALED: ни одного RESULT_MISSING,
OUTCOME_UNKNOWN или PENDING; для ABORTED+SEALED дополнительно
обязательны terminationReason, terminalTick и финальный checkpoint
остановки либо явное задокументированное обоснование его отсутствия.
UNSEALED терминален. auditStatus: записанное значение — заявление
писателя, читатель пересчитывает из manifest и ОТВЕРГАЕТ расхождение
(§7).

## 5. Идентичности и состав runIdentityHash (доп.6)

experimentIdentityHash — семантика постановки.
executionEnvironmentHash — runtime/платформа/движок/числ. политика/host.
runIdentityHash = H(exp, env, причинный журнал команд В ПРИЧИННОМ
ПОРЯДКЕ commandSeq): для каждой команды { commandSeq, commandId,
canonical body, requestedTick|scheduledTick, commandOutcome,
appliedTick|resolvedTick|null, kernelFactId|null }.
НЕ входят: journalStatus, archiveSeq, archivedAt, retries, ошибки
backend, repair-попытки, seal/audit. Один причинный прогон — одна
идентичность при любой судьбе backend.

runIdentityClass (Ф4): "causal-confirmed" — все исходы подтверждены
фактами ядра; "causal-indeterminate" — присутствует OUTCOME_UNKNOWN.
Класс — обязательный спутник хэша во всех записях результата и API
сравнения; сам хэш не меняется.

## 6. Идентичность эмиссии

### 6.1. producerInvocationId и окна (решение В2)

producerInvocationId = H(detectorId, detectorVersion, configHash,
subjectIdentity, analysisRevisionId); analysisRevisionId = "live" |
id ревизии; emissionIndexWithinInvocation — плотный с 0,
детерминированный, стабильный при повторной доставке.

windowIdentity (нормативно, состав — не только границы):
```
{ fromTick, toTick, snapshotCount, snapshotSeqsHash,
  selectionPolicyId, selectionPolicyVersion }
```
snapshotSeqsHash — по канонически отсортированному списку фактически
использованных snapshot identity; малые окна могут инлайнить
snapshotSeqs[], большие — hash + count + firstSeq + lastSeq, но content
identity зависит от ПОЛНОГО состава: одинаковые границы с разным
составом (drop/фильтрация/redelivery) — разные окна. Полный список при
необходимости аудита — в provenance/subject record.

### 6.2. ObserverFailure (решение В3)

Обязательны: producerInvocationId; failureStage ∈ { DECODE, OBSERVE,
EMIT, CHECKPOINT, RESTORE, INTERNAL }; detectorId/version/configHash;
errorCode + детерминированная категория. subjectIdentity — обязателен,
если субъект уже определён; snapshotTick/Range — опциональны (сбой до
получения снимка — норма, не дыра схемы); emittedSeq — только если
invocation началась. Stack trace — annotation, вне identity.

## 7. Completeness manifest — проверяемый объект (доп.7)

По каждому потоку:
```
{ streamId, producerId, expectedSeqPolicy, firstObservedSeq?,
  sourceHighWaterMark?, recordedSeqRanges[], missingSeqRanges[],
  duplicateCount, conflictCount, recoverableRanges[], permanentRanges[],
  evidenceSource, computedBy, computationVersion }
```
recordedCount выводится из мощности диапазонов, отдельного поля-числа,
которому нужно верить, не существует. Читатель ОТВЕРГАЕТ manifest, если:
диапазоны пересекаются; missing∩recorded ≠ ∅; high-water mark < послед-
него известного seq; заявленный auditStatus ≠ пересчёту. Нормативные
различения: dropped snapshots — штатный транспорт (свой поток со своим
high-water mark производителя), НЕ потеря фактов; отказ fact-sink —
дыра причинной летописи; RESULT_MISSING — seal, не audit.

### 7.1. Восстановление CausalFact (решение В4)

Recoverable ⇔ все пять: факт уже был порождён ядром; существует
детерминированный источник повторной выдачи ТОГО ЖЕ факта (живой
StepReport-буфер хоста); повторная выдача не вызывает step и не меняет
состояние; стабильный factId; повторная запись идемпотентна.
Правила: recoverable gap ⇒ Runtime ОБЯЗАН выполнить repair до finalize;
успешный repair закрывает диапазон, история repair остаётся в audit;
неуспешный ⇒ INCOMPLETE; permanent никогда не маскируется.
ЗАПРЕЩЕНО «восстанавливать» повторным прогоном ядра или реконструкцией
анализатором — это вывод, не исходный факт.

## 8. Числовая канонизация (доп.8) — ЗАКРЕПЛЕНО ВЕКТОРАМИ

archive-canon/json-v1 = ECMAScript Number::toString + литерал "-0".
Кросс-языковые векторы зафиксированы файлом
fixtures/numeric-canon-vectors.json: 19 случаев, каждый = { raw
IEEE-754 hex (BE), каноническая строка, SHA-256 канонических байтов }.
Покрыты: ±0, минимальная субнормаль, min-normal, max-finite, оба края
порога экспоненциальной записи (1e20/1e21), 1e-6/1e-7/5e-7, 0.1+0.2,
MAX_SAFE_INTEGER и за ним, соседи единицы, 1e16 (место расхождения с
печатью Python), мантисса на e20, отрицательное. Python/Rust-реализация
обязана из hex получить строку и хэш байт-в-байт; проверка — гейт шага 4.

## 9. Зарезервированная калибровочная родословная (ревизия п.9)

Изменение калибруемой поверхности закона — НЕ ObserverClaim и НЕ
обычный CommandRecord. Резервируются четыре типа записей (схемы —
в kernel-feedback-gate/1): KernelCalibrationProposal (заявление
самоорганизованной структуры), OperatorCalibrationDecision
(reject | defer | trial | apply-for-epoch), KernelCalibrationFact
(подтверждение ядра на безопасной границе), KernelEpochBoundary
(смена эпохи закона). Минимальная нить: proposalId →
operatorDecisionId → calibrationCommandId → fact.kernel.calibration.apply
→ kernelEpochBoundary. Родословная закона (lawHash, parent law, эпоха) —
обязательная часть идентичности среды исполнения.

## 10. Предупреждение оператору (ревизия п.10)

Режимы: LOCKED (только журналирование предложений) | CONFIRM_EACH |
BOUNDED_AUTO | AUTONOMOUS_CALIBRATION. Режим не может быть скрытым:
calibrationSafetyState входит в состояние Runtime и доступен любому UI;
при автономной калибровке главный экран постоянно показывает
«Автономная калибровка ядра включена» + версию/эпоху закона, разрешённую
поверхность, пределы, тик включения, последнее изменение, счётчик
автоприменений, кнопку немедленного отключения. Смена режима (включая
отключение предупреждений) — причинная операторская команда, fail-closed,
входит в runIdentityHash.

## 11. Обязательства реализации (после приёмки)

Семь схем §1 + manifest §7 + статусы §4; машины состояний
commandOutcome/journalStatus/seal с негативными тестами КАЖДОГО
запрещённого перехода; схемное принуждение цепочки §3; три порядка
replay + связка команды по correlationId; пересчёт auditStatus
читателем с отклонением; repair-протокол §7.1; вектора §8 в гейте.
JournalConsistencyValidator (Ф2) с негативными тестами каждого
инварианта: отсутствующая ссылка; ссылка на объект другого типа; ссылка
на запись другого запуска; APPLIED при fact.command.reject; два разных
терминальных результата одной команды; один факт, присвоенный двум
командам; цикл causationId. Плюс Ф1: тест «ABORTED с полной историей +
terminationReason + terminalTick + checkpoint ⇒ SEALED допустим» и
контртест «ABORTED без checkpoint и обоснования ⇒ SEALED отвергнут».
Центральный тест: «APPLIED + отказ result-журнала ⇒ UNSEALED,
runIdentityHash неизменен»; второй центральный: «авария хоста до
подтверждения ⇒ OUTCOME_UNKNOWN ⇒ runIdentityClass=causal-indeterminate
⇒ финализация только ABORTED+UNSEALED, сравнение с confirmed отвергается
API».
Доработка архива шага 4: finalize разводится на три оси; commandResults
выводятся из runIdentityHash (заменяются составом §5); replay — три
потока. Всё pre-freeze.

## 12. Смежные спецификации (в плане, отдельно)

execution-security/1 — защита программно-исполнительного слоя (TCB,
подписанный release manifest, воспроизводимые сборки, запрет
динамического исполнения, изоляция процессов, узкий command plane,
capability ceiling, kernel lineage, неизменяемость Gate).
kernel-feedback-gate/1 — единственный интерфейс самоорганизованной
причинной структуры к калибруемой поверхности; инвариант: через
калибровочный канал нельзя расширить саму calibration surface,
отключить аудит, checkpoint, предупреждение, откат или механизм
безопасности. Задачи разные, смешение запрещено.
