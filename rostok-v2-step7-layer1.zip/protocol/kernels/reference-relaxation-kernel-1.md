# reference-relaxation-kernel/1 — спецификация (rev 3, приёмка шага 1)

Подчиняется kernel-abi/2.1.0 (deadRegions — нормативное поле). Контрольное ядро: морфогенез невозможен
по построению, для научных выводов не используется.
Ревизия 2 закрывает уточнения ревизора У1–У7: третий буфер и ротация
ролей вместо чтения из output (У5); in-place-закон памяти (У4);
i*0.015625 как единственная форма инициализации (У6); drive — причинный
скаляр checkpoint/restore (У7); mutation-тесты У1–У3.

## 1. Состояние (N = 64, ёмкости фиксированы)

Три физических f64-буфера field0, field1, field2 и memory (все f64[64]).
Роли определяются курсором activePage ∈ {0,1,2}:
  input  = field[activePage]
  hist   = field[(activePage+2) mod 3]   // старший исторический канал
  output = field[(activePage+1) mod 3]
Ротация после такта: activePage = (activePage+1) mod 3 — без копирования:
output становится input, input — hist, hist — новым output.

cursors: activePage (0…2), phaseCursor (0…63).
rng.streams: noise (xorshift32, каноническая десятичная строка).
scalars: drive — ПРИЧИННЫЙ скаляр: входит в checkpoint, restore ОБЯЗАН
заменить текущее значение; совместимость не полагается на исходный config.
tick ≥ 0. Временных значений через границу такта нет (проверяется
mutation-тестами, не принимается на веру).

Мёртвая ролевая область декларируется в metadata нормативным полем
deadRegions (kernel-abi/2.1.0, Р1): { id:"page.output",
kind:"overwrite-before-read", buffers:[field0,field1,field2],
roleCursor:"activePage" }. Содержимое буфера в роли output на границе
такта мертво: полностью перезаписывается до любого чтения. Оно
сериализуется ради физической (не ролевой) записи; CausalStateHash —
RawCausalRecordHash (ABI §5a): неравенство хэшей при различии только в
мёртвой роли не означает различия будущего. Mutation-тест подтверждает
непричинность (обнуление output не меняет траекторию).

Р3 (приёмка): hashFn — замороженная зависимость конструктора;
emitChecksum=true без hashFn → E_CONFIG при initialize; скрытых
операций подключения не существует. restore — exact-валидация:
abiVersion, kernelName, kernelVersion, stateFormat, точный состав
буферов и дескрипторы каждого (dtype/numericClass/causal/encoding/
byteOrder/length); подмена любого поля → E_STATE_FORMAT
(негативный suite из 12 подделок).

metadata: moveClasses=["modify-state"]; moves=[{id:"field.relax",
class:"modify-state", atomic:true}]; growthCapabilities — все false;
growthCapable=false; dormant=[]; ceilings=[{elements:64}];
symmetries=[]; views=["series-view@1"].

## 2. RNG (закреплено тест-векторами)

xorshift32: s^=s<<13; s>>>=0; s^=s>>>17; s^=s<<5; s>>>=0; результат s.
Derivation: seed(имя) = (fnv1a32(utf8(имя)) XOR master)>>>0; 0 → 0x9e3779b9.
u32→f64: u / 2^32 (точное деление на степень двойки).
Векторы (master=8842107, "noise"): fnv1a32=0x904416d1; seed=0x90c2fdaa;
u32: 0x218c9831, 0xe3d6cff4, 0x7f220ee0, 0xe13c227f, 0xcb0de806;
f64: 0.1310515517834574, 0.8899965258315206, 0.49661343544721603,
0.8798238334711641, 0.7931809439323843.

## 3. Такт (порядок операций — закон)

p = phaseCursor; R(i) = (i+1+p) mod 64; L(i) = (i+63-(p mod 2)) mod 64.
Один проход i = 0…63; ровно один вызов RNG на элемент в этом порядке.
Нормативный in-place-закон (У4): для каждого i СНАЧАЛА вычисляется
output[i] из СТАРОГО memory[i], ЗАТЕМ немедленно записывается новый
memory[i]. Соседние memory не читаются, поэтому один проход корректен;
разбиение на два прохода — изменение закона. input и hist в течение
такта неизменяемы; output до конца такта не читается.

```
u         = rng.noise()                       // u32
noise     = (u / 4294967296) - 0.5            // [−0.5, 0.5)
output[i] = ( ( (input[i] * 0.5) + (input[R(i)] * 0.25) )
            + ( (hist[L(i)] * 0.125) + (memory[i] * 0.125) ) )
            + ( (noise * drive) * 0.00000095367431640625 )   // 2^-20
memory[i] = (memory[i] * 0.9375) + (output[i] * 0.0625)      // 15/16, 1/16
```

Ассоциативность закреплена скобками; формула дублируется в коде
байт-в-байт комментарием. После прохода: ротация ролей (§1),
phaseCursor = (phaseCursor+1) mod 64, tick += 1. Аллокаций в такте нет.

## 4. initialize

field0[i] = i * 0.015625 (единственная нормативная форма, У6);
field1 = field2 = memory = 0; activePage = 0; phaseCursor = 0;
drive из params.drive (по умолчанию 1.0; конечный f64, иначе E_CONFIG);
поток noise — derivation §2 от config.seed. StepReport.facts всегда [].
Внешних команд нет.

## 5. Conformance шага 1

Положительные: C1–C6, C9; step(n)≡n×step(1) по CausalStateHash и
согласованным отчётам; прямое ядро ≡ WorkerHost; FIFO-порядок хоста;
отказ одного вызова не создаёт параллельного входа; после shutdown —
только metadata и повторный shutdown; checkpoint не тянет RNG и не
меняет траекторию.

Mutation-suite полноты (каждый пункт: подделанный checkpoint →
restore → step(1) → траектория обязана разойтись):
обнуление буфера в роли input; обнуление буфера в роли hist;
обнуление memory после прогрева ≥50 тактов (У3); activePage+1 mod 3;
phaseCursor+1 — расхождение ПОЛЕВОГО содержимого уже на первом такте и
устойчиво на горизонтах 1, 8, 64, 256 (У1); RNG-state XOR ненулевой
маски — с предварительной проверкой, что первое следующее u32
гарантированно отличается, иначе взять другую маску (У2); drive×2 —
restore обязан заменить drive (У7); tick+1 (идентичность хэша).
Информационная проверка исключения: обнуление буфера в роли output
НЕ меняет траекторию (корректность ротации).
